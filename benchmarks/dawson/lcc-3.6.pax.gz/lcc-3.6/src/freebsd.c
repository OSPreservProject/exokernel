enum { EAX=0, ECX=1, EDX=2, EBX=3, ESI=6, EDI=7 };
#include "c.h"
#define NODEPTR_TYPE Node
#define OP_LABEL(p) ((p)->op)
#define LEFT_CHILD(p) ((p)->kids[0])
#define RIGHT_CHILD(p) ((p)->kids[1])
#define STATE_LABEL(p) ((p)->x.state)
static void address     ARGS((Symbol, Symbol, int));
static void blkfetch    ARGS((int, int, int, int));
static void blkloop     ARGS((int, int, int, int, int, int[]));
static void blkstore    ARGS((int, int, int, int));
static int  ckstack     ARGS((Node, int));
static void defaddress  ARGS((Symbol));
static void defconst    ARGS((int, Value));
static void defstring   ARGS((int, char *));
static void defsymbol   ARGS((Symbol));
static void doarg       ARGS((Node));
static void emit0       ARGS((Node));
static void emit2       ARGS((Node));
static void export      ARGS((Symbol));
static void clobber     ARGS((Node));
static void function    ARGS((Symbol, Symbol [], Symbol [], int));
static void global      ARGS((Symbol));
static void import      ARGS((Symbol));
static void local       ARGS((Symbol));
static void progbeg     ARGS((int, char **));
static void progend     ARGS((void));
static void segment     ARGS((int));
static void space       ARGS((int));
static void target      ARGS((Node));
static int memop ARGS((Node));
static int hasargs ARGS((Node));
static int sametree ARGS((Node, Node));
static Symbol charreg[32], shortreg[32], intreg[32];
static Symbol fltreg[32];

static int cseg;

static Symbol quo, rem;

/*
generated at Sun Oct 20 20:15:50 1996
by $Id: freebsd.c,v 1.1 1996/10/21 01:24:59 pinckney Exp $
*/
static void _kids ARGS((NODEPTR_TYPE, int, NODEPTR_TYPE[]));
static void _label ARGS((NODEPTR_TYPE));
static int _rule ARGS((void*, int));

#define _stmt_NT 1
#define _reg_NT 2
#define _freg_NT 3
#define _con_NT 4
#define _acon_NT 5
#define _baseaddr_NT 6
#define _base_NT 7
#define _con1_NT 8
#define _icon_NT 9
#define _index_NT 10
#define _addr_NT 11
#define _memb_NT 12
#define _memw_NT 13
#define _mem_NT 14
#define _rc5_NT 15
#define _rc_NT 16
#define _mr_NT 17
#define _mrb_NT 18
#define _mrw_NT 19
#define _mrc_NT 20
#define _mrca_NT 21
#define _memf_NT 22
#define _flt_NT 23
#define _addrj_NT 24
#define _addrjmp_NT 25
#define _cmpf_NT 26

static char *_ntname[] = {
	0,
	"stmt",
	"reg",
	"freg",
	"con",
	"acon",
	"baseaddr",
	"base",
	"con1",
	"icon",
	"index",
	"addr",
	"memb",
	"memw",
	"mem",
	"rc5",
	"rc",
	"mr",
	"mrb",
	"mrw",
	"mrc",
	"mrca",
	"memf",
	"flt",
	"addrj",
	"addrjmp",
	"cmpf",
	0
};

struct _state {
	short cost[27];
	struct {
		unsigned int _stmt:7;
		unsigned int _reg:6;
		unsigned int _freg:5;
		unsigned int _con:3;
		unsigned int _acon:3;
		unsigned int _baseaddr:1;
		unsigned int _base:3;
		unsigned int _con1:2;
		unsigned int _icon:3;
		unsigned int _index:2;
		unsigned int _addr:4;
		unsigned int _memb:1;
		unsigned int _memw:1;
		unsigned int _mem:2;
		unsigned int _rc5:2;
		unsigned int _rc:2;
		unsigned int _mr:2;
		unsigned int _mrb:2;
		unsigned int _mrw:2;
		unsigned int _mrc:3;
		unsigned int _mrca:2;
		unsigned int _memf:2;
		unsigned int _flt:2;
		unsigned int _addrj:2;
		unsigned int _addrjmp:2;
		unsigned int _cmpf:3;
	} rule;
};

static short _nts_0[] = { 0 };
static short _nts_1[] = { _reg_NT, 0 };
static short _nts_2[] = { _freg_NT, 0 };
static short _nts_3[] = { _reg_NT, _acon_NT, 0 };
static short _nts_4[] = { _reg_NT, _icon_NT, 0 };
static short _nts_5[] = { _base_NT, 0 };
static short _nts_6[] = { _baseaddr_NT, 0 };
static short _nts_7[] = { _index_NT, _baseaddr_NT, 0 };
static short _nts_8[] = { _reg_NT, _baseaddr_NT, 0 };
static short _nts_9[] = { _index_NT, _reg_NT, 0 };
static short _nts_10[] = { _index_NT, 0 };
static short _nts_11[] = { _addr_NT, 0 };
static short _nts_12[] = { _con_NT, 0 };
static short _nts_13[] = { _mem_NT, 0 };
static short _nts_14[] = { _memb_NT, 0 };
static short _nts_15[] = { _memw_NT, 0 };
static short _nts_16[] = { _rc_NT, 0 };
static short _nts_17[] = { _mr_NT, 0 };
static short _nts_18[] = { _mrb_NT, 0 };
static short _nts_19[] = { _mrw_NT, 0 };
static short _nts_20[] = { _reg_NT, _mrc_NT, 0 };
static short _nts_21[] = { _reg_NT, _rc5_NT, 0 };
static short _nts_22[] = { _addr_NT, _mem_NT, _con1_NT, 0 };
static short _nts_23[] = { _addr_NT, _mem_NT, _rc_NT, 0 };
static short _nts_24[] = { _addr_NT, _mem_NT, 0 };
static short _nts_25[] = { _addr_NT, _mem_NT, _rc5_NT, 0 };
static short _nts_26[] = { _con_NT, _mr_NT, 0 };
static short _nts_27[] = { _reg_NT, _mr_NT, 0 };
static short _nts_28[] = { _reg_NT, _reg_NT, 0 };
static short _nts_29[] = { _addr_NT, _rc_NT, 0 };
static short _nts_30[] = { _mrca_NT, 0 };
static short _nts_31[] = { _memf_NT, 0 };
static short _nts_32[] = { _addr_NT, _freg_NT, 0 };
static short _nts_33[] = { _freg_NT, _flt_NT, 0 };
static short _nts_34[] = { _freg_NT, _memf_NT, 0 };
static short _nts_35[] = { _freg_NT, _freg_NT, 0 };
static short _nts_36[] = { _addrjmp_NT, 0 };
static short _nts_37[] = { _mem_NT, _rc_NT, 0 };
static short _nts_38[] = { _cmpf_NT, _freg_NT, 0 };
static short _nts_39[] = { _addrj_NT, 0 };

static short *_nts[] = {
	0,	/* 0 */
	_nts_0,	/* 1 */
	_nts_0,	/* 2 */
	_nts_0,	/* 3 */
	_nts_0,	/* 4 */
	_nts_0,	/* 5 */
	_nts_0,	/* 6 */
	_nts_1,	/* 7 */
	_nts_1,	/* 8 */
	_nts_1,	/* 9 */
	_nts_1,	/* 10 */
	_nts_2,	/* 11 */
	_nts_2,	/* 12 */
	_nts_0,	/* 13 */
	_nts_0,	/* 14 */
	_nts_0,	/* 15 */
	_nts_0,	/* 16 */
	_nts_0,	/* 17 */
	_nts_1,	/* 18 */
	_nts_2,	/* 19 */
	_nts_1,	/* 20 */
	_nts_1,	/* 21 */
	_nts_1,	/* 22 */
	_nts_1,	/* 23 */
	_nts_0,	/* 24 */
	_nts_0,	/* 25 */
	_nts_0,	/* 26 */
	_nts_0,	/* 27 */
	_nts_0,	/* 28 */
	_nts_0,	/* 29 */
	_nts_0,	/* 30 */
	_nts_1,	/* 31 */
	_nts_3,	/* 32 */
	_nts_3,	/* 33 */
	_nts_3,	/* 34 */
	_nts_0,	/* 35 */
	_nts_0,	/* 36 */
	_nts_0,	/* 37 */
	_nts_0,	/* 38 */
	_nts_0,	/* 39 */
	_nts_0,	/* 40 */
	_nts_0,	/* 41 */
	_nts_0,	/* 42 */
	_nts_0,	/* 43 */
	_nts_0,	/* 44 */
	_nts_1,	/* 45 */
	_nts_4,	/* 46 */
	_nts_4,	/* 47 */
	_nts_5,	/* 48 */
	_nts_6,	/* 49 */
	_nts_7,	/* 50 */
	_nts_8,	/* 51 */
	_nts_9,	/* 52 */
	_nts_7,	/* 53 */
	_nts_8,	/* 54 */
	_nts_9,	/* 55 */
	_nts_7,	/* 56 */
	_nts_8,	/* 57 */
	_nts_9,	/* 58 */
	_nts_10,	/* 59 */
	_nts_11,	/* 60 */
	_nts_11,	/* 61 */
	_nts_11,	/* 62 */
	_nts_11,	/* 63 */
	_nts_0,	/* 64 */
	_nts_1,	/* 65 */
	_nts_1,	/* 66 */
	_nts_12,	/* 67 */
	_nts_1,	/* 68 */
	_nts_13,	/* 69 */
	_nts_1,	/* 70 */
	_nts_14,	/* 71 */
	_nts_1,	/* 72 */
	_nts_15,	/* 73 */
	_nts_13,	/* 74 */
	_nts_14,	/* 75 */
	_nts_15,	/* 76 */
	_nts_16,	/* 77 */
	_nts_11,	/* 78 */
	_nts_17,	/* 79 */
	_nts_18,	/* 80 */
	_nts_19,	/* 81 */
	_nts_12,	/* 82 */
	_nts_1,	/* 83 */
	_nts_1,	/* 84 */
	_nts_1,	/* 85 */
	_nts_1,	/* 86 */
	_nts_1,	/* 87 */
	_nts_20,	/* 88 */
	_nts_20,	/* 89 */
	_nts_20,	/* 90 */
	_nts_20,	/* 91 */
	_nts_20,	/* 92 */
	_nts_20,	/* 93 */
	_nts_20,	/* 94 */
	_nts_20,	/* 95 */
	_nts_20,	/* 96 */
	_nts_21,	/* 97 */
	_nts_21,	/* 98 */
	_nts_21,	/* 99 */
	_nts_21,	/* 100 */
	_nts_1,	/* 101 */
	_nts_1,	/* 102 */
	_nts_22,	/* 103 */
	_nts_22,	/* 104 */
	_nts_22,	/* 105 */
	_nts_22,	/* 106 */
	_nts_22,	/* 107 */
	_nts_22,	/* 108 */
	_nts_23,	/* 109 */
	_nts_23,	/* 110 */
	_nts_23,	/* 111 */
	_nts_23,	/* 112 */
	_nts_23,	/* 113 */
	_nts_23,	/* 114 */
	_nts_23,	/* 115 */
	_nts_24,	/* 116 */
	_nts_24,	/* 117 */
	_nts_25,	/* 118 */
	_nts_25,	/* 119 */
	_nts_25,	/* 120 */
	_nts_25,	/* 121 */
	_nts_20,	/* 122 */
	_nts_26,	/* 123 */
	_nts_27,	/* 124 */
	_nts_28,	/* 125 */
	_nts_28,	/* 126 */
	_nts_28,	/* 127 */
	_nts_28,	/* 128 */
	_nts_1,	/* 129 */
	_nts_1,	/* 130 */
	_nts_1,	/* 131 */
	_nts_1,	/* 132 */
	_nts_11,	/* 133 */
	_nts_11,	/* 134 */
	_nts_11,	/* 135 */
	_nts_11,	/* 136 */
	_nts_1,	/* 137 */
	_nts_1,	/* 138 */
	_nts_1,	/* 139 */
	_nts_1,	/* 140 */
	_nts_1,	/* 141 */
	_nts_1,	/* 142 */
	_nts_1,	/* 143 */
	_nts_1,	/* 144 */
	_nts_13,	/* 145 */
	_nts_16,	/* 146 */
	_nts_0,	/* 147 */
	_nts_29,	/* 148 */
	_nts_29,	/* 149 */
	_nts_29,	/* 150 */
	_nts_29,	/* 151 */
	_nts_28,	/* 152 */
	_nts_30,	/* 153 */
	_nts_30,	/* 154 */
	_nts_1,	/* 155 */
	_nts_11,	/* 156 */
	_nts_11,	/* 157 */
	_nts_11,	/* 158 */
	_nts_31,	/* 159 */
	_nts_32,	/* 160 */
	_nts_32,	/* 161 */
	_nts_32,	/* 162 */
	_nts_2,	/* 163 */
	_nts_2,	/* 164 */
	_nts_2,	/* 165 */
	_nts_2,	/* 166 */
	_nts_31,	/* 167 */
	_nts_2,	/* 168 */
	_nts_33,	/* 169 */
	_nts_33,	/* 170 */
	_nts_34,	/* 171 */
	_nts_35,	/* 172 */
	_nts_34,	/* 173 */
	_nts_35,	/* 174 */
	_nts_33,	/* 175 */
	_nts_33,	/* 176 */
	_nts_34,	/* 177 */
	_nts_35,	/* 178 */
	_nts_34,	/* 179 */
	_nts_35,	/* 180 */
	_nts_2,	/* 181 */
	_nts_2,	/* 182 */
	_nts_32,	/* 183 */
	_nts_2,	/* 184 */
	_nts_11,	/* 185 */
	_nts_1,	/* 186 */
	_nts_0,	/* 187 */
	_nts_1,	/* 188 */
	_nts_13,	/* 189 */
	_nts_0,	/* 190 */
	_nts_1,	/* 191 */
	_nts_13,	/* 192 */
	_nts_0,	/* 193 */
	_nts_36,	/* 194 */
	_nts_37,	/* 195 */
	_nts_37,	/* 196 */
	_nts_37,	/* 197 */
	_nts_37,	/* 198 */
	_nts_37,	/* 199 */
	_nts_37,	/* 200 */
	_nts_37,	/* 201 */
	_nts_37,	/* 202 */
	_nts_37,	/* 203 */
	_nts_37,	/* 204 */
	_nts_20,	/* 205 */
	_nts_20,	/* 206 */
	_nts_20,	/* 207 */
	_nts_20,	/* 208 */
	_nts_20,	/* 209 */
	_nts_20,	/* 210 */
	_nts_20,	/* 211 */
	_nts_20,	/* 212 */
	_nts_20,	/* 213 */
	_nts_20,	/* 214 */
	_nts_11,	/* 215 */
	_nts_11,	/* 216 */
	_nts_11,	/* 217 */
	_nts_2,	/* 218 */
	_nts_38,	/* 219 */
	_nts_38,	/* 220 */
	_nts_38,	/* 221 */
	_nts_38,	/* 222 */
	_nts_38,	/* 223 */
	_nts_38,	/* 224 */
	_nts_38,	/* 225 */
	_nts_38,	/* 226 */
	_nts_38,	/* 227 */
	_nts_38,	/* 228 */
	_nts_38,	/* 229 */
	_nts_38,	/* 230 */
	_nts_39,	/* 231 */
	_nts_39,	/* 232 */
	_nts_39,	/* 233 */
	_nts_39,	/* 234 */
	_nts_39,	/* 235 */
	_nts_39,	/* 236 */
	_nts_39,	/* 237 */
	_nts_39,	/* 238 */
	_nts_39,	/* 239 */
	_nts_39,	/* 240 */
	_nts_39,	/* 241 */
	_nts_39,	/* 242 */
	_nts_1,	/* 243 */
	_nts_2,	/* 244 */
	_nts_2,	/* 245 */
};

static char _arity[] = {
	0,	/* 0 */
	0,	/* 1 */
	0,	/* 2 */
	0,	/* 3 */
	0,	/* 4 */
	0,	/* 5 */
	0,	/* 6 */
	0,	/* 7 */
	0,	/* 8 */
	0,	/* 9 */
	0,	/* 10 */
	0,	/* 11 */
	0,	/* 12 */
	0,	/* 13 */
	0,	/* 14 */
	0,	/* 15 */
	0,	/* 16 */
	0,	/* 17=CNSTF */
	0,	/* 18=CNSTD */
	0,	/* 19=CNSTC */
	0,	/* 20=CNSTS */
	0,	/* 21=CNSTI */
	0,	/* 22=CNSTU */
	0,	/* 23=CNSTP */
	0,	/* 24 */
	0,	/* 25 */
	0,	/* 26 */
	0,	/* 27 */
	0,	/* 28 */
	0,	/* 29 */
	0,	/* 30 */
	0,	/* 31 */
	0,	/* 32 */
	1,	/* 33=ARGF */
	1,	/* 34=ARGD */
	0,	/* 35 */
	0,	/* 36 */
	1,	/* 37=ARGI */
	0,	/* 38 */
	1,	/* 39=ARGP */
	0,	/* 40 */
	1,	/* 41=ARGB */
	0,	/* 42 */
	0,	/* 43 */
	0,	/* 44 */
	0,	/* 45 */
	0,	/* 46 */
	0,	/* 47 */
	0,	/* 48 */
	2,	/* 49=ASGNF */
	2,	/* 50=ASGND */
	2,	/* 51=ASGNC */
	2,	/* 52=ASGNS */
	2,	/* 53=ASGNI */
	0,	/* 54 */
	2,	/* 55=ASGNP */
	0,	/* 56 */
	2,	/* 57=ASGNB */
	0,	/* 58 */
	0,	/* 59 */
	0,	/* 60 */
	0,	/* 61 */
	0,	/* 62 */
	0,	/* 63 */
	0,	/* 64 */
	1,	/* 65=INDIRF */
	1,	/* 66=INDIRD */
	1,	/* 67=INDIRC */
	1,	/* 68=INDIRS */
	1,	/* 69=INDIRI */
	0,	/* 70 */
	1,	/* 71=INDIRP */
	0,	/* 72 */
	1,	/* 73=INDIRB */
	0,	/* 74 */
	0,	/* 75 */
	0,	/* 76 */
	0,	/* 77 */
	0,	/* 78 */
	0,	/* 79 */
	0,	/* 80 */
	0,	/* 81 */
	0,	/* 82 */
	0,	/* 83 */
	0,	/* 84 */
	1,	/* 85=CVCI */
	1,	/* 86=CVCU */
	0,	/* 87 */
	0,	/* 88 */
	0,	/* 89 */
	0,	/* 90 */
	0,	/* 91 */
	0,	/* 92 */
	0,	/* 93 */
	0,	/* 94 */
	0,	/* 95 */
	0,	/* 96 */
	1,	/* 97=CVDF */
	0,	/* 98 */
	0,	/* 99 */
	0,	/* 100 */
	1,	/* 101=CVDI */
	0,	/* 102 */
	0,	/* 103 */
	0,	/* 104 */
	0,	/* 105 */
	0,	/* 106 */
	0,	/* 107 */
	0,	/* 108 */
	0,	/* 109 */
	0,	/* 110 */
	0,	/* 111 */
	0,	/* 112 */
	0,	/* 113 */
	1,	/* 114=CVFD */
	0,	/* 115 */
	0,	/* 116 */
	0,	/* 117 */
	0,	/* 118 */
	0,	/* 119 */
	0,	/* 120 */
	0,	/* 121 */
	0,	/* 122 */
	0,	/* 123 */
	0,	/* 124 */
	0,	/* 125 */
	0,	/* 126 */
	0,	/* 127 */
	0,	/* 128 */
	0,	/* 129 */
	1,	/* 130=CVID */
	1,	/* 131=CVIC */
	1,	/* 132=CVIS */
	0,	/* 133 */
	1,	/* 134=CVIU */
	0,	/* 135 */
	0,	/* 136 */
	0,	/* 137 */
	0,	/* 138 */
	0,	/* 139 */
	0,	/* 140 */
	0,	/* 141 */
	0,	/* 142 */
	0,	/* 143 */
	0,	/* 144 */
	0,	/* 145 */
	0,	/* 146 */
	0,	/* 147 */
	0,	/* 148 */
	0,	/* 149 */
	1,	/* 150=CVPU */
	0,	/* 151 */
	0,	/* 152 */
	0,	/* 153 */
	0,	/* 154 */
	0,	/* 155 */
	0,	/* 156 */
	0,	/* 157 */
	0,	/* 158 */
	0,	/* 159 */
	0,	/* 160 */
	0,	/* 161 */
	0,	/* 162 */
	0,	/* 163 */
	0,	/* 164 */
	1,	/* 165=CVSI */
	1,	/* 166=CVSU */
	0,	/* 167 */
	0,	/* 168 */
	0,	/* 169 */
	0,	/* 170 */
	0,	/* 171 */
	0,	/* 172 */
	0,	/* 173 */
	0,	/* 174 */
	0,	/* 175 */
	0,	/* 176 */
	0,	/* 177 */
	0,	/* 178 */
	1,	/* 179=CVUC */
	1,	/* 180=CVUS */
	1,	/* 181=CVUI */
	0,	/* 182 */
	1,	/* 183=CVUP */
	0,	/* 184 */
	0,	/* 185 */
	0,	/* 186 */
	0,	/* 187 */
	0,	/* 188 */
	0,	/* 189 */
	0,	/* 190 */
	0,	/* 191 */
	0,	/* 192 */
	1,	/* 193=NEGF */
	1,	/* 194=NEGD */
	0,	/* 195 */
	0,	/* 196 */
	1,	/* 197=NEGI */
	0,	/* 198 */
	0,	/* 199 */
	0,	/* 200 */
	0,	/* 201 */
	0,	/* 202 */
	0,	/* 203 */
	0,	/* 204 */
	0,	/* 205 */
	0,	/* 206 */
	0,	/* 207 */
	0,	/* 208 */
	1,	/* 209=CALLF */
	1,	/* 210=CALLD */
	0,	/* 211 */
	0,	/* 212 */
	1,	/* 213=CALLI */
	0,	/* 214 */
	0,	/* 215 */
	1,	/* 216=CALLV */
	0,	/* 217=CALLB */
	0,	/* 218 */
	0,	/* 219 */
	0,	/* 220 */
	0,	/* 221 */
	0,	/* 222 */
	0,	/* 223 */
	0,	/* 224 */
	0,	/* 225=LOADF */
	0,	/* 226=LOADD */
	1,	/* 227=LOADC */
	1,	/* 228=LOADS */
	1,	/* 229=LOADI */
	1,	/* 230=LOADU */
	1,	/* 231=LOADP */
	0,	/* 232 */
	0,	/* 233=LOADB */
	0,	/* 234 */
	0,	/* 235 */
	0,	/* 236 */
	0,	/* 237 */
	0,	/* 238 */
	0,	/* 239 */
	0,	/* 240 */
	1,	/* 241=RETF */
	1,	/* 242=RETD */
	0,	/* 243 */
	0,	/* 244 */
	1,	/* 245=RETI */
	0,	/* 246 */
	0,	/* 247 */
	0,	/* 248 */
	0,	/* 249 */
	0,	/* 250 */
	0,	/* 251 */
	0,	/* 252 */
	0,	/* 253 */
	0,	/* 254 */
	0,	/* 255 */
	0,	/* 256 */
	0,	/* 257 */
	0,	/* 258 */
	0,	/* 259 */
	0,	/* 260 */
	0,	/* 261 */
	0,	/* 262 */
	0,	/* 263=ADDRGP */
	0,	/* 264 */
	0,	/* 265 */
	0,	/* 266 */
	0,	/* 267 */
	0,	/* 268 */
	0,	/* 269 */
	0,	/* 270 */
	0,	/* 271 */
	0,	/* 272 */
	0,	/* 273 */
	0,	/* 274 */
	0,	/* 275 */
	0,	/* 276 */
	0,	/* 277 */
	0,	/* 278 */
	0,	/* 279=ADDRFP */
	0,	/* 280 */
	0,	/* 281 */
	0,	/* 282 */
	0,	/* 283 */
	0,	/* 284 */
	0,	/* 285 */
	0,	/* 286 */
	0,	/* 287 */
	0,	/* 288 */
	0,	/* 289 */
	0,	/* 290 */
	0,	/* 291 */
	0,	/* 292 */
	0,	/* 293 */
	0,	/* 294 */
	0,	/* 295=ADDRLP */
	0,	/* 296 */
	0,	/* 297 */
	0,	/* 298 */
	0,	/* 299 */
	0,	/* 300 */
	0,	/* 301 */
	0,	/* 302 */
	0,	/* 303 */
	0,	/* 304 */
	2,	/* 305=ADDF */
	2,	/* 306=ADDD */
	0,	/* 307 */
	0,	/* 308 */
	2,	/* 309=ADDI */
	2,	/* 310=ADDU */
	2,	/* 311=ADDP */
	0,	/* 312 */
	0,	/* 313 */
	0,	/* 314 */
	0,	/* 315 */
	0,	/* 316 */
	0,	/* 317 */
	0,	/* 318 */
	0,	/* 319 */
	0,	/* 320 */
	2,	/* 321=SUBF */
	2,	/* 322=SUBD */
	0,	/* 323 */
	0,	/* 324 */
	2,	/* 325=SUBI */
	2,	/* 326=SUBU */
	2,	/* 327=SUBP */
	0,	/* 328 */
	0,	/* 329 */
	0,	/* 330 */
	0,	/* 331 */
	0,	/* 332 */
	0,	/* 333 */
	0,	/* 334 */
	0,	/* 335 */
	0,	/* 336 */
	0,	/* 337 */
	0,	/* 338 */
	0,	/* 339 */
	0,	/* 340 */
	2,	/* 341=LSHI */
	2,	/* 342=LSHU */
	0,	/* 343 */
	0,	/* 344 */
	0,	/* 345 */
	0,	/* 346 */
	0,	/* 347 */
	0,	/* 348 */
	0,	/* 349 */
	0,	/* 350 */
	0,	/* 351 */
	0,	/* 352 */
	0,	/* 353 */
	0,	/* 354 */
	0,	/* 355 */
	0,	/* 356 */
	2,	/* 357=MODI */
	2,	/* 358=MODU */
	0,	/* 359 */
	0,	/* 360 */
	0,	/* 361 */
	0,	/* 362 */
	0,	/* 363 */
	0,	/* 364 */
	0,	/* 365 */
	0,	/* 366 */
	0,	/* 367 */
	0,	/* 368 */
	0,	/* 369 */
	0,	/* 370 */
	0,	/* 371 */
	0,	/* 372 */
	2,	/* 373=RSHI */
	2,	/* 374=RSHU */
	0,	/* 375 */
	0,	/* 376 */
	0,	/* 377 */
	0,	/* 378 */
	0,	/* 379 */
	0,	/* 380 */
	0,	/* 381 */
	0,	/* 382 */
	0,	/* 383 */
	0,	/* 384 */
	0,	/* 385 */
	0,	/* 386 */
	0,	/* 387 */
	0,	/* 388 */
	0,	/* 389 */
	2,	/* 390=BANDU */
	0,	/* 391 */
	0,	/* 392 */
	0,	/* 393 */
	0,	/* 394 */
	0,	/* 395 */
	0,	/* 396 */
	0,	/* 397 */
	0,	/* 398 */
	0,	/* 399 */
	0,	/* 400 */
	0,	/* 401 */
	0,	/* 402 */
	0,	/* 403 */
	0,	/* 404 */
	0,	/* 405 */
	1,	/* 406=BCOMU */
	0,	/* 407 */
	0,	/* 408 */
	0,	/* 409 */
	0,	/* 410 */
	0,	/* 411 */
	0,	/* 412 */
	0,	/* 413 */
	0,	/* 414 */
	0,	/* 415 */
	0,	/* 416 */
	0,	/* 417 */
	0,	/* 418 */
	0,	/* 419 */
	0,	/* 420 */
	0,	/* 421 */
	2,	/* 422=BORU */
	0,	/* 423 */
	0,	/* 424 */
	0,	/* 425 */
	0,	/* 426 */
	0,	/* 427 */
	0,	/* 428 */
	0,	/* 429 */
	0,	/* 430 */
	0,	/* 431 */
	0,	/* 432 */
	0,	/* 433 */
	0,	/* 434 */
	0,	/* 435 */
	0,	/* 436 */
	0,	/* 437 */
	2,	/* 438=BXORU */
	0,	/* 439 */
	0,	/* 440 */
	0,	/* 441 */
	0,	/* 442 */
	0,	/* 443 */
	0,	/* 444 */
	0,	/* 445 */
	0,	/* 446 */
	0,	/* 447 */
	0,	/* 448 */
	2,	/* 449=DIVF */
	2,	/* 450=DIVD */
	0,	/* 451 */
	0,	/* 452 */
	2,	/* 453=DIVI */
	2,	/* 454=DIVU */
	0,	/* 455 */
	0,	/* 456 */
	0,	/* 457 */
	0,	/* 458 */
	0,	/* 459 */
	0,	/* 460 */
	0,	/* 461 */
	0,	/* 462 */
	0,	/* 463 */
	0,	/* 464 */
	2,	/* 465=MULF */
	2,	/* 466=MULD */
	0,	/* 467 */
	0,	/* 468 */
	2,	/* 469=MULI */
	2,	/* 470=MULU */
	0,	/* 471 */
	0,	/* 472 */
	0,	/* 473 */
	0,	/* 474 */
	0,	/* 475 */
	0,	/* 476 */
	0,	/* 477 */
	0,	/* 478 */
	0,	/* 479 */
	0,	/* 480 */
	2,	/* 481=EQF */
	2,	/* 482=EQD */
	0,	/* 483 */
	0,	/* 484 */
	2,	/* 485=EQI */
	0,	/* 486 */
	0,	/* 487 */
	0,	/* 488 */
	0,	/* 489 */
	0,	/* 490 */
	0,	/* 491 */
	0,	/* 492 */
	0,	/* 493 */
	0,	/* 494 */
	0,	/* 495 */
	0,	/* 496 */
	2,	/* 497=GEF */
	2,	/* 498=GED */
	0,	/* 499 */
	0,	/* 500 */
	2,	/* 501=GEI */
	2,	/* 502=GEU */
	0,	/* 503 */
	0,	/* 504 */
	0,	/* 505 */
	0,	/* 506 */
	0,	/* 507 */
	0,	/* 508 */
	0,	/* 509 */
	0,	/* 510 */
	0,	/* 511 */
	0,	/* 512 */
	2,	/* 513=GTF */
	2,	/* 514=GTD */
	0,	/* 515 */
	0,	/* 516 */
	2,	/* 517=GTI */
	2,	/* 518=GTU */
	0,	/* 519 */
	0,	/* 520 */
	0,	/* 521 */
	0,	/* 522 */
	0,	/* 523 */
	0,	/* 524 */
	0,	/* 525 */
	0,	/* 526 */
	0,	/* 527 */
	0,	/* 528 */
	2,	/* 529=LEF */
	2,	/* 530=LED */
	0,	/* 531 */
	0,	/* 532 */
	2,	/* 533=LEI */
	2,	/* 534=LEU */
	0,	/* 535 */
	0,	/* 536 */
	0,	/* 537 */
	0,	/* 538 */
	0,	/* 539 */
	0,	/* 540 */
	0,	/* 541 */
	0,	/* 542 */
	0,	/* 543 */
	0,	/* 544 */
	2,	/* 545=LTF */
	2,	/* 546=LTD */
	0,	/* 547 */
	0,	/* 548 */
	2,	/* 549=LTI */
	2,	/* 550=LTU */
	0,	/* 551 */
	0,	/* 552 */
	0,	/* 553 */
	0,	/* 554 */
	0,	/* 555 */
	0,	/* 556 */
	0,	/* 557 */
	0,	/* 558 */
	0,	/* 559 */
	0,	/* 560 */
	2,	/* 561=NEF */
	2,	/* 562=NED */
	0,	/* 563 */
	0,	/* 564 */
	2,	/* 565=NEI */
	0,	/* 566 */
	0,	/* 567 */
	0,	/* 568 */
	0,	/* 569 */
	0,	/* 570 */
	0,	/* 571 */
	0,	/* 572 */
	0,	/* 573 */
	0,	/* 574 */
	0,	/* 575 */
	0,	/* 576 */
	0,	/* 577 */
	0,	/* 578 */
	0,	/* 579 */
	0,	/* 580 */
	0,	/* 581 */
	0,	/* 582 */
	0,	/* 583 */
	1,	/* 584=JUMPV */
	0,	/* 585 */
	0,	/* 586 */
	0,	/* 587 */
	0,	/* 588 */
	0,	/* 589 */
	0,	/* 590 */
	0,	/* 591 */
	0,	/* 592 */
	0,	/* 593 */
	0,	/* 594 */
	0,	/* 595 */
	0,	/* 596 */
	0,	/* 597 */
	0,	/* 598 */
	0,	/* 599 */
	0,	/* 600=LABELV */
	0,	/* 601 */
	0,	/* 602 */
	0,	/* 603 */
	0,	/* 604 */
	0,	/* 605 */
	0,	/* 606 */
	0,	/* 607 */
	0,	/* 608 */
	0,	/* 609 */
	0,	/* 610 */
	0,	/* 611 */
	0,	/* 612 */
	0,	/* 613 */
	0,	/* 614 */
	0,	/* 615=VREGP */
};

static char *_opname[] = {
/* 0 */	0,
/* 1 */	0,
/* 2 */	0,
/* 3 */	0,
/* 4 */	0,
/* 5 */	0,
/* 6 */	0,
/* 7 */	0,
/* 8 */	0,
/* 9 */	0,
/* 10 */	0,
/* 11 */	0,
/* 12 */	0,
/* 13 */	0,
/* 14 */	0,
/* 15 */	0,
/* 16 */	0,
/* 17 */	"CNSTF",
/* 18 */	"CNSTD",
/* 19 */	"CNSTC",
/* 20 */	"CNSTS",
/* 21 */	"CNSTI",
/* 22 */	"CNSTU",
/* 23 */	"CNSTP",
/* 24 */	0,
/* 25 */	0,
/* 26 */	0,
/* 27 */	0,
/* 28 */	0,
/* 29 */	0,
/* 30 */	0,
/* 31 */	0,
/* 32 */	0,
/* 33 */	"ARGF",
/* 34 */	"ARGD",
/* 35 */	0,
/* 36 */	0,
/* 37 */	"ARGI",
/* 38 */	0,
/* 39 */	"ARGP",
/* 40 */	0,
/* 41 */	"ARGB",
/* 42 */	0,
/* 43 */	0,
/* 44 */	0,
/* 45 */	0,
/* 46 */	0,
/* 47 */	0,
/* 48 */	0,
/* 49 */	"ASGNF",
/* 50 */	"ASGND",
/* 51 */	"ASGNC",
/* 52 */	"ASGNS",
/* 53 */	"ASGNI",
/* 54 */	0,
/* 55 */	"ASGNP",
/* 56 */	0,
/* 57 */	"ASGNB",
/* 58 */	0,
/* 59 */	0,
/* 60 */	0,
/* 61 */	0,
/* 62 */	0,
/* 63 */	0,
/* 64 */	0,
/* 65 */	"INDIRF",
/* 66 */	"INDIRD",
/* 67 */	"INDIRC",
/* 68 */	"INDIRS",
/* 69 */	"INDIRI",
/* 70 */	0,
/* 71 */	"INDIRP",
/* 72 */	0,
/* 73 */	"INDIRB",
/* 74 */	0,
/* 75 */	0,
/* 76 */	0,
/* 77 */	0,
/* 78 */	0,
/* 79 */	0,
/* 80 */	0,
/* 81 */	0,
/* 82 */	0,
/* 83 */	0,
/* 84 */	0,
/* 85 */	"CVCI",
/* 86 */	"CVCU",
/* 87 */	0,
/* 88 */	0,
/* 89 */	0,
/* 90 */	0,
/* 91 */	0,
/* 92 */	0,
/* 93 */	0,
/* 94 */	0,
/* 95 */	0,
/* 96 */	0,
/* 97 */	"CVDF",
/* 98 */	0,
/* 99 */	0,
/* 100 */	0,
/* 101 */	"CVDI",
/* 102 */	0,
/* 103 */	0,
/* 104 */	0,
/* 105 */	0,
/* 106 */	0,
/* 107 */	0,
/* 108 */	0,
/* 109 */	0,
/* 110 */	0,
/* 111 */	0,
/* 112 */	0,
/* 113 */	0,
/* 114 */	"CVFD",
/* 115 */	0,
/* 116 */	0,
/* 117 */	0,
/* 118 */	0,
/* 119 */	0,
/* 120 */	0,
/* 121 */	0,
/* 122 */	0,
/* 123 */	0,
/* 124 */	0,
/* 125 */	0,
/* 126 */	0,
/* 127 */	0,
/* 128 */	0,
/* 129 */	0,
/* 130 */	"CVID",
/* 131 */	"CVIC",
/* 132 */	"CVIS",
/* 133 */	0,
/* 134 */	"CVIU",
/* 135 */	0,
/* 136 */	0,
/* 137 */	0,
/* 138 */	0,
/* 139 */	0,
/* 140 */	0,
/* 141 */	0,
/* 142 */	0,
/* 143 */	0,
/* 144 */	0,
/* 145 */	0,
/* 146 */	0,
/* 147 */	0,
/* 148 */	0,
/* 149 */	0,
/* 150 */	"CVPU",
/* 151 */	0,
/* 152 */	0,
/* 153 */	0,
/* 154 */	0,
/* 155 */	0,
/* 156 */	0,
/* 157 */	0,
/* 158 */	0,
/* 159 */	0,
/* 160 */	0,
/* 161 */	0,
/* 162 */	0,
/* 163 */	0,
/* 164 */	0,
/* 165 */	"CVSI",
/* 166 */	"CVSU",
/* 167 */	0,
/* 168 */	0,
/* 169 */	0,
/* 170 */	0,
/* 171 */	0,
/* 172 */	0,
/* 173 */	0,
/* 174 */	0,
/* 175 */	0,
/* 176 */	0,
/* 177 */	0,
/* 178 */	0,
/* 179 */	"CVUC",
/* 180 */	"CVUS",
/* 181 */	"CVUI",
/* 182 */	0,
/* 183 */	"CVUP",
/* 184 */	0,
/* 185 */	0,
/* 186 */	0,
/* 187 */	0,
/* 188 */	0,
/* 189 */	0,
/* 190 */	0,
/* 191 */	0,
/* 192 */	0,
/* 193 */	"NEGF",
/* 194 */	"NEGD",
/* 195 */	0,
/* 196 */	0,
/* 197 */	"NEGI",
/* 198 */	0,
/* 199 */	0,
/* 200 */	0,
/* 201 */	0,
/* 202 */	0,
/* 203 */	0,
/* 204 */	0,
/* 205 */	0,
/* 206 */	0,
/* 207 */	0,
/* 208 */	0,
/* 209 */	"CALLF",
/* 210 */	"CALLD",
/* 211 */	0,
/* 212 */	0,
/* 213 */	"CALLI",
/* 214 */	0,
/* 215 */	0,
/* 216 */	"CALLV",
/* 217 */	"CALLB",
/* 218 */	0,
/* 219 */	0,
/* 220 */	0,
/* 221 */	0,
/* 222 */	0,
/* 223 */	0,
/* 224 */	0,
/* 225 */	"LOADF",
/* 226 */	"LOADD",
/* 227 */	"LOADC",
/* 228 */	"LOADS",
/* 229 */	"LOADI",
/* 230 */	"LOADU",
/* 231 */	"LOADP",
/* 232 */	0,
/* 233 */	"LOADB",
/* 234 */	0,
/* 235 */	0,
/* 236 */	0,
/* 237 */	0,
/* 238 */	0,
/* 239 */	0,
/* 240 */	0,
/* 241 */	"RETF",
/* 242 */	"RETD",
/* 243 */	0,
/* 244 */	0,
/* 245 */	"RETI",
/* 246 */	0,
/* 247 */	0,
/* 248 */	0,
/* 249 */	0,
/* 250 */	0,
/* 251 */	0,
/* 252 */	0,
/* 253 */	0,
/* 254 */	0,
/* 255 */	0,
/* 256 */	0,
/* 257 */	0,
/* 258 */	0,
/* 259 */	0,
/* 260 */	0,
/* 261 */	0,
/* 262 */	0,
/* 263 */	"ADDRGP",
/* 264 */	0,
/* 265 */	0,
/* 266 */	0,
/* 267 */	0,
/* 268 */	0,
/* 269 */	0,
/* 270 */	0,
/* 271 */	0,
/* 272 */	0,
/* 273 */	0,
/* 274 */	0,
/* 275 */	0,
/* 276 */	0,
/* 277 */	0,
/* 278 */	0,
/* 279 */	"ADDRFP",
/* 280 */	0,
/* 281 */	0,
/* 282 */	0,
/* 283 */	0,
/* 284 */	0,
/* 285 */	0,
/* 286 */	0,
/* 287 */	0,
/* 288 */	0,
/* 289 */	0,
/* 290 */	0,
/* 291 */	0,
/* 292 */	0,
/* 293 */	0,
/* 294 */	0,
/* 295 */	"ADDRLP",
/* 296 */	0,
/* 297 */	0,
/* 298 */	0,
/* 299 */	0,
/* 300 */	0,
/* 301 */	0,
/* 302 */	0,
/* 303 */	0,
/* 304 */	0,
/* 305 */	"ADDF",
/* 306 */	"ADDD",
/* 307 */	0,
/* 308 */	0,
/* 309 */	"ADDI",
/* 310 */	"ADDU",
/* 311 */	"ADDP",
/* 312 */	0,
/* 313 */	0,
/* 314 */	0,
/* 315 */	0,
/* 316 */	0,
/* 317 */	0,
/* 318 */	0,
/* 319 */	0,
/* 320 */	0,
/* 321 */	"SUBF",
/* 322 */	"SUBD",
/* 323 */	0,
/* 324 */	0,
/* 325 */	"SUBI",
/* 326 */	"SUBU",
/* 327 */	"SUBP",
/* 328 */	0,
/* 329 */	0,
/* 330 */	0,
/* 331 */	0,
/* 332 */	0,
/* 333 */	0,
/* 334 */	0,
/* 335 */	0,
/* 336 */	0,
/* 337 */	0,
/* 338 */	0,
/* 339 */	0,
/* 340 */	0,
/* 341 */	"LSHI",
/* 342 */	"LSHU",
/* 343 */	0,
/* 344 */	0,
/* 345 */	0,
/* 346 */	0,
/* 347 */	0,
/* 348 */	0,
/* 349 */	0,
/* 350 */	0,
/* 351 */	0,
/* 352 */	0,
/* 353 */	0,
/* 354 */	0,
/* 355 */	0,
/* 356 */	0,
/* 357 */	"MODI",
/* 358 */	"MODU",
/* 359 */	0,
/* 360 */	0,
/* 361 */	0,
/* 362 */	0,
/* 363 */	0,
/* 364 */	0,
/* 365 */	0,
/* 366 */	0,
/* 367 */	0,
/* 368 */	0,
/* 369 */	0,
/* 370 */	0,
/* 371 */	0,
/* 372 */	0,
/* 373 */	"RSHI",
/* 374 */	"RSHU",
/* 375 */	0,
/* 376 */	0,
/* 377 */	0,
/* 378 */	0,
/* 379 */	0,
/* 380 */	0,
/* 381 */	0,
/* 382 */	0,
/* 383 */	0,
/* 384 */	0,
/* 385 */	0,
/* 386 */	0,
/* 387 */	0,
/* 388 */	0,
/* 389 */	0,
/* 390 */	"BANDU",
/* 391 */	0,
/* 392 */	0,
/* 393 */	0,
/* 394 */	0,
/* 395 */	0,
/* 396 */	0,
/* 397 */	0,
/* 398 */	0,
/* 399 */	0,
/* 400 */	0,
/* 401 */	0,
/* 402 */	0,
/* 403 */	0,
/* 404 */	0,
/* 405 */	0,
/* 406 */	"BCOMU",
/* 407 */	0,
/* 408 */	0,
/* 409 */	0,
/* 410 */	0,
/* 411 */	0,
/* 412 */	0,
/* 413 */	0,
/* 414 */	0,
/* 415 */	0,
/* 416 */	0,
/* 417 */	0,
/* 418 */	0,
/* 419 */	0,
/* 420 */	0,
/* 421 */	0,
/* 422 */	"BORU",
/* 423 */	0,
/* 424 */	0,
/* 425 */	0,
/* 426 */	0,
/* 427 */	0,
/* 428 */	0,
/* 429 */	0,
/* 430 */	0,
/* 431 */	0,
/* 432 */	0,
/* 433 */	0,
/* 434 */	0,
/* 435 */	0,
/* 436 */	0,
/* 437 */	0,
/* 438 */	"BXORU",
/* 439 */	0,
/* 440 */	0,
/* 441 */	0,
/* 442 */	0,
/* 443 */	0,
/* 444 */	0,
/* 445 */	0,
/* 446 */	0,
/* 447 */	0,
/* 448 */	0,
/* 449 */	"DIVF",
/* 450 */	"DIVD",
/* 451 */	0,
/* 452 */	0,
/* 453 */	"DIVI",
/* 454 */	"DIVU",
/* 455 */	0,
/* 456 */	0,
/* 457 */	0,
/* 458 */	0,
/* 459 */	0,
/* 460 */	0,
/* 461 */	0,
/* 462 */	0,
/* 463 */	0,
/* 464 */	0,
/* 465 */	"MULF",
/* 466 */	"MULD",
/* 467 */	0,
/* 468 */	0,
/* 469 */	"MULI",
/* 470 */	"MULU",
/* 471 */	0,
/* 472 */	0,
/* 473 */	0,
/* 474 */	0,
/* 475 */	0,
/* 476 */	0,
/* 477 */	0,
/* 478 */	0,
/* 479 */	0,
/* 480 */	0,
/* 481 */	"EQF",
/* 482 */	"EQD",
/* 483 */	0,
/* 484 */	0,
/* 485 */	"EQI",
/* 486 */	0,
/* 487 */	0,
/* 488 */	0,
/* 489 */	0,
/* 490 */	0,
/* 491 */	0,
/* 492 */	0,
/* 493 */	0,
/* 494 */	0,
/* 495 */	0,
/* 496 */	0,
/* 497 */	"GEF",
/* 498 */	"GED",
/* 499 */	0,
/* 500 */	0,
/* 501 */	"GEI",
/* 502 */	"GEU",
/* 503 */	0,
/* 504 */	0,
/* 505 */	0,
/* 506 */	0,
/* 507 */	0,
/* 508 */	0,
/* 509 */	0,
/* 510 */	0,
/* 511 */	0,
/* 512 */	0,
/* 513 */	"GTF",
/* 514 */	"GTD",
/* 515 */	0,
/* 516 */	0,
/* 517 */	"GTI",
/* 518 */	"GTU",
/* 519 */	0,
/* 520 */	0,
/* 521 */	0,
/* 522 */	0,
/* 523 */	0,
/* 524 */	0,
/* 525 */	0,
/* 526 */	0,
/* 527 */	0,
/* 528 */	0,
/* 529 */	"LEF",
/* 530 */	"LED",
/* 531 */	0,
/* 532 */	0,
/* 533 */	"LEI",
/* 534 */	"LEU",
/* 535 */	0,
/* 536 */	0,
/* 537 */	0,
/* 538 */	0,
/* 539 */	0,
/* 540 */	0,
/* 541 */	0,
/* 542 */	0,
/* 543 */	0,
/* 544 */	0,
/* 545 */	"LTF",
/* 546 */	"LTD",
/* 547 */	0,
/* 548 */	0,
/* 549 */	"LTI",
/* 550 */	"LTU",
/* 551 */	0,
/* 552 */	0,
/* 553 */	0,
/* 554 */	0,
/* 555 */	0,
/* 556 */	0,
/* 557 */	0,
/* 558 */	0,
/* 559 */	0,
/* 560 */	0,
/* 561 */	"NEF",
/* 562 */	"NED",
/* 563 */	0,
/* 564 */	0,
/* 565 */	"NEI",
/* 566 */	0,
/* 567 */	0,
/* 568 */	0,
/* 569 */	0,
/* 570 */	0,
/* 571 */	0,
/* 572 */	0,
/* 573 */	0,
/* 574 */	0,
/* 575 */	0,
/* 576 */	0,
/* 577 */	0,
/* 578 */	0,
/* 579 */	0,
/* 580 */	0,
/* 581 */	0,
/* 582 */	0,
/* 583 */	0,
/* 584 */	"JUMPV",
/* 585 */	0,
/* 586 */	0,
/* 587 */	0,
/* 588 */	0,
/* 589 */	0,
/* 590 */	0,
/* 591 */	0,
/* 592 */	0,
/* 593 */	0,
/* 594 */	0,
/* 595 */	0,
/* 596 */	0,
/* 597 */	0,
/* 598 */	0,
/* 599 */	0,
/* 600 */	"LABELV",
/* 601 */	0,
/* 602 */	0,
/* 603 */	0,
/* 604 */	0,
/* 605 */	0,
/* 606 */	0,
/* 607 */	0,
/* 608 */	0,
/* 609 */	0,
/* 610 */	0,
/* 611 */	0,
/* 612 */	0,
/* 613 */	0,
/* 614 */	0,
/* 615 */	"VREGP",
};

static char *_templates[] = {
/* 0 */	0,
/* 1 */	"# read register\n",	/* reg: INDIRC(VREGP) */
/* 2 */	"# read register\n",	/* reg: INDIRI(VREGP) */
/* 3 */	"# read register\n",	/* reg: INDIRP(VREGP) */
/* 4 */	"# read register\n",	/* reg: INDIRS(VREGP) */
/* 5 */	"# read register\n",	/* freg: INDIRD(VREGP) */
/* 6 */	"# read register\n",	/* freg: INDIRF(VREGP) */
/* 7 */	"# write register\n",	/* stmt: ASGNC(VREGP,reg) */
/* 8 */	"# write register\n",	/* stmt: ASGNI(VREGP,reg) */
/* 9 */	"# write register\n",	/* stmt: ASGNP(VREGP,reg) */
/* 10 */	"# write register\n",	/* stmt: ASGNS(VREGP,reg) */
/* 11 */	"# write register\n",	/* stmt: ASGND(VREGP,freg) */
/* 12 */	"# write register\n",	/* stmt: ASGNF(VREGP,freg) */
/* 13 */	"$%a",	/* con: CNSTC */
/* 14 */	"$%a",	/* con: CNSTI */
/* 15 */	"$%a",	/* con: CNSTP */
/* 16 */	"$%a",	/* con: CNSTS */
/* 17 */	"$%a",	/* con: CNSTU */
/* 18 */	"",	/* stmt: reg */
/* 19 */	"",	/* stmt: freg */
/* 20 */	"%0",	/* reg: CVIU(reg) */
/* 21 */	"%0",	/* reg: CVPU(reg) */
/* 22 */	"%0",	/* reg: CVUI(reg) */
/* 23 */	"%0",	/* reg: CVUP(reg) */
/* 24 */	"%a",	/* acon: ADDRGP */
/* 25 */	"%a",	/* acon: CNSTC */
/* 26 */	"%a",	/* acon: CNSTI */
/* 27 */	"%a",	/* acon: CNSTP */
/* 28 */	"%a",	/* acon: CNSTS */
/* 29 */	"%a",	/* acon: CNSTU */
/* 30 */	"%a",	/* baseaddr: ADDRGP */
/* 31 */	"(%0)",	/* base: reg */
/* 32 */	"%1(%0)",	/* base: ADDI(reg,acon) */
/* 33 */	"%1(%0)",	/* base: ADDP(reg,acon) */
/* 34 */	"%1(%0)",	/* base: ADDU(reg,acon) */
/* 35 */	"%a(%%ebp)",	/* base: ADDRFP */
/* 36 */	"%a(%%ebp)",	/* base: ADDRLP */
/* 37 */	"1",	/* con1: CNSTI */
/* 38 */	"1",	/* con1: CNSTU */
/* 39 */	"2",	/* icon: CNSTI */
/* 40 */	"2",	/* icon: CNSTU */
/* 41 */	"4",	/* icon: CNSTI */
/* 42 */	"4",	/* icon: CNSTU */
/* 43 */	"8",	/* icon: CNSTI */
/* 44 */	"8",	/* icon: CNSTU */
/* 45 */	"%0",	/* index: reg */
/* 46 */	"%0,%1",	/* index: LSHI(reg,icon) */
/* 47 */	"%0,%1",	/* index: LSHU(reg,icon) */
/* 48 */	"%0",	/* addr: base */
/* 49 */	"%0",	/* addr: baseaddr */
/* 50 */	"%1(,%0)",	/* addr: ADDI(index,baseaddr) */
/* 51 */	"%1(%0)",	/* addr: ADDI(reg,baseaddr) */
/* 52 */	"(%1,%0)",	/* addr: ADDI(index,reg) */
/* 53 */	"%1(,%0)",	/* addr: ADDP(index,baseaddr) */
/* 54 */	"%1(%0)",	/* addr: ADDP(reg,baseaddr) */
/* 55 */	"(%1,%0)",	/* addr: ADDP(index,reg) */
/* 56 */	"%1(,%0)",	/* addr: ADDU(index,baseaddr) */
/* 57 */	"%1(%0)",	/* addr: ADDU(reg,baseaddr) */
/* 58 */	"(%1,%0)",	/* addr: ADDU(index,reg) */
/* 59 */	"(,%0)",	/* addr: index */
/* 60 */	"%0",	/* memb: INDIRC(addr) */
/* 61 */	"%0",	/* memw: INDIRS(addr) */
/* 62 */	"%0",	/* mem: INDIRI(addr) */
/* 63 */	"%0",	/* mem: INDIRP(addr) */
/* 64 */	"$%a",	/* rc5: CNSTI */
/* 65 */	"%%cl",	/* rc5: reg */
/* 66 */	"%0",	/* rc: reg */
/* 67 */	"%0",	/* rc: con */
/* 68 */	"%0",	/* mr: reg */
/* 69 */	"%0",	/* mr: mem */
/* 70 */	"%0",	/* mrb: reg */
/* 71 */	"%0",	/* mrb: memb */
/* 72 */	"%0",	/* mrw: reg */
/* 73 */	"%0",	/* mrw: memw */
/* 74 */	"%0",	/* mrc: mem */
/* 75 */	"%0",	/* mrc: memb */
/* 76 */	"%0",	/* mrc: memw */
/* 77 */	"%0",	/* mrc: rc */
/* 78 */	"\tleal\t%0,%c\n",	/* reg: addr */
/* 79 */	"\tmovl\t%0,%c\n",	/* reg: mr */
/* 80 */	"\tmovb\t%0,%c\n",	/* reg: mrb */
/* 81 */	"\tmovw\t%0,%c\n",	/* reg: mrw */
/* 82 */	"\tmovl\t%0,%c\n",	/* reg: con */
/* 83 */	"\tmovb\t%0,%c\n",	/* reg: LOADC(reg) */
/* 84 */	"\tmovl\t%0,%c\n",	/* reg: LOADI(reg) */
/* 85 */	"\tmovl\t%0,%c\n",	/* reg: LOADP(reg) */
/* 86 */	"\tmovw\t%0,%c\n",	/* reg: LOADS(reg) */
/* 87 */	"\tmovl\t%0,%c\n",	/* reg: LOADU(reg) */
/* 88 */	"?\tmovl\t%0,%c\n\taddl\t%1,%c\n",	/* reg: ADDI(reg,mrc) */
/* 89 */	"?\tmovl\t%0,%c\n\taddl\t%1,%c\n",	/* reg: ADDP(reg,mrc) */
/* 90 */	"?\tmovl\t%0,%c\n\taddl\t%1,%c\n",	/* reg: ADDU(reg,mrc) */
/* 91 */	"?\tmovl\t%0,%c\n\tsubl\t%1,%c\n",	/* reg: SUBI(reg,mrc) */
/* 92 */	"?\tmovl\t%0,%c\n\tsubl\t%1,%c\n",	/* reg: SUBP(reg,mrc) */
/* 93 */	"?\tmovl\t%0,%c\n\tsubl\t%1,%c\n",	/* reg: SUBU(reg,mrc) */
/* 94 */	"?\tmovl\t%0,%c\n\tandl\t%1,%c\n",	/* reg: BANDU(reg,mrc) */
/* 95 */	"?\tmovl\t%0,%c\n\torl\t%1,%c\n",	/* reg: BORU(reg,mrc) */
/* 96 */	"?\tmovl\t%0,%c\n\txorl\t%1,%c\n",	/* reg: BXORU(reg,mrc) */
/* 97 */	"?\tmovl\t%0,%c\n\tsall\t%1,%c\n",	/* reg: LSHI(reg,rc5) */
/* 98 */	"?\tmovl\t%0,%c\n\tshll\t%1,%c\n",	/* reg: LSHU(reg,rc5) */
/* 99 */	"?\tmovl\t%0,%c\n\tsarl\t%1,%c\n",	/* reg: RSHI(reg,rc5) */
/* 100 */	"?\tmovl\t%0,%c\n\tshrl\t%1,%c\n",	/* reg: RSHU(reg,rc5) */
/* 101 */	"?\tmovl\t%0,%c\n\tnotl\t%c\n",	/* reg: BCOMU(reg) */
/* 102 */	"?\tmovl\t%0,%c\n\tnegl\t%c\n",	/* reg: NEGI(reg) */
/* 103 */	"\tincl\t%1\n",	/* stmt: ASGNI(addr,ADDI(mem,con1)) */
/* 104 */	"\tincl\t%1\n",	/* stmt: ASGNI(addr,ADDU(mem,con1)) */
/* 105 */	"\tincl\t%1\n",	/* stmt: ASGNP(addr,ADDP(mem,con1)) */
/* 106 */	"\tdecl\t%1\n",	/* stmt: ASGNI(addr,SUBI(mem,con1)) */
/* 107 */	"\tdecl\t%1\n",	/* stmt: ASGNI(addr,SUBU(mem,con1)) */
/* 108 */	"\tdecl\t%1\n",	/* stmt: ASGNP(addr,SUBP(mem,con1)) */
/* 109 */	"\taddl\t%2,%1\n",	/* stmt: ASGNI(addr,ADDI(mem,rc)) */
/* 110 */	"\taddl\t%2,%1\n",	/* stmt: ASGNI(addr,ADDU(mem,rc)) */
/* 111 */	"\tsubl\t%2,%1\n",	/* stmt: ASGNI(addr,SUBI(mem,rc)) */
/* 112 */	"\tsubl\t%2,%1\n",	/* stmt: ASGNI(addr,SUBU(mem,rc)) */
/* 113 */	"\tandl\t%2,%1\n",	/* stmt: ASGNI(addr,BANDU(mem,rc)) */
/* 114 */	"\torl\t%2,%1\n",	/* stmt: ASGNI(addr,BORU(mem,rc)) */
/* 115 */	"\txorl\t%2,%1\n",	/* stmt: ASGNI(addr,BXORU(mem,rc)) */
/* 116 */	"\tnotl\t%1\n",	/* stmt: ASGNI(addr,BCOMU(mem)) */
/* 117 */	"\tnegl\t%1\n",	/* stmt: ASGNI(addr,NEGI(mem)) */
/* 118 */	"\tsall\t%2,%1\n",	/* stmt: ASGNI(addr,LSHI(mem,rc5)) */
/* 119 */	"\tshll\t%2,%1\n",	/* stmt: ASGNI(addr,LSHU(mem,rc5)) */
/* 120 */	"\tsarl\t%2,%1\n",	/* stmt: ASGNI(addr,RSHI(mem,rc5)) */
/* 121 */	"\tshrl\t%2,%1\n",	/* stmt: ASGNI(addr,RSHU(mem,rc5)) */
/* 122 */	"?\tmovl\t%0,%c\n\timull\t%1,%c\n",	/* reg: MULI(reg,mrc) */
/* 123 */	"\timul\t%0,%1,%c\n",	/* reg: MULI(con,mr) */
/* 124 */	"\tmull\t%1\n",	/* reg: MULU(reg,mr) */
/* 125 */	"\txorl\t%%edx,%%edx\n\tdivl\t%1\n",	/* reg: DIVU(reg,reg) */
/* 126 */	"\txorl\t%%edx,%%edx\n\tdivl\t%1\n",	/* reg: MODU(reg,reg) */
/* 127 */	"\tcdq\n\tidivl\t%1\n",	/* reg: DIVI(reg,reg) */
/* 128 */	"\tcdq\n\tidivl\t%1\n",	/* reg: MODI(reg,reg) */
/* 129 */	"\tmovl\t%0,%c\n",	/* reg: CVIU(reg) */
/* 130 */	"\tmovl\t%0,%c\n",	/* reg: CVPU(reg) */
/* 131 */	"\tmovl\t%0,%c\n",	/* reg: CVUI(reg) */
/* 132 */	"\tmovl\t%0,%c\n",	/* reg: CVUP(reg) */
/* 133 */	"\tmovsbl\t%0,%c\n",	/* reg: CVCI(INDIRC(addr)) */
/* 134 */	"\tmovzbl\t%0,%c\n",	/* reg: CVCU(INDIRC(addr)) */
/* 135 */	"\tmovswl\t%0,%c\n",	/* reg: CVSI(INDIRS(addr)) */
/* 136 */	"\tmovzwl\t%0,%c\n",	/* reg: CVSU(INDIRS(addr)) */
/* 137 */	"# extend\n",	/* reg: CVCI(reg) */
/* 138 */	"# extend\n",	/* reg: CVCU(reg) */
/* 139 */	"# extend\n",	/* reg: CVSI(reg) */
/* 140 */	"# extend\n",	/* reg: CVSU(reg) */
/* 141 */	"# truncate\n",	/* reg: CVIC(reg) */
/* 142 */	"# truncate\n",	/* reg: CVIS(reg) */
/* 143 */	"# truncate\n",	/* reg: CVUC(reg) */
/* 144 */	"# truncate\n",	/* reg: CVUS(reg) */
/* 145 */	"%0",	/* mrca: mem */
/* 146 */	"%0",	/* mrca: rc */
/* 147 */	"$%a",	/* mrca: ADDRGP */
/* 148 */	"\tmovb\t%1,%0\n",	/* stmt: ASGNC(addr,rc) */
/* 149 */	"\tmovl\t%1,%0\n",	/* stmt: ASGNI(addr,rc) */
/* 150 */	"\tmovl\t%1,%0\n",	/* stmt: ASGNP(addr,rc) */
/* 151 */	"\tmovw\t%1,%0\n",	/* stmt: ASGNS(addr,rc) */
/* 152 */	"\tmovl\t$%a,%%ecx\n\trep\n\tmovsb\n",	/* stmt: ASGNB(reg,INDIRB(reg)) */
/* 153 */	"\tpushl\t%0\n",	/* stmt: ARGI(mrca) */
/* 154 */	"\tpushl\t%0\n",	/* stmt: ARGP(mrca) */
/* 155 */	"\tsubl\t$%a,%%esp\n\tmovl\t%%esp,%%edi\n\tmovl\t$%a,%%ecx\n\trep\n\tmovsb\n",	/* stmt: ARGB(INDIRB(reg)) */
/* 156 */	"l\t%0",	/* memf: INDIRD(addr) */
/* 157 */	"s\t%0",	/* memf: INDIRF(addr) */
/* 158 */	"s\t%0",	/* memf: CVFD(INDIRF(addr)) */
/* 159 */	"\tfld%0\n",	/* freg: memf */
/* 160 */	"\tfstpl\t%0\n",	/* stmt: ASGND(addr,freg) */
/* 161 */	"\tfstps\t%0\n",	/* stmt: ASGNF(addr,freg) */
/* 162 */	"\tfstps\t%0\n",	/* stmt: ASGNF(addr,CVDF(freg)) */
/* 163 */	"\tsubl\t$8,%%esp\n\tfstpl\t(%%esp)\n",	/* stmt: ARGD(freg) */
/* 164 */	"\tsubl\t$4,%%esp\n\tfstps\t(%%esp)\n",	/* stmt: ARGF(freg) */
/* 165 */	"\tfchs\n",	/* freg: NEGD(freg) */
/* 166 */	"\tfchs\n",	/* freg: NEGF(freg) */
/* 167 */	"%0",	/* flt: memf */
/* 168 */	"p\t%%st,%%st(1)",	/* flt: freg */
/* 169 */	"\tfadd%1\n",	/* freg: ADDD(freg,flt) */
/* 170 */	"\tfadd%1\n",	/* freg: ADDF(freg,flt) */
/* 171 */	"\tfdiv%1\n",	/* freg: DIVD(freg,memf) */
/* 172 */	"\tfdivrp\t%%st,%%st(1)\n",	/* freg: DIVD(freg,freg) */
/* 173 */	"\tfdiv%1\n",	/* freg: DIVF(freg,memf) */
/* 174 */	"\tfdivrp\t%%st,%%st(1)\n",	/* freg: DIVF(freg,freg) */
/* 175 */	"\tfmul%1\n",	/* freg: MULD(freg,flt) */
/* 176 */	"\tfmul%1\n",	/* freg: MULF(freg,flt) */
/* 177 */	"\tfsub%1\n",	/* freg: SUBD(freg,memf) */
/* 178 */	"\tfsubrp\t%%st,%%st(1)\n",	/* freg: SUBD(freg,freg) */
/* 179 */	"\tfsub%1\n",	/* freg: SUBF(freg,memf) */
/* 180 */	"\tfsubrp\t%%st,%%st(1)\n",	/* freg: SUBF(freg,freg) */
/* 181 */	"# CVFD\n",	/* freg: CVFD(freg) */
/* 182 */	"\tsub\t$4,%%esp ; fstps (%%esp) ; flds (%%esp) ; addl $4,%%esp\n",	/* freg: CVDF(freg) */
/* 183 */	"\tfistpl\t%0\n",	/* stmt: ASGNI(addr,CVDI(freg)) */
/* 184 */	"\tsubl\t$4,%%esp\n\tfistpl\t0(%%esp)\n\tpopl\t%c\n",	/* reg: CVDI(freg) */
/* 185 */	"\tfildl\t%0\n",	/* freg: CVID(INDIRI(addr)) */
/* 186 */	"\tpushl\t%0\n\tfildl\t(%%esp)\n\taddl\t$4,%%esp\n",	/* freg: CVID(reg) */
/* 187 */	"%a",	/* addrj: ADDRGP */
/* 188 */	"*%0",	/* addrj: reg */
/* 189 */	"*%0",	/* addrj: mem */
/* 190 */	"%a",	/* addrjmp: ADDRGP */
/* 191 */	"*%0",	/* addrjmp: reg */
/* 192 */	"*%0",	/* addrjmp: mem */
/* 193 */	"%a:\n",	/* stmt: LABELV */
/* 194 */	"\tjmp\t%0\n",	/* stmt: JUMPV(addrjmp) */
/* 195 */	"\tcmpl\t%1,%0\n\tje\t%a\n",	/* stmt: EQI(mem,rc) */
/* 196 */	"\tcmpl\t%1,%0\n\tjge\t%a\n",	/* stmt: GEI(mem,rc) */
/* 197 */	"\tcmpl\t%1,%0\n\tjg\t%a\n",	/* stmt: GTI(mem,rc) */
/* 198 */	"\tcmpl\t%1,%0\n\tjle\t%a\n",	/* stmt: LEI(mem,rc) */
/* 199 */	"\tcmpl\t%1,%0\n\tjl\t%a\n",	/* stmt: LTI(mem,rc) */
/* 200 */	"\tcmpl\t%1,%0\n\tjne\t%a\n",	/* stmt: NEI(mem,rc) */
/* 201 */	"\tcmpl\t%1,%0\n\tjae\t%a\n",	/* stmt: GEU(mem,rc) */
/* 202 */	"\tcmpl\t%1,%0\n\tja \t%a\n",	/* stmt: GTU(mem,rc) */
/* 203 */	"\tcmpl\t%1,%0\n\tjbe\t%a\n",	/* stmt: LEU(mem,rc) */
/* 204 */	"\tcmpl\t%1,%0\n\tjb \t%a\n",	/* stmt: LTU(mem,rc) */
/* 205 */	"\tcmpl\t%1,%0\n\tje\t%a\n",	/* stmt: EQI(reg,mrc) */
/* 206 */	"\tcmpl\t%1,%0\n\tjge\t%a\n",	/* stmt: GEI(reg,mrc) */
/* 207 */	"\tcmpl\t%1,%0\n\tjg\t%a\n",	/* stmt: GTI(reg,mrc) */
/* 208 */	"\tcmpl\t%1,%0\n\tjle\t%a\n",	/* stmt: LEI(reg,mrc) */
/* 209 */	"\tcmpl\t%1,%0\n\tjl\t%a\n",	/* stmt: LTI(reg,mrc) */
/* 210 */	"\tcmpl\t%1,%0\n\tjne\t%a\n",	/* stmt: NEI(reg,mrc) */
/* 211 */	"\tcmpl\t%1,%0\n\tjae\t%a\n",	/* stmt: GEU(reg,mrc) */
/* 212 */	"\tcmpl\t%1,%0\n\tja \t%a\n",	/* stmt: GTU(reg,mrc) */
/* 213 */	"\tcmpl\t%1,%0\n\tjbe\t%a\n",	/* stmt: LEU(reg,mrc) */
/* 214 */	"\tcmpl\t%1,%0\n\tjb \t%a\n",	/* stmt: LTU(reg,mrc) */
/* 215 */	"l\t%0",	/* cmpf: INDIRD(addr) */
/* 216 */	"s\t%0",	/* cmpf: INDIRF(addr) */
/* 217 */	"s\t%0",	/* cmpf: CVFD(INDIRF(addr)) */
/* 218 */	"p",	/* cmpf: freg */
/* 219 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tje\t%a\n",	/* stmt: EQD(cmpf,freg) */
/* 220 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjbe\t%a\n",	/* stmt: GED(cmpf,freg) */
/* 221 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjb\t%a\n",	/* stmt: GTD(cmpf,freg) */
/* 222 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjae\t%a\n",	/* stmt: LED(cmpf,freg) */
/* 223 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tja\t%a\n",	/* stmt: LTD(cmpf,freg) */
/* 224 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjne\t%a\n",	/* stmt: NED(cmpf,freg) */
/* 225 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tje\t%a\n",	/* stmt: EQF(cmpf,freg) */
/* 226 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjbe\t%a\n",	/* stmt: GEF(cmpf,freg) */
/* 227 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjb\t%a\n",	/* stmt: GTF(cmpf,freg) */
/* 228 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjae\t%a\n",	/* stmt: LEF(cmpf,freg) */
/* 229 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tja\t%a\n",	/* stmt: LTF(cmpf,freg) */
/* 230 */	"\tfcomp%0 ; fstsw %%ax ; sahf\n\tjne\t%a\n",	/* stmt: NEF(cmpf,freg) */
/* 231 */	"\tcall\t%0\n\taddl\t$%a,%%esp\n",	/* reg: CALLI(addrj) */
/* 232 */	"\tcall\t%0\n",	/* reg: CALLI(addrj) */
/* 233 */	"\tcall\t%0\n\taddl\t$%a,%%esp\n",	/* stmt: CALLV(addrj) */
/* 234 */	"\tcall\t%0\n",	/* stmt: CALLV(addrj) */
/* 235 */	"\tcall\t%0\n\taddl\t$%a,%%esp\n",	/* freg: CALLF(addrj) */
/* 236 */	"\tcall\t%0\n",	/* freg: CALLF(addrj) */
/* 237 */	"\tcall\t%0\n\taddl\t$%a,%%esp\n\tfstp\t%%st(0)\n",	/* stmt: CALLF(addrj) */
/* 238 */	"\tcall\t%0\n\tfstp\t%%st(0)\n",	/* stmt: CALLF(addrj) */
/* 239 */	"\tcall\t%0\n\taddl\t$%a,%%esp\n",	/* freg: CALLD(addrj) */
/* 240 */	"\tcall\t%0\n",	/* freg: CALLD(addrj) */
/* 241 */	"\tcall\t%0\n\taddl\t$%a,%%esp\n\tfstp\t%%st(0)\n",	/* stmt: CALLD(addrj) */
/* 242 */	"\tcall\t%0\n\tfstp\t%%st(0)\n",	/* stmt: CALLD(addrj) */
/* 243 */	"# ret\n",	/* stmt: RETI(reg) */
/* 244 */	"# retf\n",	/* stmt: RETF(freg) */
/* 245 */	"# retd\n",	/* stmt: RETD(freg) */
};

static char _isinstruction[] = {
/* 0 */	0,
/* 1 */	1,	/* # read register\n */
/* 2 */	1,	/* # read register\n */
/* 3 */	1,	/* # read register\n */
/* 4 */	1,	/* # read register\n */
/* 5 */	1,	/* # read register\n */
/* 6 */	1,	/* # read register\n */
/* 7 */	1,	/* # write register\n */
/* 8 */	1,	/* # write register\n */
/* 9 */	1,	/* # write register\n */
/* 10 */	1,	/* # write register\n */
/* 11 */	1,	/* # write register\n */
/* 12 */	1,	/* # write register\n */
/* 13 */	0,	/* $%a */
/* 14 */	0,	/* $%a */
/* 15 */	0,	/* $%a */
/* 16 */	0,	/* $%a */
/* 17 */	0,	/* $%a */
/* 18 */	0,	/*  */
/* 19 */	0,	/*  */
/* 20 */	0,	/* %0 */
/* 21 */	0,	/* %0 */
/* 22 */	0,	/* %0 */
/* 23 */	0,	/* %0 */
/* 24 */	0,	/* %a */
/* 25 */	0,	/* %a */
/* 26 */	0,	/* %a */
/* 27 */	0,	/* %a */
/* 28 */	0,	/* %a */
/* 29 */	0,	/* %a */
/* 30 */	0,	/* %a */
/* 31 */	0,	/* (%0) */
/* 32 */	0,	/* %1(%0) */
/* 33 */	0,	/* %1(%0) */
/* 34 */	0,	/* %1(%0) */
/* 35 */	0,	/* %a(%%ebp) */
/* 36 */	0,	/* %a(%%ebp) */
/* 37 */	0,	/* 1 */
/* 38 */	0,	/* 1 */
/* 39 */	0,	/* 2 */
/* 40 */	0,	/* 2 */
/* 41 */	0,	/* 4 */
/* 42 */	0,	/* 4 */
/* 43 */	0,	/* 8 */
/* 44 */	0,	/* 8 */
/* 45 */	0,	/* %0 */
/* 46 */	0,	/* %0,%1 */
/* 47 */	0,	/* %0,%1 */
/* 48 */	0,	/* %0 */
/* 49 */	0,	/* %0 */
/* 50 */	0,	/* %1(,%0) */
/* 51 */	0,	/* %1(%0) */
/* 52 */	0,	/* (%1,%0) */
/* 53 */	0,	/* %1(,%0) */
/* 54 */	0,	/* %1(%0) */
/* 55 */	0,	/* (%1,%0) */
/* 56 */	0,	/* %1(,%0) */
/* 57 */	0,	/* %1(%0) */
/* 58 */	0,	/* (%1,%0) */
/* 59 */	0,	/* (,%0) */
/* 60 */	0,	/* %0 */
/* 61 */	0,	/* %0 */
/* 62 */	0,	/* %0 */
/* 63 */	0,	/* %0 */
/* 64 */	0,	/* $%a */
/* 65 */	0,	/* %%cl */
/* 66 */	0,	/* %0 */
/* 67 */	0,	/* %0 */
/* 68 */	0,	/* %0 */
/* 69 */	0,	/* %0 */
/* 70 */	0,	/* %0 */
/* 71 */	0,	/* %0 */
/* 72 */	0,	/* %0 */
/* 73 */	0,	/* %0 */
/* 74 */	0,	/* %0 */
/* 75 */	0,	/* %0 */
/* 76 */	0,	/* %0 */
/* 77 */	0,	/* %0 */
/* 78 */	1,	/* \tleal\t%0,%c\n */
/* 79 */	1,	/* \tmovl\t%0,%c\n */
/* 80 */	1,	/* \tmovb\t%0,%c\n */
/* 81 */	1,	/* \tmovw\t%0,%c\n */
/* 82 */	1,	/* \tmovl\t%0,%c\n */
/* 83 */	1,	/* \tmovb\t%0,%c\n */
/* 84 */	1,	/* \tmovl\t%0,%c\n */
/* 85 */	1,	/* \tmovl\t%0,%c\n */
/* 86 */	1,	/* \tmovw\t%0,%c\n */
/* 87 */	1,	/* \tmovl\t%0,%c\n */
/* 88 */	1,	/* ?\tmovl\t%0,%c\n\taddl\t%1,%c\n */
/* 89 */	1,	/* ?\tmovl\t%0,%c\n\taddl\t%1,%c\n */
/* 90 */	1,	/* ?\tmovl\t%0,%c\n\taddl\t%1,%c\n */
/* 91 */	1,	/* ?\tmovl\t%0,%c\n\tsubl\t%1,%c\n */
/* 92 */	1,	/* ?\tmovl\t%0,%c\n\tsubl\t%1,%c\n */
/* 93 */	1,	/* ?\tmovl\t%0,%c\n\tsubl\t%1,%c\n */
/* 94 */	1,	/* ?\tmovl\t%0,%c\n\tandl\t%1,%c\n */
/* 95 */	1,	/* ?\tmovl\t%0,%c\n\torl\t%1,%c\n */
/* 96 */	1,	/* ?\tmovl\t%0,%c\n\txorl\t%1,%c\n */
/* 97 */	1,	/* ?\tmovl\t%0,%c\n\tsall\t%1,%c\n */
/* 98 */	1,	/* ?\tmovl\t%0,%c\n\tshll\t%1,%c\n */
/* 99 */	1,	/* ?\tmovl\t%0,%c\n\tsarl\t%1,%c\n */
/* 100 */	1,	/* ?\tmovl\t%0,%c\n\tshrl\t%1,%c\n */
/* 101 */	1,	/* ?\tmovl\t%0,%c\n\tnotl\t%c\n */
/* 102 */	1,	/* ?\tmovl\t%0,%c\n\tnegl\t%c\n */
/* 103 */	1,	/* \tincl\t%1\n */
/* 104 */	1,	/* \tincl\t%1\n */
/* 105 */	1,	/* \tincl\t%1\n */
/* 106 */	1,	/* \tdecl\t%1\n */
/* 107 */	1,	/* \tdecl\t%1\n */
/* 108 */	1,	/* \tdecl\t%1\n */
/* 109 */	1,	/* \taddl\t%2,%1\n */
/* 110 */	1,	/* \taddl\t%2,%1\n */
/* 111 */	1,	/* \tsubl\t%2,%1\n */
/* 112 */	1,	/* \tsubl\t%2,%1\n */
/* 113 */	1,	/* \tandl\t%2,%1\n */
/* 114 */	1,	/* \torl\t%2,%1\n */
/* 115 */	1,	/* \txorl\t%2,%1\n */
/* 116 */	1,	/* \tnotl\t%1\n */
/* 117 */	1,	/* \tnegl\t%1\n */
/* 118 */	1,	/* \tsall\t%2,%1\n */
/* 119 */	1,	/* \tshll\t%2,%1\n */
/* 120 */	1,	/* \tsarl\t%2,%1\n */
/* 121 */	1,	/* \tshrl\t%2,%1\n */
/* 122 */	1,	/* ?\tmovl\t%0,%c\n\timull\t%1,%c\n */
/* 123 */	1,	/* \timul\t%0,%1,%c\n */
/* 124 */	1,	/* \tmull\t%1\n */
/* 125 */	1,	/* \txorl\t%%edx,%%edx\n\tdivl\t%1\n */
/* 126 */	1,	/* \txorl\t%%edx,%%edx\n\tdivl\t%1\n */
/* 127 */	1,	/* \tcdq\n\tidivl\t%1\n */
/* 128 */	1,	/* \tcdq\n\tidivl\t%1\n */
/* 129 */	1,	/* \tmovl\t%0,%c\n */
/* 130 */	1,	/* \tmovl\t%0,%c\n */
/* 131 */	1,	/* \tmovl\t%0,%c\n */
/* 132 */	1,	/* \tmovl\t%0,%c\n */
/* 133 */	1,	/* \tmovsbl\t%0,%c\n */
/* 134 */	1,	/* \tmovzbl\t%0,%c\n */
/* 135 */	1,	/* \tmovswl\t%0,%c\n */
/* 136 */	1,	/* \tmovzwl\t%0,%c\n */
/* 137 */	1,	/* # extend\n */
/* 138 */	1,	/* # extend\n */
/* 139 */	1,	/* # extend\n */
/* 140 */	1,	/* # extend\n */
/* 141 */	1,	/* # truncate\n */
/* 142 */	1,	/* # truncate\n */
/* 143 */	1,	/* # truncate\n */
/* 144 */	1,	/* # truncate\n */
/* 145 */	0,	/* %0 */
/* 146 */	0,	/* %0 */
/* 147 */	0,	/* $%a */
/* 148 */	1,	/* \tmovb\t%1,%0\n */
/* 149 */	1,	/* \tmovl\t%1,%0\n */
/* 150 */	1,	/* \tmovl\t%1,%0\n */
/* 151 */	1,	/* \tmovw\t%1,%0\n */
/* 152 */	1,	/* \tmovl\t$%a,%%ecx\n\trep\n\tmovsb\n */
/* 153 */	1,	/* \tpushl\t%0\n */
/* 154 */	1,	/* \tpushl\t%0\n */
/* 155 */	1,	/* \tsubl\t$%a,%%esp\n\tmovl\t%%esp,%%edi\n\tmovl\t$%a,%%ecx\n\trep\n\tmovsb\n */
/* 156 */	0,	/* l\t%0 */
/* 157 */	0,	/* s\t%0 */
/* 158 */	0,	/* s\t%0 */
/* 159 */	1,	/* \tfld%0\n */
/* 160 */	1,	/* \tfstpl\t%0\n */
/* 161 */	1,	/* \tfstps\t%0\n */
/* 162 */	1,	/* \tfstps\t%0\n */
/* 163 */	1,	/* \tsubl\t$8,%%esp\n\tfstpl\t(%%esp)\n */
/* 164 */	1,	/* \tsubl\t$4,%%esp\n\tfstps\t(%%esp)\n */
/* 165 */	1,	/* \tfchs\n */
/* 166 */	1,	/* \tfchs\n */
/* 167 */	0,	/* %0 */
/* 168 */	0,	/* p\t%%st,%%st(1) */
/* 169 */	1,	/* \tfadd%1\n */
/* 170 */	1,	/* \tfadd%1\n */
/* 171 */	1,	/* \tfdiv%1\n */
/* 172 */	1,	/* \tfdivrp\t%%st,%%st(1)\n */
/* 173 */	1,	/* \tfdiv%1\n */
/* 174 */	1,	/* \tfdivrp\t%%st,%%st(1)\n */
/* 175 */	1,	/* \tfmul%1\n */
/* 176 */	1,	/* \tfmul%1\n */
/* 177 */	1,	/* \tfsub%1\n */
/* 178 */	1,	/* \tfsubrp\t%%st,%%st(1)\n */
/* 179 */	1,	/* \tfsub%1\n */
/* 180 */	1,	/* \tfsubrp\t%%st,%%st(1)\n */
/* 181 */	1,	/* # CVFD\n */
/* 182 */	1,	/* \tsub\t$4,%%esp ; fstps (%%esp) ; flds (%%esp) ; addl $4,%%esp\n */
/* 183 */	1,	/* \tfistpl\t%0\n */
/* 184 */	1,	/* \tsubl\t$4,%%esp\n\tfistpl\t0(%%esp)\n\tpopl\t%c\n */
/* 185 */	1,	/* \tfildl\t%0\n */
/* 186 */	1,	/* \tpushl\t%0\n\tfildl\t(%%esp)\n\taddl\t$4,%%esp\n */
/* 187 */	0,	/* %a */
/* 188 */	0,	/* *%0 */
/* 189 */	0,	/* *%0 */
/* 190 */	0,	/* %a */
/* 191 */	0,	/* *%0 */
/* 192 */	0,	/* *%0 */
/* 193 */	1,	/* %a:\n */
/* 194 */	1,	/* \tjmp\t%0\n */
/* 195 */	1,	/* \tcmpl\t%1,%0\n\tje\t%a\n */
/* 196 */	1,	/* \tcmpl\t%1,%0\n\tjge\t%a\n */
/* 197 */	1,	/* \tcmpl\t%1,%0\n\tjg\t%a\n */
/* 198 */	1,	/* \tcmpl\t%1,%0\n\tjle\t%a\n */
/* 199 */	1,	/* \tcmpl\t%1,%0\n\tjl\t%a\n */
/* 200 */	1,	/* \tcmpl\t%1,%0\n\tjne\t%a\n */
/* 201 */	1,	/* \tcmpl\t%1,%0\n\tjae\t%a\n */
/* 202 */	1,	/* \tcmpl\t%1,%0\n\tja \t%a\n */
/* 203 */	1,	/* \tcmpl\t%1,%0\n\tjbe\t%a\n */
/* 204 */	1,	/* \tcmpl\t%1,%0\n\tjb \t%a\n */
/* 205 */	1,	/* \tcmpl\t%1,%0\n\tje\t%a\n */
/* 206 */	1,	/* \tcmpl\t%1,%0\n\tjge\t%a\n */
/* 207 */	1,	/* \tcmpl\t%1,%0\n\tjg\t%a\n */
/* 208 */	1,	/* \tcmpl\t%1,%0\n\tjle\t%a\n */
/* 209 */	1,	/* \tcmpl\t%1,%0\n\tjl\t%a\n */
/* 210 */	1,	/* \tcmpl\t%1,%0\n\tjne\t%a\n */
/* 211 */	1,	/* \tcmpl\t%1,%0\n\tjae\t%a\n */
/* 212 */	1,	/* \tcmpl\t%1,%0\n\tja \t%a\n */
/* 213 */	1,	/* \tcmpl\t%1,%0\n\tjbe\t%a\n */
/* 214 */	1,	/* \tcmpl\t%1,%0\n\tjb \t%a\n */
/* 215 */	0,	/* l\t%0 */
/* 216 */	0,	/* s\t%0 */
/* 217 */	0,	/* s\t%0 */
/* 218 */	0,	/* p */
/* 219 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tje\t%a\n */
/* 220 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjbe\t%a\n */
/* 221 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjb\t%a\n */
/* 222 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjae\t%a\n */
/* 223 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tja\t%a\n */
/* 224 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjne\t%a\n */
/* 225 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tje\t%a\n */
/* 226 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjbe\t%a\n */
/* 227 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjb\t%a\n */
/* 228 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjae\t%a\n */
/* 229 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tja\t%a\n */
/* 230 */	1,	/* \tfcomp%0 ; fstsw %%ax ; sahf\n\tjne\t%a\n */
/* 231 */	1,	/* \tcall\t%0\n\taddl\t$%a,%%esp\n */
/* 232 */	1,	/* \tcall\t%0\n */
/* 233 */	1,	/* \tcall\t%0\n\taddl\t$%a,%%esp\n */
/* 234 */	1,	/* \tcall\t%0\n */
/* 235 */	1,	/* \tcall\t%0\n\taddl\t$%a,%%esp\n */
/* 236 */	1,	/* \tcall\t%0\n */
/* 237 */	1,	/* \tcall\t%0\n\taddl\t$%a,%%esp\n\tfstp\t%%st(0)\n */
/* 238 */	1,	/* \tcall\t%0\n\tfstp\t%%st(0)\n */
/* 239 */	1,	/* \tcall\t%0\n\taddl\t$%a,%%esp\n */
/* 240 */	1,	/* \tcall\t%0\n */
/* 241 */	1,	/* \tcall\t%0\n\taddl\t$%a,%%esp\n\tfstp\t%%st(0)\n */
/* 242 */	1,	/* \tcall\t%0\n\tfstp\t%%st(0)\n */
/* 243 */	1,	/* # ret\n */
/* 244 */	1,	/* # retf\n */
/* 245 */	1,	/* # retd\n */
};

static char *_string[] = {
/* 0 */	0,
/* 1 */	"reg: INDIRC(VREGP)",
/* 2 */	"reg: INDIRI(VREGP)",
/* 3 */	"reg: INDIRP(VREGP)",
/* 4 */	"reg: INDIRS(VREGP)",
/* 5 */	"freg: INDIRD(VREGP)",
/* 6 */	"freg: INDIRF(VREGP)",
/* 7 */	"stmt: ASGNC(VREGP,reg)",
/* 8 */	"stmt: ASGNI(VREGP,reg)",
/* 9 */	"stmt: ASGNP(VREGP,reg)",
/* 10 */	"stmt: ASGNS(VREGP,reg)",
/* 11 */	"stmt: ASGND(VREGP,freg)",
/* 12 */	"stmt: ASGNF(VREGP,freg)",
/* 13 */	"con: CNSTC",
/* 14 */	"con: CNSTI",
/* 15 */	"con: CNSTP",
/* 16 */	"con: CNSTS",
/* 17 */	"con: CNSTU",
/* 18 */	"stmt: reg",
/* 19 */	"stmt: freg",
/* 20 */	"reg: CVIU(reg)",
/* 21 */	"reg: CVPU(reg)",
/* 22 */	"reg: CVUI(reg)",
/* 23 */	"reg: CVUP(reg)",
/* 24 */	"acon: ADDRGP",
/* 25 */	"acon: CNSTC",
/* 26 */	"acon: CNSTI",
/* 27 */	"acon: CNSTP",
/* 28 */	"acon: CNSTS",
/* 29 */	"acon: CNSTU",
/* 30 */	"baseaddr: ADDRGP",
/* 31 */	"base: reg",
/* 32 */	"base: ADDI(reg,acon)",
/* 33 */	"base: ADDP(reg,acon)",
/* 34 */	"base: ADDU(reg,acon)",
/* 35 */	"base: ADDRFP",
/* 36 */	"base: ADDRLP",
/* 37 */	"con1: CNSTI",
/* 38 */	"con1: CNSTU",
/* 39 */	"icon: CNSTI",
/* 40 */	"icon: CNSTU",
/* 41 */	"icon: CNSTI",
/* 42 */	"icon: CNSTU",
/* 43 */	"icon: CNSTI",
/* 44 */	"icon: CNSTU",
/* 45 */	"index: reg",
/* 46 */	"index: LSHI(reg,icon)",
/* 47 */	"index: LSHU(reg,icon)",
/* 48 */	"addr: base",
/* 49 */	"addr: baseaddr",
/* 50 */	"addr: ADDI(index,baseaddr)",
/* 51 */	"addr: ADDI(reg,baseaddr)",
/* 52 */	"addr: ADDI(index,reg)",
/* 53 */	"addr: ADDP(index,baseaddr)",
/* 54 */	"addr: ADDP(reg,baseaddr)",
/* 55 */	"addr: ADDP(index,reg)",
/* 56 */	"addr: ADDU(index,baseaddr)",
/* 57 */	"addr: ADDU(reg,baseaddr)",
/* 58 */	"addr: ADDU(index,reg)",
/* 59 */	"addr: index",
/* 60 */	"memb: INDIRC(addr)",
/* 61 */	"memw: INDIRS(addr)",
/* 62 */	"mem: INDIRI(addr)",
/* 63 */	"mem: INDIRP(addr)",
/* 64 */	"rc5: CNSTI",
/* 65 */	"rc5: reg",
/* 66 */	"rc: reg",
/* 67 */	"rc: con",
/* 68 */	"mr: reg",
/* 69 */	"mr: mem",
/* 70 */	"mrb: reg",
/* 71 */	"mrb: memb",
/* 72 */	"mrw: reg",
/* 73 */	"mrw: memw",
/* 74 */	"mrc: mem",
/* 75 */	"mrc: memb",
/* 76 */	"mrc: memw",
/* 77 */	"mrc: rc",
/* 78 */	"reg: addr",
/* 79 */	"reg: mr",
/* 80 */	"reg: mrb",
/* 81 */	"reg: mrw",
/* 82 */	"reg: con",
/* 83 */	"reg: LOADC(reg)",
/* 84 */	"reg: LOADI(reg)",
/* 85 */	"reg: LOADP(reg)",
/* 86 */	"reg: LOADS(reg)",
/* 87 */	"reg: LOADU(reg)",
/* 88 */	"reg: ADDI(reg,mrc)",
/* 89 */	"reg: ADDP(reg,mrc)",
/* 90 */	"reg: ADDU(reg,mrc)",
/* 91 */	"reg: SUBI(reg,mrc)",
/* 92 */	"reg: SUBP(reg,mrc)",
/* 93 */	"reg: SUBU(reg,mrc)",
/* 94 */	"reg: BANDU(reg,mrc)",
/* 95 */	"reg: BORU(reg,mrc)",
/* 96 */	"reg: BXORU(reg,mrc)",
/* 97 */	"reg: LSHI(reg,rc5)",
/* 98 */	"reg: LSHU(reg,rc5)",
/* 99 */	"reg: RSHI(reg,rc5)",
/* 100 */	"reg: RSHU(reg,rc5)",
/* 101 */	"reg: BCOMU(reg)",
/* 102 */	"reg: NEGI(reg)",
/* 103 */	"stmt: ASGNI(addr,ADDI(mem,con1))",
/* 104 */	"stmt: ASGNI(addr,ADDU(mem,con1))",
/* 105 */	"stmt: ASGNP(addr,ADDP(mem,con1))",
/* 106 */	"stmt: ASGNI(addr,SUBI(mem,con1))",
/* 107 */	"stmt: ASGNI(addr,SUBU(mem,con1))",
/* 108 */	"stmt: ASGNP(addr,SUBP(mem,con1))",
/* 109 */	"stmt: ASGNI(addr,ADDI(mem,rc))",
/* 110 */	"stmt: ASGNI(addr,ADDU(mem,rc))",
/* 111 */	"stmt: ASGNI(addr,SUBI(mem,rc))",
/* 112 */	"stmt: ASGNI(addr,SUBU(mem,rc))",
/* 113 */	"stmt: ASGNI(addr,BANDU(mem,rc))",
/* 114 */	"stmt: ASGNI(addr,BORU(mem,rc))",
/* 115 */	"stmt: ASGNI(addr,BXORU(mem,rc))",
/* 116 */	"stmt: ASGNI(addr,BCOMU(mem))",
/* 117 */	"stmt: ASGNI(addr,NEGI(mem))",
/* 118 */	"stmt: ASGNI(addr,LSHI(mem,rc5))",
/* 119 */	"stmt: ASGNI(addr,LSHU(mem,rc5))",
/* 120 */	"stmt: ASGNI(addr,RSHI(mem,rc5))",
/* 121 */	"stmt: ASGNI(addr,RSHU(mem,rc5))",
/* 122 */	"reg: MULI(reg,mrc)",
/* 123 */	"reg: MULI(con,mr)",
/* 124 */	"reg: MULU(reg,mr)",
/* 125 */	"reg: DIVU(reg,reg)",
/* 126 */	"reg: MODU(reg,reg)",
/* 127 */	"reg: DIVI(reg,reg)",
/* 128 */	"reg: MODI(reg,reg)",
/* 129 */	"reg: CVIU(reg)",
/* 130 */	"reg: CVPU(reg)",
/* 131 */	"reg: CVUI(reg)",
/* 132 */	"reg: CVUP(reg)",
/* 133 */	"reg: CVCI(INDIRC(addr))",
/* 134 */	"reg: CVCU(INDIRC(addr))",
/* 135 */	"reg: CVSI(INDIRS(addr))",
/* 136 */	"reg: CVSU(INDIRS(addr))",
/* 137 */	"reg: CVCI(reg)",
/* 138 */	"reg: CVCU(reg)",
/* 139 */	"reg: CVSI(reg)",
/* 140 */	"reg: CVSU(reg)",
/* 141 */	"reg: CVIC(reg)",
/* 142 */	"reg: CVIS(reg)",
/* 143 */	"reg: CVUC(reg)",
/* 144 */	"reg: CVUS(reg)",
/* 145 */	"mrca: mem",
/* 146 */	"mrca: rc",
/* 147 */	"mrca: ADDRGP",
/* 148 */	"stmt: ASGNC(addr,rc)",
/* 149 */	"stmt: ASGNI(addr,rc)",
/* 150 */	"stmt: ASGNP(addr,rc)",
/* 151 */	"stmt: ASGNS(addr,rc)",
/* 152 */	"stmt: ASGNB(reg,INDIRB(reg))",
/* 153 */	"stmt: ARGI(mrca)",
/* 154 */	"stmt: ARGP(mrca)",
/* 155 */	"stmt: ARGB(INDIRB(reg))",
/* 156 */	"memf: INDIRD(addr)",
/* 157 */	"memf: INDIRF(addr)",
/* 158 */	"memf: CVFD(INDIRF(addr))",
/* 159 */	"freg: memf",
/* 160 */	"stmt: ASGND(addr,freg)",
/* 161 */	"stmt: ASGNF(addr,freg)",
/* 162 */	"stmt: ASGNF(addr,CVDF(freg))",
/* 163 */	"stmt: ARGD(freg)",
/* 164 */	"stmt: ARGF(freg)",
/* 165 */	"freg: NEGD(freg)",
/* 166 */	"freg: NEGF(freg)",
/* 167 */	"flt: memf",
/* 168 */	"flt: freg",
/* 169 */	"freg: ADDD(freg,flt)",
/* 170 */	"freg: ADDF(freg,flt)",
/* 171 */	"freg: DIVD(freg,memf)",
/* 172 */	"freg: DIVD(freg,freg)",
/* 173 */	"freg: DIVF(freg,memf)",
/* 174 */	"freg: DIVF(freg,freg)",
/* 175 */	"freg: MULD(freg,flt)",
/* 176 */	"freg: MULF(freg,flt)",
/* 177 */	"freg: SUBD(freg,memf)",
/* 178 */	"freg: SUBD(freg,freg)",
/* 179 */	"freg: SUBF(freg,memf)",
/* 180 */	"freg: SUBF(freg,freg)",
/* 181 */	"freg: CVFD(freg)",
/* 182 */	"freg: CVDF(freg)",
/* 183 */	"stmt: ASGNI(addr,CVDI(freg))",
/* 184 */	"reg: CVDI(freg)",
/* 185 */	"freg: CVID(INDIRI(addr))",
/* 186 */	"freg: CVID(reg)",
/* 187 */	"addrj: ADDRGP",
/* 188 */	"addrj: reg",
/* 189 */	"addrj: mem",
/* 190 */	"addrjmp: ADDRGP",
/* 191 */	"addrjmp: reg",
/* 192 */	"addrjmp: mem",
/* 193 */	"stmt: LABELV",
/* 194 */	"stmt: JUMPV(addrjmp)",
/* 195 */	"stmt: EQI(mem,rc)",
/* 196 */	"stmt: GEI(mem,rc)",
/* 197 */	"stmt: GTI(mem,rc)",
/* 198 */	"stmt: LEI(mem,rc)",
/* 199 */	"stmt: LTI(mem,rc)",
/* 200 */	"stmt: NEI(mem,rc)",
/* 201 */	"stmt: GEU(mem,rc)",
/* 202 */	"stmt: GTU(mem,rc)",
/* 203 */	"stmt: LEU(mem,rc)",
/* 204 */	"stmt: LTU(mem,rc)",
/* 205 */	"stmt: EQI(reg,mrc)",
/* 206 */	"stmt: GEI(reg,mrc)",
/* 207 */	"stmt: GTI(reg,mrc)",
/* 208 */	"stmt: LEI(reg,mrc)",
/* 209 */	"stmt: LTI(reg,mrc)",
/* 210 */	"stmt: NEI(reg,mrc)",
/* 211 */	"stmt: GEU(reg,mrc)",
/* 212 */	"stmt: GTU(reg,mrc)",
/* 213 */	"stmt: LEU(reg,mrc)",
/* 214 */	"stmt: LTU(reg,mrc)",
/* 215 */	"cmpf: INDIRD(addr)",
/* 216 */	"cmpf: INDIRF(addr)",
/* 217 */	"cmpf: CVFD(INDIRF(addr))",
/* 218 */	"cmpf: freg",
/* 219 */	"stmt: EQD(cmpf,freg)",
/* 220 */	"stmt: GED(cmpf,freg)",
/* 221 */	"stmt: GTD(cmpf,freg)",
/* 222 */	"stmt: LED(cmpf,freg)",
/* 223 */	"stmt: LTD(cmpf,freg)",
/* 224 */	"stmt: NED(cmpf,freg)",
/* 225 */	"stmt: EQF(cmpf,freg)",
/* 226 */	"stmt: GEF(cmpf,freg)",
/* 227 */	"stmt: GTF(cmpf,freg)",
/* 228 */	"stmt: LEF(cmpf,freg)",
/* 229 */	"stmt: LTF(cmpf,freg)",
/* 230 */	"stmt: NEF(cmpf,freg)",
/* 231 */	"reg: CALLI(addrj)",
/* 232 */	"reg: CALLI(addrj)",
/* 233 */	"stmt: CALLV(addrj)",
/* 234 */	"stmt: CALLV(addrj)",
/* 235 */	"freg: CALLF(addrj)",
/* 236 */	"freg: CALLF(addrj)",
/* 237 */	"stmt: CALLF(addrj)",
/* 238 */	"stmt: CALLF(addrj)",
/* 239 */	"freg: CALLD(addrj)",
/* 240 */	"freg: CALLD(addrj)",
/* 241 */	"stmt: CALLD(addrj)",
/* 242 */	"stmt: CALLD(addrj)",
/* 243 */	"stmt: RETI(reg)",
/* 244 */	"stmt: RETF(freg)",
/* 245 */	"stmt: RETD(freg)",
};

static short _decode_stmt[] = {
	0,
	7,
	8,
	9,
	10,
	11,
	12,
	18,
	19,
	103,
	104,
	105,
	106,
	107,
	108,
	109,
	110,
	111,
	112,
	113,
	114,
	115,
	116,
	117,
	118,
	119,
	120,
	121,
	148,
	149,
	150,
	151,
	152,
	153,
	154,
	155,
	160,
	161,
	162,
	163,
	164,
	183,
	193,
	194,
	195,
	196,
	197,
	198,
	199,
	200,
	201,
	202,
	203,
	204,
	205,
	206,
	207,
	208,
	209,
	210,
	211,
	212,
	213,
	214,
	219,
	220,
	221,
	222,
	223,
	224,
	225,
	226,
	227,
	228,
	229,
	230,
	233,
	234,
	237,
	238,
	241,
	242,
	243,
	244,
	245,
};

static short _decode_reg[] = {
	0,
	1,
	2,
	3,
	4,
	20,
	21,
	22,
	23,
	78,
	79,
	80,
	81,
	82,
	83,
	84,
	85,
	86,
	87,
	88,
	89,
	90,
	91,
	92,
	93,
	94,
	95,
	96,
	97,
	98,
	99,
	100,
	101,
	102,
	122,
	123,
	124,
	125,
	126,
	127,
	128,
	129,
	130,
	131,
	132,
	133,
	134,
	135,
	136,
	137,
	138,
	139,
	140,
	141,
	142,
	143,
	144,
	184,
	231,
	232,
};

static short _decode_freg[] = {
	0,
	5,
	6,
	159,
	165,
	166,
	169,
	170,
	171,
	172,
	173,
	174,
	175,
	176,
	177,
	178,
	179,
	180,
	181,
	182,
	185,
	186,
	235,
	236,
	239,
	240,
};

static short _decode_con[] = {
	0,
	13,
	14,
	15,
	16,
	17,
};

static short _decode_acon[] = {
	0,
	24,
	25,
	26,
	27,
	28,
	29,
};

static short _decode_baseaddr[] = {
	0,
	30,
};

static short _decode_base[] = {
	0,
	31,
	32,
	33,
	34,
	35,
	36,
};

static short _decode_con1[] = {
	0,
	37,
	38,
};

static short _decode_icon[] = {
	0,
	39,
	40,
	41,
	42,
	43,
	44,
};

static short _decode_index[] = {
	0,
	45,
	46,
	47,
};

static short _decode_addr[] = {
	0,
	48,
	49,
	50,
	51,
	52,
	53,
	54,
	55,
	56,
	57,
	58,
	59,
};

static short _decode_memb[] = {
	0,
	60,
};

static short _decode_memw[] = {
	0,
	61,
};

static short _decode_mem[] = {
	0,
	62,
	63,
};

static short _decode_rc5[] = {
	0,
	64,
	65,
};

static short _decode_rc[] = {
	0,
	66,
	67,
};

static short _decode_mr[] = {
	0,
	68,
	69,
};

static short _decode_mrb[] = {
	0,
	70,
	71,
};

static short _decode_mrw[] = {
	0,
	72,
	73,
};

static short _decode_mrc[] = {
	0,
	74,
	75,
	76,
	77,
};

static short _decode_mrca[] = {
	0,
	145,
	146,
	147,
};

static short _decode_memf[] = {
	0,
	156,
	157,
	158,
};

static short _decode_flt[] = {
	0,
	167,
	168,
};

static short _decode_addrj[] = {
	0,
	187,
	188,
	189,
};

static short _decode_addrjmp[] = {
	0,
	190,
	191,
	192,
};

static short _decode_cmpf[] = {
	0,
	215,
	216,
	217,
	218,
};

static int _rule(state, goalnt) void *state; int goalnt; {
	if (goalnt < 1 || goalnt > 26)
		fatal("_rule", "Bad goal nonterminal %d\n", goalnt);
	if (!state)
		return 0;
	switch (goalnt) {
	case _stmt_NT:	return _decode_stmt[((struct _state *)state)->rule._stmt];
	case _reg_NT:	return _decode_reg[((struct _state *)state)->rule._reg];
	case _freg_NT:	return _decode_freg[((struct _state *)state)->rule._freg];
	case _con_NT:	return _decode_con[((struct _state *)state)->rule._con];
	case _acon_NT:	return _decode_acon[((struct _state *)state)->rule._acon];
	case _baseaddr_NT:	return _decode_baseaddr[((struct _state *)state)->rule._baseaddr];
	case _base_NT:	return _decode_base[((struct _state *)state)->rule._base];
	case _con1_NT:	return _decode_con1[((struct _state *)state)->rule._con1];
	case _icon_NT:	return _decode_icon[((struct _state *)state)->rule._icon];
	case _index_NT:	return _decode_index[((struct _state *)state)->rule._index];
	case _addr_NT:	return _decode_addr[((struct _state *)state)->rule._addr];
	case _memb_NT:	return _decode_memb[((struct _state *)state)->rule._memb];
	case _memw_NT:	return _decode_memw[((struct _state *)state)->rule._memw];
	case _mem_NT:	return _decode_mem[((struct _state *)state)->rule._mem];
	case _rc5_NT:	return _decode_rc5[((struct _state *)state)->rule._rc5];
	case _rc_NT:	return _decode_rc[((struct _state *)state)->rule._rc];
	case _mr_NT:	return _decode_mr[((struct _state *)state)->rule._mr];
	case _mrb_NT:	return _decode_mrb[((struct _state *)state)->rule._mrb];
	case _mrw_NT:	return _decode_mrw[((struct _state *)state)->rule._mrw];
	case _mrc_NT:	return _decode_mrc[((struct _state *)state)->rule._mrc];
	case _mrca_NT:	return _decode_mrca[((struct _state *)state)->rule._mrca];
	case _memf_NT:	return _decode_memf[((struct _state *)state)->rule._memf];
	case _flt_NT:	return _decode_flt[((struct _state *)state)->rule._flt];
	case _addrj_NT:	return _decode_addrj[((struct _state *)state)->rule._addrj];
	case _addrjmp_NT:	return _decode_addrjmp[((struct _state *)state)->rule._addrjmp];
	case _cmpf_NT:	return _decode_cmpf[((struct _state *)state)->rule._cmpf];
	default:
		fatal("_rule", "Bad goal nonterminal %d\n", goalnt);
		return 0;
	}
}

static void _closure_reg ARGS((NODEPTR_TYPE, int));
static void _closure_freg ARGS((NODEPTR_TYPE, int));
static void _closure_con ARGS((NODEPTR_TYPE, int));
static void _closure_baseaddr ARGS((NODEPTR_TYPE, int));
static void _closure_base ARGS((NODEPTR_TYPE, int));
static void _closure_index ARGS((NODEPTR_TYPE, int));
static void _closure_addr ARGS((NODEPTR_TYPE, int));
static void _closure_memb ARGS((NODEPTR_TYPE, int));
static void _closure_memw ARGS((NODEPTR_TYPE, int));
static void _closure_mem ARGS((NODEPTR_TYPE, int));
static void _closure_rc ARGS((NODEPTR_TYPE, int));
static void _closure_mr ARGS((NODEPTR_TYPE, int));
static void _closure_mrb ARGS((NODEPTR_TYPE, int));
static void _closure_mrw ARGS((NODEPTR_TYPE, int));
static void _closure_memf ARGS((NODEPTR_TYPE, int));

static void _closure_reg(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 2 < p->cost[_addrjmp_NT]) {
		p->cost[_addrjmp_NT] = c + 2;
		p->rule._addrjmp = 2;
	}
	if (c + 2 < p->cost[_addrj_NT]) {
		p->cost[_addrj_NT] = c + 2;
		p->rule._addrj = 2;
	}
	if (c + 0 < p->cost[_mrw_NT]) {
		p->cost[_mrw_NT] = c + 0;
		p->rule._mrw = 1;
		_closure_mrw(a, c + 0);
	}
	if (c + 0 < p->cost[_mrb_NT]) {
		p->cost[_mrb_NT] = c + 0;
		p->rule._mrb = 1;
		_closure_mrb(a, c + 0);
	}
	if (c + 0 < p->cost[_mr_NT]) {
		p->cost[_mr_NT] = c + 0;
		p->rule._mr = 1;
		_closure_mr(a, c + 0);
	}
	if (c + 0 < p->cost[_rc_NT]) {
		p->cost[_rc_NT] = c + 0;
		p->rule._rc = 1;
		_closure_rc(a, c + 0);
	}
	if (c + 0 < p->cost[_rc5_NT]) {
		p->cost[_rc5_NT] = c + 0;
		p->rule._rc5 = 2;
	}
	if (c + 0 < p->cost[_index_NT]) {
		p->cost[_index_NT] = c + 0;
		p->rule._index = 1;
		_closure_index(a, c + 0);
	}
	if (c + 0 < p->cost[_base_NT]) {
		p->cost[_base_NT] = c + 0;
		p->rule._base = 1;
		_closure_base(a, c + 0);
	}
	if (c + 0 < p->cost[_stmt_NT]) {
		p->cost[_stmt_NT] = c + 0;
		p->rule._stmt = 7;
	}
}

static void _closure_freg(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 0 < p->cost[_cmpf_NT]) {
		p->cost[_cmpf_NT] = c + 0;
		p->rule._cmpf = 4;
	}
	if (c + 0 < p->cost[_flt_NT]) {
		p->cost[_flt_NT] = c + 0;
		p->rule._flt = 2;
	}
	if (c + 0 < p->cost[_stmt_NT]) {
		p->cost[_stmt_NT] = c + 0;
		p->rule._stmt = 8;
	}
}

static void _closure_con(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_reg_NT]) {
		p->cost[_reg_NT] = c + 1;
		p->rule._reg = 13;
		_closure_reg(a, c + 1);
	}
	if (c + 0 < p->cost[_rc_NT]) {
		p->cost[_rc_NT] = c + 0;
		p->rule._rc = 2;
		_closure_rc(a, c + 0);
	}
}

static void _closure_baseaddr(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 0 < p->cost[_addr_NT]) {
		p->cost[_addr_NT] = c + 0;
		p->rule._addr = 2;
		_closure_addr(a, c + 0);
	}
}

static void _closure_base(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_addr_NT]) {
		p->cost[_addr_NT] = c + 1;
		p->rule._addr = 1;
		_closure_addr(a, c + 1);
	}
}

static void _closure_index(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 0 < p->cost[_addr_NT]) {
		p->cost[_addr_NT] = c + 0;
		p->rule._addr = 12;
		_closure_addr(a, c + 0);
	}
}

static void _closure_addr(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_reg_NT]) {
		p->cost[_reg_NT] = c + 1;
		p->rule._reg = 9;
		_closure_reg(a, c + 1);
	}
}

static void _closure_memb(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_mrc_NT]) {
		p->cost[_mrc_NT] = c + 1;
		p->rule._mrc = 2;
	}
	if (c + 0 < p->cost[_mrb_NT]) {
		p->cost[_mrb_NT] = c + 0;
		p->rule._mrb = 2;
		_closure_mrb(a, c + 0);
	}
}

static void _closure_memw(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_mrc_NT]) {
		p->cost[_mrc_NT] = c + 1;
		p->rule._mrc = 3;
	}
	if (c + 0 < p->cost[_mrw_NT]) {
		p->cost[_mrw_NT] = c + 0;
		p->rule._mrw = 2;
		_closure_mrw(a, c + 0);
	}
}

static void _closure_mem(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 2 < p->cost[_addrjmp_NT]) {
		p->cost[_addrjmp_NT] = c + 2;
		p->rule._addrjmp = 3;
	}
	if (c + 2 < p->cost[_addrj_NT]) {
		p->cost[_addrj_NT] = c + 2;
		p->rule._addrj = 3;
	}
	if (c + 0 < p->cost[_mrca_NT]) {
		p->cost[_mrca_NT] = c + 0;
		p->rule._mrca = 1;
	}
	if (c + 1 < p->cost[_mrc_NT]) {
		p->cost[_mrc_NT] = c + 1;
		p->rule._mrc = 1;
	}
	if (c + 0 < p->cost[_mr_NT]) {
		p->cost[_mr_NT] = c + 0;
		p->rule._mr = 2;
		_closure_mr(a, c + 0);
	}
}

static void _closure_rc(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 0 < p->cost[_mrca_NT]) {
		p->cost[_mrca_NT] = c + 0;
		p->rule._mrca = 2;
	}
	if (c + 0 < p->cost[_mrc_NT]) {
		p->cost[_mrc_NT] = c + 0;
		p->rule._mrc = 4;
	}
}

static void _closure_mr(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_reg_NT]) {
		p->cost[_reg_NT] = c + 1;
		p->rule._reg = 10;
		_closure_reg(a, c + 1);
	}
}

static void _closure_mrb(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_reg_NT]) {
		p->cost[_reg_NT] = c + 1;
		p->rule._reg = 11;
		_closure_reg(a, c + 1);
	}
}

static void _closure_mrw(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 1 < p->cost[_reg_NT]) {
		p->cost[_reg_NT] = c + 1;
		p->rule._reg = 12;
		_closure_reg(a, c + 1);
	}
}

static void _closure_memf(a, c) NODEPTR_TYPE a; int c; {
	struct _state *p = STATE_LABEL(a);
	if (c + 0 < p->cost[_flt_NT]) {
		p->cost[_flt_NT] = c + 0;
		p->rule._flt = 1;
	}
	if (c + 3 < p->cost[_freg_NT]) {
		p->cost[_freg_NT] = c + 3;
		p->rule._freg = 3;
		_closure_freg(a, c + 3);
	}
}

static void _label(a) NODEPTR_TYPE a; {
	int c;
	struct _state *p;

	if (!a)
		fatal("_label", "Null tree\n", 0);
	STATE_LABEL(a) = p = allocate(sizeof *p, FUNC);
	p->rule._stmt = 0;
	p->cost[1] =
	p->cost[2] =
	p->cost[3] =
	p->cost[4] =
	p->cost[5] =
	p->cost[6] =
	p->cost[7] =
	p->cost[8] =
	p->cost[9] =
	p->cost[10] =
	p->cost[11] =
	p->cost[12] =
	p->cost[13] =
	p->cost[14] =
	p->cost[15] =
	p->cost[16] =
	p->cost[17] =
	p->cost[18] =
	p->cost[19] =
	p->cost[20] =
	p->cost[21] =
	p->cost[22] =
	p->cost[23] =
	p->cost[24] =
	p->cost[25] =
	p->cost[26] =
		0x7fff;
	switch (OP_LABEL(a)) {
	case 17: /* CNSTF */
		break;
	case 18: /* CNSTD */
		break;
	case 19: /* CNSTC */
		/* con: CNSTC */
		if (0 + 0 < p->cost[_con_NT]) {
			p->cost[_con_NT] = 0 + 0;
			p->rule._con = 1;
			_closure_con(a, 0 + 0);
		}
		/* acon: CNSTC */
		if (0 + 0 < p->cost[_acon_NT]) {
			p->cost[_acon_NT] = 0 + 0;
			p->rule._acon = 2;
		}
		break;
	case 20: /* CNSTS */
		/* con: CNSTS */
		if (0 + 0 < p->cost[_con_NT]) {
			p->cost[_con_NT] = 0 + 0;
			p->rule._con = 4;
			_closure_con(a, 0 + 0);
		}
		/* acon: CNSTS */
		if (0 + 0 < p->cost[_acon_NT]) {
			p->cost[_acon_NT] = 0 + 0;
			p->rule._acon = 5;
		}
		break;
	case 21: /* CNSTI */
		/* con: CNSTI */
		if (0 + 0 < p->cost[_con_NT]) {
			p->cost[_con_NT] = 0 + 0;
			p->rule._con = 2;
			_closure_con(a, 0 + 0);
		}
		/* acon: CNSTI */
		if (0 + 0 < p->cost[_acon_NT]) {
			p->cost[_acon_NT] = 0 + 0;
			p->rule._acon = 3;
		}
		/* con1: CNSTI */
		c = (range(a, 1, 1));
		if (c + 0 < p->cost[_con1_NT]) {
			p->cost[_con1_NT] = c + 0;
			p->rule._con1 = 1;
		}
		/* icon: CNSTI */
		c = (range(a, 1, 1));
		if (c + 0 < p->cost[_icon_NT]) {
			p->cost[_icon_NT] = c + 0;
			p->rule._icon = 1;
		}
		/* icon: CNSTI */
		c = (range(a, 2, 2));
		if (c + 0 < p->cost[_icon_NT]) {
			p->cost[_icon_NT] = c + 0;
			p->rule._icon = 3;
		}
		/* icon: CNSTI */
		c = (range(a, 3, 3));
		if (c + 0 < p->cost[_icon_NT]) {
			p->cost[_icon_NT] = c + 0;
			p->rule._icon = 5;
		}
		/* rc5: CNSTI */
		c = (range(a, 0, 31));
		if (c + 0 < p->cost[_rc5_NT]) {
			p->cost[_rc5_NT] = c + 0;
			p->rule._rc5 = 1;
		}
		break;
	case 22: /* CNSTU */
		/* con: CNSTU */
		if (0 + 0 < p->cost[_con_NT]) {
			p->cost[_con_NT] = 0 + 0;
			p->rule._con = 5;
			_closure_con(a, 0 + 0);
		}
		/* acon: CNSTU */
		if (0 + 0 < p->cost[_acon_NT]) {
			p->cost[_acon_NT] = 0 + 0;
			p->rule._acon = 6;
		}
		/* con1: CNSTU */
		c = (range(a, 1, 1));
		if (c + 0 < p->cost[_con1_NT]) {
			p->cost[_con1_NT] = c + 0;
			p->rule._con1 = 2;
		}
		/* icon: CNSTU */
		c = (range(a, 1, 1));
		if (c + 0 < p->cost[_icon_NT]) {
			p->cost[_icon_NT] = c + 0;
			p->rule._icon = 2;
		}
		/* icon: CNSTU */
		c = (range(a, 2, 2));
		if (c + 0 < p->cost[_icon_NT]) {
			p->cost[_icon_NT] = c + 0;
			p->rule._icon = 4;
		}
		/* icon: CNSTU */
		c = (range(a, 3, 3));
		if (c + 0 < p->cost[_icon_NT]) {
			p->cost[_icon_NT] = c + 0;
			p->rule._icon = 6;
		}
		break;
	case 23: /* CNSTP */
		/* con: CNSTP */
		if (0 + 0 < p->cost[_con_NT]) {
			p->cost[_con_NT] = 0 + 0;
			p->rule._con = 3;
			_closure_con(a, 0 + 0);
		}
		/* acon: CNSTP */
		if (0 + 0 < p->cost[_acon_NT]) {
			p->cost[_acon_NT] = 0 + 0;
			p->rule._acon = 4;
		}
		break;
	case 33: /* ARGF */
		_label(LEFT_CHILD(a));
		/* stmt: ARGF(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 40;
		}
		break;
	case 34: /* ARGD */
		_label(LEFT_CHILD(a));
		/* stmt: ARGD(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 39;
		}
		break;
	case 37: /* ARGI */
		_label(LEFT_CHILD(a));
		/* stmt: ARGI(mrca) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mrca_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 33;
		}
		break;
	case 39: /* ARGP */
		_label(LEFT_CHILD(a));
		/* stmt: ARGP(mrca) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mrca_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 34;
		}
		break;
	case 41: /* ARGB */
		_label(LEFT_CHILD(a));
		if (	/* stmt: ARGB(INDIRB(reg)) */
			LEFT_CHILD(a)->op == 73 /* INDIRB */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_reg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 35;
			}
		}
		break;
	case 49: /* ASGNF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		if (	/* stmt: ASGNF(VREGP,freg) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			c = ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 6;
			}
		}
		/* stmt: ASGNF(addr,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 7;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 37;
		}
		if (	/* stmt: ASGNF(addr,CVDF(freg)) */
			RIGHT_CHILD(a)->op == 97 /* CVDF */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_freg_NT] + 7;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 38;
			}
		}
		break;
	case 50: /* ASGND */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		if (	/* stmt: ASGND(VREGP,freg) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			c = ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 5;
			}
		}
		/* stmt: ASGND(addr,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 7;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 36;
		}
		break;
	case 51: /* ASGNC */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		if (	/* stmt: ASGNC(VREGP,reg) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			c = ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 1;
			}
		}
		/* stmt: ASGNC(addr,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 28;
		}
		break;
	case 52: /* ASGNS */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		if (	/* stmt: ASGNS(VREGP,reg) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			c = ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 4;
			}
		}
		/* stmt: ASGNS(addr,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 31;
		}
		break;
	case 53: /* ASGNI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		if (	/* stmt: ASGNI(VREGP,reg) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			c = ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 2;
			}
		}
		if (	/* stmt: ASGNI(addr,ADDI(mem,con1)) */
			RIGHT_CHILD(a)->op == 309 /* ADDI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_con1_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 9;
			}
		}
		if (	/* stmt: ASGNI(addr,ADDU(mem,con1)) */
			RIGHT_CHILD(a)->op == 310 /* ADDU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_con1_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 10;
			}
		}
		if (	/* stmt: ASGNI(addr,SUBI(mem,con1)) */
			RIGHT_CHILD(a)->op == 325 /* SUBI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_con1_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 12;
			}
		}
		if (	/* stmt: ASGNI(addr,SUBU(mem,con1)) */
			RIGHT_CHILD(a)->op == 326 /* SUBU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_con1_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 13;
			}
		}
		if (	/* stmt: ASGNI(addr,ADDI(mem,rc)) */
			RIGHT_CHILD(a)->op == 309 /* ADDI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 15;
			}
		}
		if (	/* stmt: ASGNI(addr,ADDU(mem,rc)) */
			RIGHT_CHILD(a)->op == 310 /* ADDU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 16;
			}
		}
		if (	/* stmt: ASGNI(addr,SUBI(mem,rc)) */
			RIGHT_CHILD(a)->op == 325 /* SUBI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 17;
			}
		}
		if (	/* stmt: ASGNI(addr,SUBU(mem,rc)) */
			RIGHT_CHILD(a)->op == 326 /* SUBU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 18;
			}
		}
		if (	/* stmt: ASGNI(addr,BANDU(mem,rc)) */
			RIGHT_CHILD(a)->op == 390 /* BANDU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 19;
			}
		}
		if (	/* stmt: ASGNI(addr,BORU(mem,rc)) */
			RIGHT_CHILD(a)->op == 422 /* BORU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 20;
			}
		}
		if (	/* stmt: ASGNI(addr,BXORU(mem,rc)) */
			RIGHT_CHILD(a)->op == 438 /* BXORU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 21;
			}
		}
		if (	/* stmt: ASGNI(addr,BCOMU(mem)) */
			RIGHT_CHILD(a)->op == 406 /* BCOMU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 22;
			}
		}
		if (	/* stmt: ASGNI(addr,NEGI(mem)) */
			RIGHT_CHILD(a)->op == 197 /* NEGI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 23;
			}
		}
		if (	/* stmt: ASGNI(addr,LSHI(mem,rc5)) */
			RIGHT_CHILD(a)->op == 341 /* LSHI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc5_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 24;
			}
		}
		if (	/* stmt: ASGNI(addr,LSHU(mem,rc5)) */
			RIGHT_CHILD(a)->op == 342 /* LSHU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc5_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 25;
			}
		}
		if (	/* stmt: ASGNI(addr,RSHI(mem,rc5)) */
			RIGHT_CHILD(a)->op == 373 /* RSHI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc5_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 26;
			}
		}
		if (	/* stmt: ASGNI(addr,RSHU(mem,rc5)) */
			RIGHT_CHILD(a)->op == 374 /* RSHU */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_rc5_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 27;
			}
		}
		/* stmt: ASGNI(addr,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 29;
		}
		if (	/* stmt: ASGNI(addr,CVDI(freg)) */
			RIGHT_CHILD(a)->op == 101 /* CVDI */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_freg_NT] + 29;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 41;
			}
		}
		break;
	case 55: /* ASGNP */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		if (	/* stmt: ASGNP(VREGP,reg) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			c = ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 3;
			}
		}
		if (	/* stmt: ASGNP(addr,ADDP(mem,con1)) */
			RIGHT_CHILD(a)->op == 311 /* ADDP */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_con1_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 11;
			}
		}
		if (	/* stmt: ASGNP(addr,SUBP(mem,con1)) */
			RIGHT_CHILD(a)->op == 327 /* SUBP */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_con1_NT] + (memop(a));
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 14;
			}
		}
		/* stmt: ASGNP(addr,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 30;
		}
		break;
	case 57: /* ASGNB */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		if (	/* stmt: ASGNB(reg,INDIRB(reg)) */
			RIGHT_CHILD(a)->op == 73 /* INDIRB */
		) {
			c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(LEFT_CHILD(RIGHT_CHILD(a))->x.state))->cost[_reg_NT] + 0;
			if (c + 0 < p->cost[_stmt_NT]) {
				p->cost[_stmt_NT] = c + 0;
				p->rule._stmt = 32;
			}
		}
		break;
	case 65: /* INDIRF */
		_label(LEFT_CHILD(a));
		if (	/* freg: INDIRF(VREGP) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			if (mayrecalc(a)) {
				struct _state *q = a->syms[RX]->u.t.cse->x.state;
				if (q->cost[_stmt_NT] == 0) {
					p->cost[_stmt_NT] = 0;
					p->rule._stmt = q->rule._stmt;
				}
				if (q->cost[_reg_NT] == 0) {
					p->cost[_reg_NT] = 0;
					p->rule._reg = q->rule._reg;
				}
				if (q->cost[_freg_NT] == 0) {
					p->cost[_freg_NT] = 0;
					p->rule._freg = q->rule._freg;
				}
				if (q->cost[_con_NT] == 0) {
					p->cost[_con_NT] = 0;
					p->rule._con = q->rule._con;
				}
				if (q->cost[_acon_NT] == 0) {
					p->cost[_acon_NT] = 0;
					p->rule._acon = q->rule._acon;
				}
				if (q->cost[_baseaddr_NT] == 0) {
					p->cost[_baseaddr_NT] = 0;
					p->rule._baseaddr = q->rule._baseaddr;
				}
				if (q->cost[_base_NT] == 0) {
					p->cost[_base_NT] = 0;
					p->rule._base = q->rule._base;
				}
				if (q->cost[_con1_NT] == 0) {
					p->cost[_con1_NT] = 0;
					p->rule._con1 = q->rule._con1;
				}
				if (q->cost[_icon_NT] == 0) {
					p->cost[_icon_NT] = 0;
					p->rule._icon = q->rule._icon;
				}
				if (q->cost[_index_NT] == 0) {
					p->cost[_index_NT] = 0;
					p->rule._index = q->rule._index;
				}
				if (q->cost[_addr_NT] == 0) {
					p->cost[_addr_NT] = 0;
					p->rule._addr = q->rule._addr;
				}
				if (q->cost[_memb_NT] == 0) {
					p->cost[_memb_NT] = 0;
					p->rule._memb = q->rule._memb;
				}
				if (q->cost[_memw_NT] == 0) {
					p->cost[_memw_NT] = 0;
					p->rule._memw = q->rule._memw;
				}
				if (q->cost[_mem_NT] == 0) {
					p->cost[_mem_NT] = 0;
					p->rule._mem = q->rule._mem;
				}
				if (q->cost[_rc5_NT] == 0) {
					p->cost[_rc5_NT] = 0;
					p->rule._rc5 = q->rule._rc5;
				}
				if (q->cost[_rc_NT] == 0) {
					p->cost[_rc_NT] = 0;
					p->rule._rc = q->rule._rc;
				}
				if (q->cost[_mr_NT] == 0) {
					p->cost[_mr_NT] = 0;
					p->rule._mr = q->rule._mr;
				}
				if (q->cost[_mrb_NT] == 0) {
					p->cost[_mrb_NT] = 0;
					p->rule._mrb = q->rule._mrb;
				}
				if (q->cost[_mrw_NT] == 0) {
					p->cost[_mrw_NT] = 0;
					p->rule._mrw = q->rule._mrw;
				}
				if (q->cost[_mrc_NT] == 0) {
					p->cost[_mrc_NT] = 0;
					p->rule._mrc = q->rule._mrc;
				}
				if (q->cost[_mrca_NT] == 0) {
					p->cost[_mrca_NT] = 0;
					p->rule._mrca = q->rule._mrca;
				}
				if (q->cost[_memf_NT] == 0) {
					p->cost[_memf_NT] = 0;
					p->rule._memf = q->rule._memf;
				}
				if (q->cost[_flt_NT] == 0) {
					p->cost[_flt_NT] = 0;
					p->rule._flt = q->rule._flt;
				}
				if (q->cost[_addrj_NT] == 0) {
					p->cost[_addrj_NT] = 0;
					p->rule._addrj = q->rule._addrj;
				}
				if (q->cost[_addrjmp_NT] == 0) {
					p->cost[_addrjmp_NT] = 0;
					p->rule._addrjmp = q->rule._addrjmp;
				}
				if (q->cost[_cmpf_NT] == 0) {
					p->cost[_cmpf_NT] = 0;
					p->rule._cmpf = q->rule._cmpf;
				}
			}
			c = 0;
			if (c + 0 < p->cost[_freg_NT]) {
				p->cost[_freg_NT] = c + 0;
				p->rule._freg = 2;
				_closure_freg(a, c + 0);
			}
		}
		/* memf: INDIRF(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_memf_NT]) {
			p->cost[_memf_NT] = c + 0;
			p->rule._memf = 2;
			_closure_memf(a, c + 0);
		}
		/* cmpf: INDIRF(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_cmpf_NT]) {
			p->cost[_cmpf_NT] = c + 0;
			p->rule._cmpf = 2;
		}
		break;
	case 66: /* INDIRD */
		_label(LEFT_CHILD(a));
		if (	/* freg: INDIRD(VREGP) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			if (mayrecalc(a)) {
				struct _state *q = a->syms[RX]->u.t.cse->x.state;
				if (q->cost[_stmt_NT] == 0) {
					p->cost[_stmt_NT] = 0;
					p->rule._stmt = q->rule._stmt;
				}
				if (q->cost[_reg_NT] == 0) {
					p->cost[_reg_NT] = 0;
					p->rule._reg = q->rule._reg;
				}
				if (q->cost[_freg_NT] == 0) {
					p->cost[_freg_NT] = 0;
					p->rule._freg = q->rule._freg;
				}
				if (q->cost[_con_NT] == 0) {
					p->cost[_con_NT] = 0;
					p->rule._con = q->rule._con;
				}
				if (q->cost[_acon_NT] == 0) {
					p->cost[_acon_NT] = 0;
					p->rule._acon = q->rule._acon;
				}
				if (q->cost[_baseaddr_NT] == 0) {
					p->cost[_baseaddr_NT] = 0;
					p->rule._baseaddr = q->rule._baseaddr;
				}
				if (q->cost[_base_NT] == 0) {
					p->cost[_base_NT] = 0;
					p->rule._base = q->rule._base;
				}
				if (q->cost[_con1_NT] == 0) {
					p->cost[_con1_NT] = 0;
					p->rule._con1 = q->rule._con1;
				}
				if (q->cost[_icon_NT] == 0) {
					p->cost[_icon_NT] = 0;
					p->rule._icon = q->rule._icon;
				}
				if (q->cost[_index_NT] == 0) {
					p->cost[_index_NT] = 0;
					p->rule._index = q->rule._index;
				}
				if (q->cost[_addr_NT] == 0) {
					p->cost[_addr_NT] = 0;
					p->rule._addr = q->rule._addr;
				}
				if (q->cost[_memb_NT] == 0) {
					p->cost[_memb_NT] = 0;
					p->rule._memb = q->rule._memb;
				}
				if (q->cost[_memw_NT] == 0) {
					p->cost[_memw_NT] = 0;
					p->rule._memw = q->rule._memw;
				}
				if (q->cost[_mem_NT] == 0) {
					p->cost[_mem_NT] = 0;
					p->rule._mem = q->rule._mem;
				}
				if (q->cost[_rc5_NT] == 0) {
					p->cost[_rc5_NT] = 0;
					p->rule._rc5 = q->rule._rc5;
				}
				if (q->cost[_rc_NT] == 0) {
					p->cost[_rc_NT] = 0;
					p->rule._rc = q->rule._rc;
				}
				if (q->cost[_mr_NT] == 0) {
					p->cost[_mr_NT] = 0;
					p->rule._mr = q->rule._mr;
				}
				if (q->cost[_mrb_NT] == 0) {
					p->cost[_mrb_NT] = 0;
					p->rule._mrb = q->rule._mrb;
				}
				if (q->cost[_mrw_NT] == 0) {
					p->cost[_mrw_NT] = 0;
					p->rule._mrw = q->rule._mrw;
				}
				if (q->cost[_mrc_NT] == 0) {
					p->cost[_mrc_NT] = 0;
					p->rule._mrc = q->rule._mrc;
				}
				if (q->cost[_mrca_NT] == 0) {
					p->cost[_mrca_NT] = 0;
					p->rule._mrca = q->rule._mrca;
				}
				if (q->cost[_memf_NT] == 0) {
					p->cost[_memf_NT] = 0;
					p->rule._memf = q->rule._memf;
				}
				if (q->cost[_flt_NT] == 0) {
					p->cost[_flt_NT] = 0;
					p->rule._flt = q->rule._flt;
				}
				if (q->cost[_addrj_NT] == 0) {
					p->cost[_addrj_NT] = 0;
					p->rule._addrj = q->rule._addrj;
				}
				if (q->cost[_addrjmp_NT] == 0) {
					p->cost[_addrjmp_NT] = 0;
					p->rule._addrjmp = q->rule._addrjmp;
				}
				if (q->cost[_cmpf_NT] == 0) {
					p->cost[_cmpf_NT] = 0;
					p->rule._cmpf = q->rule._cmpf;
				}
			}
			c = 0;
			if (c + 0 < p->cost[_freg_NT]) {
				p->cost[_freg_NT] = c + 0;
				p->rule._freg = 1;
				_closure_freg(a, c + 0);
			}
		}
		/* memf: INDIRD(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_memf_NT]) {
			p->cost[_memf_NT] = c + 0;
			p->rule._memf = 1;
			_closure_memf(a, c + 0);
		}
		/* cmpf: INDIRD(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_cmpf_NT]) {
			p->cost[_cmpf_NT] = c + 0;
			p->rule._cmpf = 1;
		}
		break;
	case 67: /* INDIRC */
		_label(LEFT_CHILD(a));
		if (	/* reg: INDIRC(VREGP) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			if (mayrecalc(a)) {
				struct _state *q = a->syms[RX]->u.t.cse->x.state;
				if (q->cost[_stmt_NT] == 0) {
					p->cost[_stmt_NT] = 0;
					p->rule._stmt = q->rule._stmt;
				}
				if (q->cost[_reg_NT] == 0) {
					p->cost[_reg_NT] = 0;
					p->rule._reg = q->rule._reg;
				}
				if (q->cost[_freg_NT] == 0) {
					p->cost[_freg_NT] = 0;
					p->rule._freg = q->rule._freg;
				}
				if (q->cost[_con_NT] == 0) {
					p->cost[_con_NT] = 0;
					p->rule._con = q->rule._con;
				}
				if (q->cost[_acon_NT] == 0) {
					p->cost[_acon_NT] = 0;
					p->rule._acon = q->rule._acon;
				}
				if (q->cost[_baseaddr_NT] == 0) {
					p->cost[_baseaddr_NT] = 0;
					p->rule._baseaddr = q->rule._baseaddr;
				}
				if (q->cost[_base_NT] == 0) {
					p->cost[_base_NT] = 0;
					p->rule._base = q->rule._base;
				}
				if (q->cost[_con1_NT] == 0) {
					p->cost[_con1_NT] = 0;
					p->rule._con1 = q->rule._con1;
				}
				if (q->cost[_icon_NT] == 0) {
					p->cost[_icon_NT] = 0;
					p->rule._icon = q->rule._icon;
				}
				if (q->cost[_index_NT] == 0) {
					p->cost[_index_NT] = 0;
					p->rule._index = q->rule._index;
				}
				if (q->cost[_addr_NT] == 0) {
					p->cost[_addr_NT] = 0;
					p->rule._addr = q->rule._addr;
				}
				if (q->cost[_memb_NT] == 0) {
					p->cost[_memb_NT] = 0;
					p->rule._memb = q->rule._memb;
				}
				if (q->cost[_memw_NT] == 0) {
					p->cost[_memw_NT] = 0;
					p->rule._memw = q->rule._memw;
				}
				if (q->cost[_mem_NT] == 0) {
					p->cost[_mem_NT] = 0;
					p->rule._mem = q->rule._mem;
				}
				if (q->cost[_rc5_NT] == 0) {
					p->cost[_rc5_NT] = 0;
					p->rule._rc5 = q->rule._rc5;
				}
				if (q->cost[_rc_NT] == 0) {
					p->cost[_rc_NT] = 0;
					p->rule._rc = q->rule._rc;
				}
				if (q->cost[_mr_NT] == 0) {
					p->cost[_mr_NT] = 0;
					p->rule._mr = q->rule._mr;
				}
				if (q->cost[_mrb_NT] == 0) {
					p->cost[_mrb_NT] = 0;
					p->rule._mrb = q->rule._mrb;
				}
				if (q->cost[_mrw_NT] == 0) {
					p->cost[_mrw_NT] = 0;
					p->rule._mrw = q->rule._mrw;
				}
				if (q->cost[_mrc_NT] == 0) {
					p->cost[_mrc_NT] = 0;
					p->rule._mrc = q->rule._mrc;
				}
				if (q->cost[_mrca_NT] == 0) {
					p->cost[_mrca_NT] = 0;
					p->rule._mrca = q->rule._mrca;
				}
				if (q->cost[_memf_NT] == 0) {
					p->cost[_memf_NT] = 0;
					p->rule._memf = q->rule._memf;
				}
				if (q->cost[_flt_NT] == 0) {
					p->cost[_flt_NT] = 0;
					p->rule._flt = q->rule._flt;
				}
				if (q->cost[_addrj_NT] == 0) {
					p->cost[_addrj_NT] = 0;
					p->rule._addrj = q->rule._addrj;
				}
				if (q->cost[_addrjmp_NT] == 0) {
					p->cost[_addrjmp_NT] = 0;
					p->rule._addrjmp = q->rule._addrjmp;
				}
				if (q->cost[_cmpf_NT] == 0) {
					p->cost[_cmpf_NT] = 0;
					p->rule._cmpf = q->rule._cmpf;
				}
			}
			c = 0;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 1;
				_closure_reg(a, c + 0);
			}
		}
		/* memb: INDIRC(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_memb_NT]) {
			p->cost[_memb_NT] = c + 0;
			p->rule._memb = 1;
			_closure_memb(a, c + 0);
		}
		break;
	case 68: /* INDIRS */
		_label(LEFT_CHILD(a));
		if (	/* reg: INDIRS(VREGP) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			if (mayrecalc(a)) {
				struct _state *q = a->syms[RX]->u.t.cse->x.state;
				if (q->cost[_stmt_NT] == 0) {
					p->cost[_stmt_NT] = 0;
					p->rule._stmt = q->rule._stmt;
				}
				if (q->cost[_reg_NT] == 0) {
					p->cost[_reg_NT] = 0;
					p->rule._reg = q->rule._reg;
				}
				if (q->cost[_freg_NT] == 0) {
					p->cost[_freg_NT] = 0;
					p->rule._freg = q->rule._freg;
				}
				if (q->cost[_con_NT] == 0) {
					p->cost[_con_NT] = 0;
					p->rule._con = q->rule._con;
				}
				if (q->cost[_acon_NT] == 0) {
					p->cost[_acon_NT] = 0;
					p->rule._acon = q->rule._acon;
				}
				if (q->cost[_baseaddr_NT] == 0) {
					p->cost[_baseaddr_NT] = 0;
					p->rule._baseaddr = q->rule._baseaddr;
				}
				if (q->cost[_base_NT] == 0) {
					p->cost[_base_NT] = 0;
					p->rule._base = q->rule._base;
				}
				if (q->cost[_con1_NT] == 0) {
					p->cost[_con1_NT] = 0;
					p->rule._con1 = q->rule._con1;
				}
				if (q->cost[_icon_NT] == 0) {
					p->cost[_icon_NT] = 0;
					p->rule._icon = q->rule._icon;
				}
				if (q->cost[_index_NT] == 0) {
					p->cost[_index_NT] = 0;
					p->rule._index = q->rule._index;
				}
				if (q->cost[_addr_NT] == 0) {
					p->cost[_addr_NT] = 0;
					p->rule._addr = q->rule._addr;
				}
				if (q->cost[_memb_NT] == 0) {
					p->cost[_memb_NT] = 0;
					p->rule._memb = q->rule._memb;
				}
				if (q->cost[_memw_NT] == 0) {
					p->cost[_memw_NT] = 0;
					p->rule._memw = q->rule._memw;
				}
				if (q->cost[_mem_NT] == 0) {
					p->cost[_mem_NT] = 0;
					p->rule._mem = q->rule._mem;
				}
				if (q->cost[_rc5_NT] == 0) {
					p->cost[_rc5_NT] = 0;
					p->rule._rc5 = q->rule._rc5;
				}
				if (q->cost[_rc_NT] == 0) {
					p->cost[_rc_NT] = 0;
					p->rule._rc = q->rule._rc;
				}
				if (q->cost[_mr_NT] == 0) {
					p->cost[_mr_NT] = 0;
					p->rule._mr = q->rule._mr;
				}
				if (q->cost[_mrb_NT] == 0) {
					p->cost[_mrb_NT] = 0;
					p->rule._mrb = q->rule._mrb;
				}
				if (q->cost[_mrw_NT] == 0) {
					p->cost[_mrw_NT] = 0;
					p->rule._mrw = q->rule._mrw;
				}
				if (q->cost[_mrc_NT] == 0) {
					p->cost[_mrc_NT] = 0;
					p->rule._mrc = q->rule._mrc;
				}
				if (q->cost[_mrca_NT] == 0) {
					p->cost[_mrca_NT] = 0;
					p->rule._mrca = q->rule._mrca;
				}
				if (q->cost[_memf_NT] == 0) {
					p->cost[_memf_NT] = 0;
					p->rule._memf = q->rule._memf;
				}
				if (q->cost[_flt_NT] == 0) {
					p->cost[_flt_NT] = 0;
					p->rule._flt = q->rule._flt;
				}
				if (q->cost[_addrj_NT] == 0) {
					p->cost[_addrj_NT] = 0;
					p->rule._addrj = q->rule._addrj;
				}
				if (q->cost[_addrjmp_NT] == 0) {
					p->cost[_addrjmp_NT] = 0;
					p->rule._addrjmp = q->rule._addrjmp;
				}
				if (q->cost[_cmpf_NT] == 0) {
					p->cost[_cmpf_NT] = 0;
					p->rule._cmpf = q->rule._cmpf;
				}
			}
			c = 0;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 4;
				_closure_reg(a, c + 0);
			}
		}
		/* memw: INDIRS(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_memw_NT]) {
			p->cost[_memw_NT] = c + 0;
			p->rule._memw = 1;
			_closure_memw(a, c + 0);
		}
		break;
	case 69: /* INDIRI */
		_label(LEFT_CHILD(a));
		if (	/* reg: INDIRI(VREGP) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			if (mayrecalc(a)) {
				struct _state *q = a->syms[RX]->u.t.cse->x.state;
				if (q->cost[_stmt_NT] == 0) {
					p->cost[_stmt_NT] = 0;
					p->rule._stmt = q->rule._stmt;
				}
				if (q->cost[_reg_NT] == 0) {
					p->cost[_reg_NT] = 0;
					p->rule._reg = q->rule._reg;
				}
				if (q->cost[_freg_NT] == 0) {
					p->cost[_freg_NT] = 0;
					p->rule._freg = q->rule._freg;
				}
				if (q->cost[_con_NT] == 0) {
					p->cost[_con_NT] = 0;
					p->rule._con = q->rule._con;
				}
				if (q->cost[_acon_NT] == 0) {
					p->cost[_acon_NT] = 0;
					p->rule._acon = q->rule._acon;
				}
				if (q->cost[_baseaddr_NT] == 0) {
					p->cost[_baseaddr_NT] = 0;
					p->rule._baseaddr = q->rule._baseaddr;
				}
				if (q->cost[_base_NT] == 0) {
					p->cost[_base_NT] = 0;
					p->rule._base = q->rule._base;
				}
				if (q->cost[_con1_NT] == 0) {
					p->cost[_con1_NT] = 0;
					p->rule._con1 = q->rule._con1;
				}
				if (q->cost[_icon_NT] == 0) {
					p->cost[_icon_NT] = 0;
					p->rule._icon = q->rule._icon;
				}
				if (q->cost[_index_NT] == 0) {
					p->cost[_index_NT] = 0;
					p->rule._index = q->rule._index;
				}
				if (q->cost[_addr_NT] == 0) {
					p->cost[_addr_NT] = 0;
					p->rule._addr = q->rule._addr;
				}
				if (q->cost[_memb_NT] == 0) {
					p->cost[_memb_NT] = 0;
					p->rule._memb = q->rule._memb;
				}
				if (q->cost[_memw_NT] == 0) {
					p->cost[_memw_NT] = 0;
					p->rule._memw = q->rule._memw;
				}
				if (q->cost[_mem_NT] == 0) {
					p->cost[_mem_NT] = 0;
					p->rule._mem = q->rule._mem;
				}
				if (q->cost[_rc5_NT] == 0) {
					p->cost[_rc5_NT] = 0;
					p->rule._rc5 = q->rule._rc5;
				}
				if (q->cost[_rc_NT] == 0) {
					p->cost[_rc_NT] = 0;
					p->rule._rc = q->rule._rc;
				}
				if (q->cost[_mr_NT] == 0) {
					p->cost[_mr_NT] = 0;
					p->rule._mr = q->rule._mr;
				}
				if (q->cost[_mrb_NT] == 0) {
					p->cost[_mrb_NT] = 0;
					p->rule._mrb = q->rule._mrb;
				}
				if (q->cost[_mrw_NT] == 0) {
					p->cost[_mrw_NT] = 0;
					p->rule._mrw = q->rule._mrw;
				}
				if (q->cost[_mrc_NT] == 0) {
					p->cost[_mrc_NT] = 0;
					p->rule._mrc = q->rule._mrc;
				}
				if (q->cost[_mrca_NT] == 0) {
					p->cost[_mrca_NT] = 0;
					p->rule._mrca = q->rule._mrca;
				}
				if (q->cost[_memf_NT] == 0) {
					p->cost[_memf_NT] = 0;
					p->rule._memf = q->rule._memf;
				}
				if (q->cost[_flt_NT] == 0) {
					p->cost[_flt_NT] = 0;
					p->rule._flt = q->rule._flt;
				}
				if (q->cost[_addrj_NT] == 0) {
					p->cost[_addrj_NT] = 0;
					p->rule._addrj = q->rule._addrj;
				}
				if (q->cost[_addrjmp_NT] == 0) {
					p->cost[_addrjmp_NT] = 0;
					p->rule._addrjmp = q->rule._addrjmp;
				}
				if (q->cost[_cmpf_NT] == 0) {
					p->cost[_cmpf_NT] = 0;
					p->rule._cmpf = q->rule._cmpf;
				}
			}
			c = 0;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 2;
				_closure_reg(a, c + 0);
			}
		}
		/* mem: INDIRI(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_mem_NT]) {
			p->cost[_mem_NT] = c + 0;
			p->rule._mem = 1;
			_closure_mem(a, c + 0);
		}
		break;
	case 71: /* INDIRP */
		_label(LEFT_CHILD(a));
		if (	/* reg: INDIRP(VREGP) */
			LEFT_CHILD(a)->op == 615 /* VREGP */
		) {
			if (mayrecalc(a)) {
				struct _state *q = a->syms[RX]->u.t.cse->x.state;
				if (q->cost[_stmt_NT] == 0) {
					p->cost[_stmt_NT] = 0;
					p->rule._stmt = q->rule._stmt;
				}
				if (q->cost[_reg_NT] == 0) {
					p->cost[_reg_NT] = 0;
					p->rule._reg = q->rule._reg;
				}
				if (q->cost[_freg_NT] == 0) {
					p->cost[_freg_NT] = 0;
					p->rule._freg = q->rule._freg;
				}
				if (q->cost[_con_NT] == 0) {
					p->cost[_con_NT] = 0;
					p->rule._con = q->rule._con;
				}
				if (q->cost[_acon_NT] == 0) {
					p->cost[_acon_NT] = 0;
					p->rule._acon = q->rule._acon;
				}
				if (q->cost[_baseaddr_NT] == 0) {
					p->cost[_baseaddr_NT] = 0;
					p->rule._baseaddr = q->rule._baseaddr;
				}
				if (q->cost[_base_NT] == 0) {
					p->cost[_base_NT] = 0;
					p->rule._base = q->rule._base;
				}
				if (q->cost[_con1_NT] == 0) {
					p->cost[_con1_NT] = 0;
					p->rule._con1 = q->rule._con1;
				}
				if (q->cost[_icon_NT] == 0) {
					p->cost[_icon_NT] = 0;
					p->rule._icon = q->rule._icon;
				}
				if (q->cost[_index_NT] == 0) {
					p->cost[_index_NT] = 0;
					p->rule._index = q->rule._index;
				}
				if (q->cost[_addr_NT] == 0) {
					p->cost[_addr_NT] = 0;
					p->rule._addr = q->rule._addr;
				}
				if (q->cost[_memb_NT] == 0) {
					p->cost[_memb_NT] = 0;
					p->rule._memb = q->rule._memb;
				}
				if (q->cost[_memw_NT] == 0) {
					p->cost[_memw_NT] = 0;
					p->rule._memw = q->rule._memw;
				}
				if (q->cost[_mem_NT] == 0) {
					p->cost[_mem_NT] = 0;
					p->rule._mem = q->rule._mem;
				}
				if (q->cost[_rc5_NT] == 0) {
					p->cost[_rc5_NT] = 0;
					p->rule._rc5 = q->rule._rc5;
				}
				if (q->cost[_rc_NT] == 0) {
					p->cost[_rc_NT] = 0;
					p->rule._rc = q->rule._rc;
				}
				if (q->cost[_mr_NT] == 0) {
					p->cost[_mr_NT] = 0;
					p->rule._mr = q->rule._mr;
				}
				if (q->cost[_mrb_NT] == 0) {
					p->cost[_mrb_NT] = 0;
					p->rule._mrb = q->rule._mrb;
				}
				if (q->cost[_mrw_NT] == 0) {
					p->cost[_mrw_NT] = 0;
					p->rule._mrw = q->rule._mrw;
				}
				if (q->cost[_mrc_NT] == 0) {
					p->cost[_mrc_NT] = 0;
					p->rule._mrc = q->rule._mrc;
				}
				if (q->cost[_mrca_NT] == 0) {
					p->cost[_mrca_NT] = 0;
					p->rule._mrca = q->rule._mrca;
				}
				if (q->cost[_memf_NT] == 0) {
					p->cost[_memf_NT] = 0;
					p->rule._memf = q->rule._memf;
				}
				if (q->cost[_flt_NT] == 0) {
					p->cost[_flt_NT] = 0;
					p->rule._flt = q->rule._flt;
				}
				if (q->cost[_addrj_NT] == 0) {
					p->cost[_addrj_NT] = 0;
					p->rule._addrj = q->rule._addrj;
				}
				if (q->cost[_addrjmp_NT] == 0) {
					p->cost[_addrjmp_NT] = 0;
					p->rule._addrjmp = q->rule._addrjmp;
				}
				if (q->cost[_cmpf_NT] == 0) {
					p->cost[_cmpf_NT] = 0;
					p->rule._cmpf = q->rule._cmpf;
				}
			}
			c = 0;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 3;
				_closure_reg(a, c + 0);
			}
		}
		/* mem: INDIRP(addr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addr_NT] + 0;
		if (c + 0 < p->cost[_mem_NT]) {
			p->cost[_mem_NT] = c + 0;
			p->rule._mem = 2;
			_closure_mem(a, c + 0);
		}
		break;
	case 73: /* INDIRB */
		_label(LEFT_CHILD(a));
		break;
	case 85: /* CVCI */
		_label(LEFT_CHILD(a));
		if (	/* reg: CVCI(INDIRC(addr)) */
			LEFT_CHILD(a)->op == 67 /* INDIRC */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_addr_NT] + 3;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 45;
				_closure_reg(a, c + 0);
			}
		}
		/* reg: CVCI(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 3;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 49;
			_closure_reg(a, c + 0);
		}
		break;
	case 86: /* CVCU */
		_label(LEFT_CHILD(a));
		if (	/* reg: CVCU(INDIRC(addr)) */
			LEFT_CHILD(a)->op == 67 /* INDIRC */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_addr_NT] + 3;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 46;
				_closure_reg(a, c + 0);
			}
		}
		/* reg: CVCU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 3;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 50;
			_closure_reg(a, c + 0);
		}
		break;
	case 97: /* CVDF */
		_label(LEFT_CHILD(a));
		/* freg: CVDF(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 12;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 19;
			_closure_freg(a, c + 0);
		}
		break;
	case 101: /* CVDI */
		_label(LEFT_CHILD(a));
		/* reg: CVDI(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 31;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 57;
			_closure_reg(a, c + 0);
		}
		break;
	case 114: /* CVFD */
		_label(LEFT_CHILD(a));
		if (	/* memf: CVFD(INDIRF(addr)) */
			LEFT_CHILD(a)->op == 65 /* INDIRF */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_addr_NT] + 0;
			if (c + 0 < p->cost[_memf_NT]) {
				p->cost[_memf_NT] = c + 0;
				p->rule._memf = 3;
				_closure_memf(a, c + 0);
			}
		}
		/* freg: CVFD(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 18;
			_closure_freg(a, c + 0);
		}
		if (	/* cmpf: CVFD(INDIRF(addr)) */
			LEFT_CHILD(a)->op == 65 /* INDIRF */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_addr_NT] + 0;
			if (c + 0 < p->cost[_cmpf_NT]) {
				p->cost[_cmpf_NT] = c + 0;
				p->rule._cmpf = 3;
			}
		}
		break;
	case 130: /* CVID */
		_label(LEFT_CHILD(a));
		if (	/* freg: CVID(INDIRI(addr)) */
			LEFT_CHILD(a)->op == 69 /* INDIRI */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_addr_NT] + 10;
			if (c + 0 < p->cost[_freg_NT]) {
				p->cost[_freg_NT] = c + 0;
				p->rule._freg = 20;
				_closure_freg(a, c + 0);
			}
		}
		/* freg: CVID(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 12;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 21;
			_closure_freg(a, c + 0);
		}
		break;
	case 131: /* CVIC */
		_label(LEFT_CHILD(a));
		/* reg: CVIC(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 53;
			_closure_reg(a, c + 0);
		}
		break;
	case 132: /* CVIS */
		_label(LEFT_CHILD(a));
		/* reg: CVIS(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 54;
			_closure_reg(a, c + 0);
		}
		break;
	case 134: /* CVIU */
		_label(LEFT_CHILD(a));
		/* reg: CVIU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (notarget(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 5;
			_closure_reg(a, c + 0);
		}
		/* reg: CVIU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 41;
			_closure_reg(a, c + 0);
		}
		break;
	case 150: /* CVPU */
		_label(LEFT_CHILD(a));
		/* reg: CVPU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (notarget(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 6;
			_closure_reg(a, c + 0);
		}
		/* reg: CVPU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 42;
			_closure_reg(a, c + 0);
		}
		break;
	case 165: /* CVSI */
		_label(LEFT_CHILD(a));
		if (	/* reg: CVSI(INDIRS(addr)) */
			LEFT_CHILD(a)->op == 68 /* INDIRS */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_addr_NT] + 3;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 47;
				_closure_reg(a, c + 0);
			}
		}
		/* reg: CVSI(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 3;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 51;
			_closure_reg(a, c + 0);
		}
		break;
	case 166: /* CVSU */
		_label(LEFT_CHILD(a));
		if (	/* reg: CVSU(INDIRS(addr)) */
			LEFT_CHILD(a)->op == 68 /* INDIRS */
		) {
			c = ((struct _state *)(LEFT_CHILD(LEFT_CHILD(a))->x.state))->cost[_addr_NT] + 3;
			if (c + 0 < p->cost[_reg_NT]) {
				p->cost[_reg_NT] = c + 0;
				p->rule._reg = 48;
				_closure_reg(a, c + 0);
			}
		}
		/* reg: CVSU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 3;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 52;
			_closure_reg(a, c + 0);
		}
		break;
	case 179: /* CVUC */
		_label(LEFT_CHILD(a));
		/* reg: CVUC(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 55;
			_closure_reg(a, c + 0);
		}
		break;
	case 180: /* CVUS */
		_label(LEFT_CHILD(a));
		/* reg: CVUS(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 56;
			_closure_reg(a, c + 0);
		}
		break;
	case 181: /* CVUI */
		_label(LEFT_CHILD(a));
		/* reg: CVUI(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (notarget(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 7;
			_closure_reg(a, c + 0);
		}
		/* reg: CVUI(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 43;
			_closure_reg(a, c + 0);
		}
		break;
	case 183: /* CVUP */
		_label(LEFT_CHILD(a));
		/* reg: CVUP(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (notarget(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 8;
			_closure_reg(a, c + 0);
		}
		/* reg: CVUP(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 44;
			_closure_reg(a, c + 0);
		}
		break;
	case 193: /* NEGF */
		_label(LEFT_CHILD(a));
		/* freg: NEGF(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 5;
			_closure_freg(a, c + 0);
		}
		break;
	case 194: /* NEGD */
		_label(LEFT_CHILD(a));
		/* freg: NEGD(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 4;
			_closure_freg(a, c + 0);
		}
		break;
	case 197: /* NEGI */
		_label(LEFT_CHILD(a));
		/* reg: NEGI(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 2;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 33;
			_closure_reg(a, c + 0);
		}
		break;
	case 209: /* CALLF */
		_label(LEFT_CHILD(a));
		/* freg: CALLF(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + (hasargs(a));
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 22;
			_closure_freg(a, c + 0);
		}
		/* freg: CALLF(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + 1;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 23;
			_closure_freg(a, c + 0);
		}
		/* stmt: CALLF(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + (hasargs(a));
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 78;
		}
		/* stmt: CALLF(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 79;
		}
		break;
	case 210: /* CALLD */
		_label(LEFT_CHILD(a));
		/* freg: CALLD(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + (hasargs(a));
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 24;
			_closure_freg(a, c + 0);
		}
		/* freg: CALLD(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + 1;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 25;
			_closure_freg(a, c + 0);
		}
		/* stmt: CALLD(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + (hasargs(a));
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 80;
		}
		/* stmt: CALLD(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 81;
		}
		break;
	case 213: /* CALLI */
		_label(LEFT_CHILD(a));
		/* reg: CALLI(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + (hasargs(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 58;
			_closure_reg(a, c + 0);
		}
		/* reg: CALLI(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 59;
			_closure_reg(a, c + 0);
		}
		break;
	case 216: /* CALLV */
		_label(LEFT_CHILD(a));
		/* stmt: CALLV(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + (hasargs(a));
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 76;
		}
		/* stmt: CALLV(addrj) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrj_NT] + 1;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 77;
		}
		break;
	case 217: /* CALLB */
		break;
	case 225: /* LOADF */
		break;
	case 226: /* LOADD */
		break;
	case 227: /* LOADC */
		_label(LEFT_CHILD(a));
		/* reg: LOADC(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 14;
			_closure_reg(a, c + 0);
		}
		break;
	case 228: /* LOADS */
		_label(LEFT_CHILD(a));
		/* reg: LOADS(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 17;
			_closure_reg(a, c + 0);
		}
		break;
	case 229: /* LOADI */
		_label(LEFT_CHILD(a));
		/* reg: LOADI(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 15;
			_closure_reg(a, c + 0);
		}
		break;
	case 230: /* LOADU */
		_label(LEFT_CHILD(a));
		/* reg: LOADU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 18;
			_closure_reg(a, c + 0);
		}
		break;
	case 231: /* LOADP */
		_label(LEFT_CHILD(a));
		/* reg: LOADP(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + (move(a));
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 16;
			_closure_reg(a, c + 0);
		}
		break;
	case 233: /* LOADB */
		break;
	case 241: /* RETF */
		_label(LEFT_CHILD(a));
		/* stmt: RETF(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 83;
		}
		break;
	case 242: /* RETD */
		_label(LEFT_CHILD(a));
		/* stmt: RETD(freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 84;
		}
		break;
	case 245: /* RETI */
		_label(LEFT_CHILD(a));
		/* stmt: RETI(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 82;
		}
		break;
	case 263: /* ADDRGP */
		/* acon: ADDRGP */
		if (0 + 0 < p->cost[_acon_NT]) {
			p->cost[_acon_NT] = 0 + 0;
			p->rule._acon = 1;
		}
		/* baseaddr: ADDRGP */
		if (0 + 0 < p->cost[_baseaddr_NT]) {
			p->cost[_baseaddr_NT] = 0 + 0;
			p->rule._baseaddr = 1;
			_closure_baseaddr(a, 0 + 0);
		}
		/* mrca: ADDRGP */
		if (0 + 0 < p->cost[_mrca_NT]) {
			p->cost[_mrca_NT] = 0 + 0;
			p->rule._mrca = 3;
		}
		/* addrj: ADDRGP */
		if (0 + 0 < p->cost[_addrj_NT]) {
			p->cost[_addrj_NT] = 0 + 0;
			p->rule._addrj = 1;
		}
		/* addrjmp: ADDRGP */
		if (0 + 0 < p->cost[_addrjmp_NT]) {
			p->cost[_addrjmp_NT] = 0 + 0;
			p->rule._addrjmp = 1;
		}
		break;
	case 279: /* ADDRFP */
		/* base: ADDRFP */
		if (0 + 0 < p->cost[_base_NT]) {
			p->cost[_base_NT] = 0 + 0;
			p->rule._base = 5;
			_closure_base(a, 0 + 0);
		}
		break;
	case 295: /* ADDRLP */
		/* base: ADDRLP */
		if (0 + 0 < p->cost[_base_NT]) {
			p->cost[_base_NT] = 0 + 0;
			p->rule._base = 6;
			_closure_base(a, 0 + 0);
		}
		break;
	case 305: /* ADDF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: ADDF(freg,flt) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_flt_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 7;
			_closure_freg(a, c + 0);
		}
		break;
	case 306: /* ADDD */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: ADDD(freg,flt) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_flt_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 6;
			_closure_freg(a, c + 0);
		}
		break;
	case 309: /* ADDI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* base: ADDI(reg,acon) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_acon_NT] + 0;
		if (c + 0 < p->cost[_base_NT]) {
			p->cost[_base_NT] = c + 0;
			p->rule._base = 2;
			_closure_base(a, c + 0);
		}
		/* addr: ADDI(index,baseaddr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_index_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_baseaddr_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 3;
			_closure_addr(a, c + 0);
		}
		/* addr: ADDI(reg,baseaddr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_baseaddr_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 4;
			_closure_addr(a, c + 0);
		}
		/* addr: ADDI(index,reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_index_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 5;
			_closure_addr(a, c + 0);
		}
		/* reg: ADDI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 19;
			_closure_reg(a, c + 0);
		}
		break;
	case 310: /* ADDU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* base: ADDU(reg,acon) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_acon_NT] + 0;
		if (c + 0 < p->cost[_base_NT]) {
			p->cost[_base_NT] = c + 0;
			p->rule._base = 4;
			_closure_base(a, c + 0);
		}
		/* addr: ADDU(index,baseaddr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_index_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_baseaddr_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 9;
			_closure_addr(a, c + 0);
		}
		/* addr: ADDU(reg,baseaddr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_baseaddr_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 10;
			_closure_addr(a, c + 0);
		}
		/* addr: ADDU(index,reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_index_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 11;
			_closure_addr(a, c + 0);
		}
		/* reg: ADDU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 21;
			_closure_reg(a, c + 0);
		}
		break;
	case 311: /* ADDP */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* base: ADDP(reg,acon) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_acon_NT] + 0;
		if (c + 0 < p->cost[_base_NT]) {
			p->cost[_base_NT] = c + 0;
			p->rule._base = 3;
			_closure_base(a, c + 0);
		}
		/* addr: ADDP(index,baseaddr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_index_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_baseaddr_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 6;
			_closure_addr(a, c + 0);
		}
		/* addr: ADDP(reg,baseaddr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_baseaddr_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 7;
			_closure_addr(a, c + 0);
		}
		/* addr: ADDP(index,reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_index_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_addr_NT]) {
			p->cost[_addr_NT] = c + 0;
			p->rule._addr = 8;
			_closure_addr(a, c + 0);
		}
		/* reg: ADDP(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 20;
			_closure_reg(a, c + 0);
		}
		break;
	case 321: /* SUBF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: SUBF(freg,memf) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_memf_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 16;
			_closure_freg(a, c + 0);
		}
		/* freg: SUBF(freg,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 17;
			_closure_freg(a, c + 0);
		}
		break;
	case 322: /* SUBD */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: SUBD(freg,memf) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_memf_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 14;
			_closure_freg(a, c + 0);
		}
		/* freg: SUBD(freg,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 15;
			_closure_freg(a, c + 0);
		}
		break;
	case 325: /* SUBI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: SUBI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 22;
			_closure_reg(a, c + 0);
		}
		break;
	case 326: /* SUBU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: SUBU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 24;
			_closure_reg(a, c + 0);
		}
		break;
	case 327: /* SUBP */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: SUBP(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 23;
			_closure_reg(a, c + 0);
		}
		break;
	case 341: /* LSHI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* index: LSHI(reg,icon) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_icon_NT] + 0;
		if (c + 0 < p->cost[_index_NT]) {
			p->cost[_index_NT] = c + 0;
			p->rule._index = 2;
			_closure_index(a, c + 0);
		}
		/* reg: LSHI(reg,rc5) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc5_NT] + 2;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 28;
			_closure_reg(a, c + 0);
		}
		break;
	case 342: /* LSHU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* index: LSHU(reg,icon) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_icon_NT] + 0;
		if (c + 0 < p->cost[_index_NT]) {
			p->cost[_index_NT] = c + 0;
			p->rule._index = 3;
			_closure_index(a, c + 0);
		}
		/* reg: LSHU(reg,rc5) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc5_NT] + 2;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 29;
			_closure_reg(a, c + 0);
		}
		break;
	case 357: /* MODI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: MODI(reg,reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 40;
			_closure_reg(a, c + 0);
		}
		break;
	case 358: /* MODU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: MODU(reg,reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 38;
			_closure_reg(a, c + 0);
		}
		break;
	case 373: /* RSHI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: RSHI(reg,rc5) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc5_NT] + 2;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 30;
			_closure_reg(a, c + 0);
		}
		break;
	case 374: /* RSHU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: RSHU(reg,rc5) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc5_NT] + 2;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 31;
			_closure_reg(a, c + 0);
		}
		break;
	case 390: /* BANDU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: BANDU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 25;
			_closure_reg(a, c + 0);
		}
		break;
	case 406: /* BCOMU */
		_label(LEFT_CHILD(a));
		/* reg: BCOMU(reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + 2;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 32;
			_closure_reg(a, c + 0);
		}
		break;
	case 422: /* BORU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: BORU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 26;
			_closure_reg(a, c + 0);
		}
		break;
	case 438: /* BXORU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: BXORU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 1;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 27;
			_closure_reg(a, c + 0);
		}
		break;
	case 449: /* DIVF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: DIVF(freg,memf) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_memf_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 10;
			_closure_freg(a, c + 0);
		}
		/* freg: DIVF(freg,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 11;
			_closure_freg(a, c + 0);
		}
		break;
	case 450: /* DIVD */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: DIVD(freg,memf) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_memf_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 8;
			_closure_freg(a, c + 0);
		}
		/* freg: DIVD(freg,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 9;
			_closure_freg(a, c + 0);
		}
		break;
	case 453: /* DIVI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: DIVI(reg,reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 39;
			_closure_reg(a, c + 0);
		}
		break;
	case 454: /* DIVU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: DIVU(reg,reg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_reg_NT] + 0;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 37;
			_closure_reg(a, c + 0);
		}
		break;
	case 465: /* MULF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: MULF(freg,flt) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_flt_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 13;
			_closure_freg(a, c + 0);
		}
		break;
	case 466: /* MULD */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* freg: MULD(freg,flt) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_freg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_flt_NT] + 0;
		if (c + 0 < p->cost[_freg_NT]) {
			p->cost[_freg_NT] = c + 0;
			p->rule._freg = 12;
			_closure_freg(a, c + 0);
		}
		break;
	case 469: /* MULI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: MULI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 14;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 34;
			_closure_reg(a, c + 0);
		}
		/* reg: MULI(con,mr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_con_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mr_NT] + 13;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 35;
			_closure_reg(a, c + 0);
		}
		break;
	case 470: /* MULU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* reg: MULU(reg,mr) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mr_NT] + 13;
		if (c + 0 < p->cost[_reg_NT]) {
			p->cost[_reg_NT] = c + 0;
			p->rule._reg = 36;
			_closure_reg(a, c + 0);
		}
		break;
	case 481: /* EQF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: EQF(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 70;
		}
		break;
	case 482: /* EQD */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: EQD(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 64;
		}
		break;
	case 485: /* EQI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: EQI(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 44;
		}
		/* stmt: EQI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 54;
		}
		break;
	case 497: /* GEF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GEF(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 71;
		}
		break;
	case 498: /* GED */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GED(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 65;
		}
		break;
	case 501: /* GEI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GEI(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 45;
		}
		/* stmt: GEI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 55;
		}
		break;
	case 502: /* GEU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GEU(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 50;
		}
		/* stmt: GEU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 60;
		}
		break;
	case 513: /* GTF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GTF(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 72;
		}
		break;
	case 514: /* GTD */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GTD(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 66;
		}
		break;
	case 517: /* GTI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GTI(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 46;
		}
		/* stmt: GTI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 56;
		}
		break;
	case 518: /* GTU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: GTU(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 51;
		}
		/* stmt: GTU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 61;
		}
		break;
	case 529: /* LEF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LEF(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 73;
		}
		break;
	case 530: /* LED */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LED(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 67;
		}
		break;
	case 533: /* LEI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LEI(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 47;
		}
		/* stmt: LEI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 57;
		}
		break;
	case 534: /* LEU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LEU(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 52;
		}
		/* stmt: LEU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 62;
		}
		break;
	case 545: /* LTF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LTF(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 74;
		}
		break;
	case 546: /* LTD */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LTD(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 68;
		}
		break;
	case 549: /* LTI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LTI(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 48;
		}
		/* stmt: LTI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 58;
		}
		break;
	case 550: /* LTU */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: LTU(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 53;
		}
		/* stmt: LTU(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 63;
		}
		break;
	case 561: /* NEF */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: NEF(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 75;
		}
		break;
	case 562: /* NED */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: NED(cmpf,freg) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_cmpf_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_freg_NT] + 0;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 69;
		}
		break;
	case 565: /* NEI */
		_label(LEFT_CHILD(a));
		_label(RIGHT_CHILD(a));
		/* stmt: NEI(mem,rc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_mem_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_rc_NT] + 5;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 49;
		}
		/* stmt: NEI(reg,mrc) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_reg_NT] + ((struct _state *)(RIGHT_CHILD(a)->x.state))->cost[_mrc_NT] + 4;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 59;
		}
		break;
	case 584: /* JUMPV */
		_label(LEFT_CHILD(a));
		/* stmt: JUMPV(addrjmp) */
		c = ((struct _state *)(LEFT_CHILD(a)->x.state))->cost[_addrjmp_NT] + 3;
		if (c + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = c + 0;
			p->rule._stmt = 43;
		}
		break;
	case 600: /* LABELV */
		/* stmt: LABELV */
		if (0 + 0 < p->cost[_stmt_NT]) {
			p->cost[_stmt_NT] = 0 + 0;
			p->rule._stmt = 42;
		}
		break;
	case 615: /* VREGP */
		break;
	default:
		fatal("_label", "Bad terminal %d\n", OP_LABEL(a));
	}
}

static void _kids(p, eruleno, kids) NODEPTR_TYPE p, kids[]; int eruleno; {
	if (!p)
		fatal("_kids", "Null tree\n", 0);
	if (!kids)
		fatal("_kids", "Null kids\n", 0);
	switch (eruleno) {
	case 193: /* stmt: LABELV */
	case 190: /* addrjmp: ADDRGP */
	case 187: /* addrj: ADDRGP */
	case 147: /* mrca: ADDRGP */
	case 64: /* rc5: CNSTI */
	case 44: /* icon: CNSTU */
	case 43: /* icon: CNSTI */
	case 42: /* icon: CNSTU */
	case 41: /* icon: CNSTI */
	case 40: /* icon: CNSTU */
	case 39: /* icon: CNSTI */
	case 38: /* con1: CNSTU */
	case 37: /* con1: CNSTI */
	case 36: /* base: ADDRLP */
	case 35: /* base: ADDRFP */
	case 30: /* baseaddr: ADDRGP */
	case 29: /* acon: CNSTU */
	case 28: /* acon: CNSTS */
	case 27: /* acon: CNSTP */
	case 26: /* acon: CNSTI */
	case 25: /* acon: CNSTC */
	case 24: /* acon: ADDRGP */
	case 17: /* con: CNSTU */
	case 16: /* con: CNSTS */
	case 15: /* con: CNSTP */
	case 14: /* con: CNSTI */
	case 13: /* con: CNSTC */
	case 6: /* freg: INDIRF(VREGP) */
	case 5: /* freg: INDIRD(VREGP) */
	case 4: /* reg: INDIRS(VREGP) */
	case 3: /* reg: INDIRP(VREGP) */
	case 2: /* reg: INDIRI(VREGP) */
	case 1: /* reg: INDIRC(VREGP) */
		break;
	case 12: /* stmt: ASGNF(VREGP,freg) */
	case 11: /* stmt: ASGND(VREGP,freg) */
	case 10: /* stmt: ASGNS(VREGP,reg) */
	case 9: /* stmt: ASGNP(VREGP,reg) */
	case 8: /* stmt: ASGNI(VREGP,reg) */
	case 7: /* stmt: ASGNC(VREGP,reg) */
		kids[0] = RIGHT_CHILD(p);
		break;
	case 218: /* cmpf: freg */
	case 192: /* addrjmp: mem */
	case 191: /* addrjmp: reg */
	case 189: /* addrj: mem */
	case 188: /* addrj: reg */
	case 168: /* flt: freg */
	case 167: /* flt: memf */
	case 159: /* freg: memf */
	case 146: /* mrca: rc */
	case 145: /* mrca: mem */
	case 82: /* reg: con */
	case 81: /* reg: mrw */
	case 80: /* reg: mrb */
	case 79: /* reg: mr */
	case 78: /* reg: addr */
	case 77: /* mrc: rc */
	case 76: /* mrc: memw */
	case 75: /* mrc: memb */
	case 74: /* mrc: mem */
	case 73: /* mrw: memw */
	case 72: /* mrw: reg */
	case 71: /* mrb: memb */
	case 70: /* mrb: reg */
	case 69: /* mr: mem */
	case 68: /* mr: reg */
	case 67: /* rc: con */
	case 66: /* rc: reg */
	case 65: /* rc5: reg */
	case 59: /* addr: index */
	case 49: /* addr: baseaddr */
	case 48: /* addr: base */
	case 45: /* index: reg */
	case 31: /* base: reg */
	case 19: /* stmt: freg */
	case 18: /* stmt: reg */
		kids[0] = p;
		break;
	case 245: /* stmt: RETD(freg) */
	case 244: /* stmt: RETF(freg) */
	case 243: /* stmt: RETI(reg) */
	case 242: /* stmt: CALLD(addrj) */
	case 241: /* stmt: CALLD(addrj) */
	case 240: /* freg: CALLD(addrj) */
	case 239: /* freg: CALLD(addrj) */
	case 238: /* stmt: CALLF(addrj) */
	case 237: /* stmt: CALLF(addrj) */
	case 236: /* freg: CALLF(addrj) */
	case 235: /* freg: CALLF(addrj) */
	case 234: /* stmt: CALLV(addrj) */
	case 233: /* stmt: CALLV(addrj) */
	case 232: /* reg: CALLI(addrj) */
	case 231: /* reg: CALLI(addrj) */
	case 216: /* cmpf: INDIRF(addr) */
	case 215: /* cmpf: INDIRD(addr) */
	case 194: /* stmt: JUMPV(addrjmp) */
	case 186: /* freg: CVID(reg) */
	case 184: /* reg: CVDI(freg) */
	case 182: /* freg: CVDF(freg) */
	case 181: /* freg: CVFD(freg) */
	case 166: /* freg: NEGF(freg) */
	case 165: /* freg: NEGD(freg) */
	case 164: /* stmt: ARGF(freg) */
	case 163: /* stmt: ARGD(freg) */
	case 157: /* memf: INDIRF(addr) */
	case 156: /* memf: INDIRD(addr) */
	case 154: /* stmt: ARGP(mrca) */
	case 153: /* stmt: ARGI(mrca) */
	case 144: /* reg: CVUS(reg) */
	case 143: /* reg: CVUC(reg) */
	case 142: /* reg: CVIS(reg) */
	case 141: /* reg: CVIC(reg) */
	case 140: /* reg: CVSU(reg) */
	case 139: /* reg: CVSI(reg) */
	case 138: /* reg: CVCU(reg) */
	case 137: /* reg: CVCI(reg) */
	case 132: /* reg: CVUP(reg) */
	case 131: /* reg: CVUI(reg) */
	case 130: /* reg: CVPU(reg) */
	case 129: /* reg: CVIU(reg) */
	case 102: /* reg: NEGI(reg) */
	case 101: /* reg: BCOMU(reg) */
	case 87: /* reg: LOADU(reg) */
	case 86: /* reg: LOADS(reg) */
	case 85: /* reg: LOADP(reg) */
	case 84: /* reg: LOADI(reg) */
	case 83: /* reg: LOADC(reg) */
	case 63: /* mem: INDIRP(addr) */
	case 62: /* mem: INDIRI(addr) */
	case 61: /* memw: INDIRS(addr) */
	case 60: /* memb: INDIRC(addr) */
	case 23: /* reg: CVUP(reg) */
	case 22: /* reg: CVUI(reg) */
	case 21: /* reg: CVPU(reg) */
	case 20: /* reg: CVIU(reg) */
		kids[0] = LEFT_CHILD(p);
		break;
	case 230: /* stmt: NEF(cmpf,freg) */
	case 229: /* stmt: LTF(cmpf,freg) */
	case 228: /* stmt: LEF(cmpf,freg) */
	case 227: /* stmt: GTF(cmpf,freg) */
	case 226: /* stmt: GEF(cmpf,freg) */
	case 225: /* stmt: EQF(cmpf,freg) */
	case 224: /* stmt: NED(cmpf,freg) */
	case 223: /* stmt: LTD(cmpf,freg) */
	case 222: /* stmt: LED(cmpf,freg) */
	case 221: /* stmt: GTD(cmpf,freg) */
	case 220: /* stmt: GED(cmpf,freg) */
	case 219: /* stmt: EQD(cmpf,freg) */
	case 214: /* stmt: LTU(reg,mrc) */
	case 213: /* stmt: LEU(reg,mrc) */
	case 212: /* stmt: GTU(reg,mrc) */
	case 211: /* stmt: GEU(reg,mrc) */
	case 210: /* stmt: NEI(reg,mrc) */
	case 209: /* stmt: LTI(reg,mrc) */
	case 208: /* stmt: LEI(reg,mrc) */
	case 207: /* stmt: GTI(reg,mrc) */
	case 206: /* stmt: GEI(reg,mrc) */
	case 205: /* stmt: EQI(reg,mrc) */
	case 204: /* stmt: LTU(mem,rc) */
	case 203: /* stmt: LEU(mem,rc) */
	case 202: /* stmt: GTU(mem,rc) */
	case 201: /* stmt: GEU(mem,rc) */
	case 200: /* stmt: NEI(mem,rc) */
	case 199: /* stmt: LTI(mem,rc) */
	case 198: /* stmt: LEI(mem,rc) */
	case 197: /* stmt: GTI(mem,rc) */
	case 196: /* stmt: GEI(mem,rc) */
	case 195: /* stmt: EQI(mem,rc) */
	case 180: /* freg: SUBF(freg,freg) */
	case 179: /* freg: SUBF(freg,memf) */
	case 178: /* freg: SUBD(freg,freg) */
	case 177: /* freg: SUBD(freg,memf) */
	case 176: /* freg: MULF(freg,flt) */
	case 175: /* freg: MULD(freg,flt) */
	case 174: /* freg: DIVF(freg,freg) */
	case 173: /* freg: DIVF(freg,memf) */
	case 172: /* freg: DIVD(freg,freg) */
	case 171: /* freg: DIVD(freg,memf) */
	case 170: /* freg: ADDF(freg,flt) */
	case 169: /* freg: ADDD(freg,flt) */
	case 161: /* stmt: ASGNF(addr,freg) */
	case 160: /* stmt: ASGND(addr,freg) */
	case 151: /* stmt: ASGNS(addr,rc) */
	case 150: /* stmt: ASGNP(addr,rc) */
	case 149: /* stmt: ASGNI(addr,rc) */
	case 148: /* stmt: ASGNC(addr,rc) */
	case 128: /* reg: MODI(reg,reg) */
	case 127: /* reg: DIVI(reg,reg) */
	case 126: /* reg: MODU(reg,reg) */
	case 125: /* reg: DIVU(reg,reg) */
	case 124: /* reg: MULU(reg,mr) */
	case 123: /* reg: MULI(con,mr) */
	case 122: /* reg: MULI(reg,mrc) */
	case 100: /* reg: RSHU(reg,rc5) */
	case 99: /* reg: RSHI(reg,rc5) */
	case 98: /* reg: LSHU(reg,rc5) */
	case 97: /* reg: LSHI(reg,rc5) */
	case 96: /* reg: BXORU(reg,mrc) */
	case 95: /* reg: BORU(reg,mrc) */
	case 94: /* reg: BANDU(reg,mrc) */
	case 93: /* reg: SUBU(reg,mrc) */
	case 92: /* reg: SUBP(reg,mrc) */
	case 91: /* reg: SUBI(reg,mrc) */
	case 90: /* reg: ADDU(reg,mrc) */
	case 89: /* reg: ADDP(reg,mrc) */
	case 88: /* reg: ADDI(reg,mrc) */
	case 58: /* addr: ADDU(index,reg) */
	case 57: /* addr: ADDU(reg,baseaddr) */
	case 56: /* addr: ADDU(index,baseaddr) */
	case 55: /* addr: ADDP(index,reg) */
	case 54: /* addr: ADDP(reg,baseaddr) */
	case 53: /* addr: ADDP(index,baseaddr) */
	case 52: /* addr: ADDI(index,reg) */
	case 51: /* addr: ADDI(reg,baseaddr) */
	case 50: /* addr: ADDI(index,baseaddr) */
	case 47: /* index: LSHU(reg,icon) */
	case 46: /* index: LSHI(reg,icon) */
	case 34: /* base: ADDU(reg,acon) */
	case 33: /* base: ADDP(reg,acon) */
	case 32: /* base: ADDI(reg,acon) */
		kids[0] = LEFT_CHILD(p);
		kids[1] = RIGHT_CHILD(p);
		break;
	case 121: /* stmt: ASGNI(addr,RSHU(mem,rc5)) */
	case 120: /* stmt: ASGNI(addr,RSHI(mem,rc5)) */
	case 119: /* stmt: ASGNI(addr,LSHU(mem,rc5)) */
	case 118: /* stmt: ASGNI(addr,LSHI(mem,rc5)) */
	case 115: /* stmt: ASGNI(addr,BXORU(mem,rc)) */
	case 114: /* stmt: ASGNI(addr,BORU(mem,rc)) */
	case 113: /* stmt: ASGNI(addr,BANDU(mem,rc)) */
	case 112: /* stmt: ASGNI(addr,SUBU(mem,rc)) */
	case 111: /* stmt: ASGNI(addr,SUBI(mem,rc)) */
	case 110: /* stmt: ASGNI(addr,ADDU(mem,rc)) */
	case 109: /* stmt: ASGNI(addr,ADDI(mem,rc)) */
	case 108: /* stmt: ASGNP(addr,SUBP(mem,con1)) */
	case 107: /* stmt: ASGNI(addr,SUBU(mem,con1)) */
	case 106: /* stmt: ASGNI(addr,SUBI(mem,con1)) */
	case 105: /* stmt: ASGNP(addr,ADDP(mem,con1)) */
	case 104: /* stmt: ASGNI(addr,ADDU(mem,con1)) */
	case 103: /* stmt: ASGNI(addr,ADDI(mem,con1)) */
		kids[0] = LEFT_CHILD(p);
		kids[1] = LEFT_CHILD(RIGHT_CHILD(p));
		kids[2] = RIGHT_CHILD(RIGHT_CHILD(p));
		break;
	case 183: /* stmt: ASGNI(addr,CVDI(freg)) */
	case 162: /* stmt: ASGNF(addr,CVDF(freg)) */
	case 152: /* stmt: ASGNB(reg,INDIRB(reg)) */
	case 117: /* stmt: ASGNI(addr,NEGI(mem)) */
	case 116: /* stmt: ASGNI(addr,BCOMU(mem)) */
		kids[0] = LEFT_CHILD(p);
		kids[1] = LEFT_CHILD(RIGHT_CHILD(p));
		break;
	case 217: /* cmpf: CVFD(INDIRF(addr)) */
	case 185: /* freg: CVID(INDIRI(addr)) */
	case 158: /* memf: CVFD(INDIRF(addr)) */
	case 155: /* stmt: ARGB(INDIRB(reg)) */
	case 136: /* reg: CVSU(INDIRS(addr)) */
	case 135: /* reg: CVSI(INDIRS(addr)) */
	case 134: /* reg: CVCU(INDIRC(addr)) */
	case 133: /* reg: CVCI(INDIRC(addr)) */
		kids[0] = LEFT_CHILD(LEFT_CHILD(p));
		break;
	default:
		fatal("_kids", "Bad rule number %d\n", eruleno);
	}
}


static void 
progbeg(argc, argv)
	char *argv[];
{
	int i;

	{
		union {
			char c;
			int i;
		} u;
		u.i = 0;
		u.c = 1;
		swap = (u.i == 1) != IR->little_endian;
	}
	parseflags(argc, argv);
	intreg[EAX] = mkreg("%%eax", EAX, 1, IREG);
	intreg[EDX] = mkreg("%%edx", EDX, 1, IREG);
	intreg[ECX] = mkreg("%%ecx", ECX, 1, IREG);
	intreg[EBX] = mkreg("%%ebx", EBX, 1, IREG);
	intreg[ESI] = mkreg("%%esi", ESI, 1, IREG);
	intreg[EDI] = mkreg("%%edi", EDI, 1, IREG);
	shortreg[EAX] = mkreg("%%ax", EAX, 1, IREG);
	shortreg[ECX] = mkreg("%%cx", ECX, 1, IREG);
	shortreg[EDX] = mkreg("%%dx", EDX, 1, IREG);
	shortreg[EBX] = mkreg("%%bx", EBX, 1, IREG);
	shortreg[ESI] = mkreg("%%si", ESI, 1, IREG);
	shortreg[EDI] = mkreg("%%di", EDI, 1, IREG);

	charreg[EAX] = mkreg("%%al", EAX, 1, IREG);
	charreg[ECX] = mkreg("%%cl", ECX, 1, IREG);
	charreg[EDX] = mkreg("%%dl", EDX, 1, IREG);
	charreg[EBX] = mkreg("%%bl", EBX, 1, IREG);
	for (i = 0; i < 8; i++)
		fltreg[i] = mkreg("%d", i, 0, FREG);
	rmap[C] = mkwildcard(charreg);
	rmap[S] = mkwildcard(shortreg);
	rmap[P] = rmap[B] = rmap[U] = rmap[I] = mkwildcard(intreg);
	rmap[F] = rmap[D] = mkwildcard(fltreg);
	tmask[IREG] = (1 << EDI) | (1 << ESI) | (1 << EBX)
		| (1 << EDX) | (1 << ECX) | (1 << EAX);
	vmask[IREG] = 0;
	tmask[FREG] = 0xff;
	vmask[FREG] = 0;
	print("\t.text\n");
	cseg = 0;
	quo = mkreg("%%eax", EAX, 1, IREG);
	quo->x.regnode->mask |= 1<<EDX;
	rem = mkreg("%%edx", EDX, 1, IREG);
	rem->x.regnode->mask |= 1<<EAX;
}

static void 
segment(n)
{
	if (n == cseg)
		return;
	cseg = n;
	if (n == CODE)
		print("\t.text\n");
	else if (cseg == BSS)
    	    	print("\t.bss\n");
	else if (cseg == DATA || cseg == LIT)
		print("\t.data\n");
}

static void 
progend()
{
	segment(0);
}
static void target(p) Node p; {
	assert(p);
	switch (p->op) {
	case RSHI: case RSHU: case LSHI: case LSHU:
		if (generic(p->kids[1]->op) != CNST
		&& !(   generic(p->kids[1]->op) == INDIR
		     && p->kids[1]->kids[0]->op == VREG+P
		     && p->kids[1]->syms[RX]->u.t.cse
		     && generic(p->kids[1]->syms[RX]->u.t.cse->op) == CNST
)) {
			rtarget(p, 1, intreg[ECX]);
			setreg(p, intreg[EAX]);
		}
		break;
	case MULU:
		setreg(p, quo);
		rtarget(p, 0, intreg[EAX]);
		break;
	case DIVI: case DIVU:
		setreg(p, quo);
		rtarget(p, 0, intreg[EAX]);
		rtarget(p, 1, intreg[ECX]);
		break;
	case MODI: case MODU:
		setreg(p, rem);
		rtarget(p, 0, intreg[EAX]);
		rtarget(p, 1, intreg[ECX]);
		break;
	case ASGNB:
		rtarget(p, 0, intreg[EDI]);
		rtarget(p, 1, intreg[ESI]);
		break;
	case ARGB:
		rtarget(p->kids[0], 0, intreg[ESI]);
		break;
	case CALLI: case CALLV:
		setreg(p, intreg[EAX]);
		break;
	case RETI:
		rtarget(p, 0, intreg[EAX]);
		break;
	}
}

static void clobber(p) Node p; {
	static int nstack = 0;

	assert(p);
	nstack = ckstack(p, nstack);
	assert(p->count > 0 || nstack == 0);
	switch (p->op) {
     
        case DIVI: case DIVU: case MULU:
               spill(1 << EDX, IREG, p);
               break;
        case MODI: case MODU:
               spill(1 << EAX, IREG, p);
               break;

	case ASGNB: case ARGB:
		spill(1<<ECX | 1<<ESI | 1<<EDI, IREG, p);
		break;
	case EQD: case LED: case GED: case LTD: case GTD: case NED:
	case EQF: case LEF: case GEF: case LTF: case GTF: case NEF:
		spill(1<<EAX, IREG, p);
		break;
	case CALLD: case CALLF:
		spill(1<<EDX | 1<<EAX, IREG, p);
		break;
	}
}


#define isfp(p) (optype((p)->op)==F || optype((p)->op)==D)

static int ckstack(p, n) Node p; int n; {
	int i;

	for (i = 0; i < NELEMS(p->x.kids) && p->x.kids[i]; i++)
		if (isfp(p->x.kids[i]))
			n--;
	if (isfp(p) && p->count > 0)
		n++;
	if (n > 8)
		error("expression too complicated\n");
	debug(fprint(2, "(ckstack(%x)=%d)\n", p, n));
	assert(n >= 0);
	return n;
}

static int
hasargs(p)
	Node p;
{
	assert(p);
	assert(generic(p->op) == CALL);
	assert(p->syms[0]);
	if (p->syms[0]->u.c.v.i > 0)
		return 0;
	return LBURG_MAX;
}

static int 
memop(p)
	Node p;
{
	assert(p);
	assert(generic(p->op) == ASGN);
	assert(p->kids[0]);
	assert(p->kids[1]);
	if (generic(p->kids[1]->kids[0]->op) == INDIR
	    && sametree(p->kids[0], p->kids[1]->kids[0]->kids[0]))
		return 3;
	else
		return LBURG_MAX;
}

static int 
sametree(p, q)
	Node p, q;
{
	return p == NULL && q == NULL
		|| p && q && p->op == q->op && p->syms[0] == q->syms[0]
		&& sametree(p->kids[0], q->kids[0])
		&& sametree(p->kids[1], q->kids[1]);
}

static void
emit0(q)
	Node q;
{
#if _EMIT_DEBUG
	Node p = q;
	for (; p; p = p->x.next) {
		if (p->op == LABEL+V) {
			assert(p->syms[0]);
			print("# %s:\n", p->syms[0]->x.name);
		} else {
			int i;
			print("# node%c%d %s count=%d", p->x.listed ? '\'' : '#', p->x.inst,
				opname(p->op), p->count);
			for (i = 0; i < NELEMS(p->kids) && p->kids[i]; i++)
				print(" #%d", p->kids[i]->x.inst);
			for (i = 0; i < NELEMS(p->syms) && p->syms[i]; i++) {
				if (p->syms[i]->x.name)
					print(" %s", p->syms[i]->x.name);
				if (p->syms[i]->name != p->syms[i]->x.name)
					print(" (%s)", p->syms[i]->name);
			}
			print("\n");
		}
	}
#endif
	emit(q);
}

static void 
emit2(p)
	Node p;
{
#define preg(f) ((f)[getregnum(p->x.kids[0])]->x.name)

	switch (p->op) {
	case CVCI:
		print("\tmovsbl\t%s,%s\n",
		      preg(charreg),
		      p->syms[RX]->x.name);
		break;
	case CVCU:
		print("\tmovzbl\t%s,%s\n",
		      preg(charreg),
		      p->syms[RX]->x.name);
		break;
	case CVSI:
		print("\tmovswl\t%s,%s\n",
		      preg(shortreg),
		      p->syms[RX]->x.name);
		break;
	case CVSU:
		print("\tmovzwl\t%s,%s\n",
		      preg(shortreg),
		      p->syms[RX]->x.name);
		break;
	case CVIC: case CVIS:
	case CVUC: case CVUS:
		{ char *dst = shortreg[getregnum(p)]->x.name;
		  char *src = preg(shortreg);
		  if (dst != src)
			print("\tmovl\t%s,%s\n", src, dst);
		}
		break;
	}
}

static void 
doarg(p)
	Node p;
{
	assert(p && p->syms[0]);
	mkactual(4, p->syms[0]->u.c.v.i);
}

static void 
blkfetch(k, off, reg, tmp)
{
}

static void 
blkstore(k, off, reg, tmp)
{
}

static void 
blkloop(dreg, doff, sreg, soff, size, tmps)
	int tmps[];
{
}

static void 
local(p)
	Symbol p;
{
	if (isfloat(p->type))
		p->sclass = AUTO;
	if (askregvar(p, rmap[ttob(p->type)]) == 0)
		mkauto(p);
}

static void 
function(f, caller, callee, n)
	Symbol f, callee[], caller[];
	int n;
{
	int i;

	print("\t.type\t%s,@function\n", f->x.name);
	print("%s:\n", f->x.name);
	print("\tpushl\t%%ebx\n");
	print("\tpushl\t%%esi\n");
	print("\tpushl\t%%edi\n");
	print("\tpushl\t%%ebp\n");
	print("\tmovl\t%%esp,%%ebp\n");

	usedmask[0] = usedmask[1] = 0;
	freemask[0] = freemask[1] = ~(unsigned) 0;
	offset = 16 + 4;
	for (i = 0; callee[i]; i++) {
		Symbol p = callee[i];
		Symbol q = caller[i];
		assert(q);
		offset = roundup(offset, q->type->align);
		p->x.offset = q->x.offset = offset;
		p->x.name = q->x.name = stringf("%d", p->x.offset);
		p->sclass = q->sclass = AUTO;
		offset += roundup(q->type->size, 4);
	}
	assert(caller[i] == 0);
	offset = maxoffset = 0;
	gencode(caller, callee);
	framesize = roundup(maxoffset, 4);
	if (framesize > 0)
		print("\tsubl\t$%d,%%esp\n", framesize);
	emitcode();

	print("\tleave\n");
	print("\tpopl\t%%edi\n");
	print("\tpopl\t%%esi\n");
	print("\tpopl\t%%ebx\n");
	print("\tret\n");
	{ int l = genlabel(1);
	  print("L%d:\n", l);
	  print("\t.size\t%s,L%d-%s\n", f->x.name, l, f->x.name);
	}
}

static void 
defsymbol(p)
	Symbol p;
{
	if (p->scope >= LOCAL && p->sclass == STATIC)
		p->x.name = stringf("L%d", genlabel(1));
	else if (p->generated)
		p->x.name = stringf("L%s", p->name);
	else if (p->scope == GLOBAL || p->sclass == EXTERN)
		p->x.name = stringf("_%s", p->name);
/*
	else if (p->scope == CONSTANTS
		 && (isint(p->type) || isptr(p->type))
		 && p->name[0] == '0' && p->name[1] == 'x')
		p->x.name = stringf("0%sH", &p->name[2]);
*/
	else
		p->x.name = p->name;
}

static void 
address(q, p, n)
	Symbol q, p;
	int n;
{
	if (p->scope == GLOBAL
	    || p->sclass == STATIC || p->sclass == EXTERN)
		q->x.name = stringf("%s%s%d",
				    p->x.name, n >= 0 ? "+" : "", n);
	else {
		q->x.offset = p->x.offset + n;
		q->x.name = stringd(q->x.offset);
	}
}

static void 
defconst(ty, v)
	Value v;
{
	switch (ty) {
	case C:
		print("\t.byte\t%d\n", v.uc);
		return;
	case S:
		print("\t.word\t%d\n", v.ss);
		return;
	case I:
		print("\t.long\t%d\n", v.i);
		return;
	case U:
		print("\t.long\t0x%x\n", v.u);
		return;
	case P:
		print("\t.long\t0x%x\n", v.p);
		return;
	case F:
		print("\t.long\t0x%x\n", *(unsigned *) &v.f);
		return;
	case D:{
			unsigned *p = (unsigned *) &v.d;
			print("\t.long\t0x%x,0x%x\n", p[swap], p[1 - swap]);
			return;
		}
	}
	assert(0);
}

static void 
defaddress(p)
	Symbol p;
{
	print("\t.long\t%s\n", p->x.name);
}

static void 
defstring(n, str)
	char *str;
{
	char *s;
#if 1
	for (s = str; s < str + n; s++)
		print("\t.byte\t%d\n", *s);
#else
	print("\t.ascii\t\"", *s);
	for (s = str; s < str + n; s++)
		if (*s < 0x20)
			print("\\0%o", *s);
		else
			print("%c", *s);
	print("\"\n");
#endif
}

static void 
export(p)
	Symbol p;
{
	print("\t.globl\t%s\n", p->x.name);
}

static void 
import(p)
	Symbol p;
{
	int oldseg = cseg;

	if (p->ref > 0) {
		segment(0);
		print("\t.extern\t%s\n", p->x.name);
		segment(oldseg);
	}
}

static void global (p)
	Symbol p;
{
	print("\t.align\t%d\n", p->type->align > 4 ? 4 : p->type->align);
	if (!p->generated)
		print("\t.type\t%s,@%s\n", p->x.name,
			isfunc(p->type) ? "function" : "object");
	if (p->u.seg == BSS) {
		if (p->sclass == STATIC)
			print("\t.lcomm\t%s,%d\n", p->x.name, p->type->size);
		else
			print("\t.comm\t%s,%d\n", p->x.name, p->type->size);
	} else {
		if (!p->generated)
			print("\t.size\t%s,%d\n", p->x.name, p->type->size);
		print("%s:\n", p->x.name);
	}
}

static void 
space(n)
{
	if (cseg != BSS)
		print("\t.space\t%d\n", n);
}

#include <stab.h>
static char *currentfile;       /* current file name */
static int ntypes;

static void stabblock ARGS((int, int, Symbol*));
static void stabfend ARGS((Symbol, int));
static void stabinit ARGS((char *, int, char *[]));
static void stabline ARGS((Coordinate *));
static void stabsym ARGS((Symbol));
static void stabtype ARGS((Symbol));

static void asgncode ARGS((Type, int));
static void dbxout ARGS((Type));
static int dbxtype ARGS((Type));
static int emittype ARGS((Type, int, int));

/* asgncode - assign type code to ty */
static void asgncode(ty, lev) Type ty; {
	if (ty->x.marked || ty->x.typeno)
		return;
	ty->x.marked = 1;
	switch (ty->op) {
	case VOLATILE: case CONST: case VOLATILE+CONST:
		asgncode(ty->type, lev);
		ty->x.typeno = ty->type->x.typeno;
		break;
	case POINTER: case FUNCTION: case ARRAY:
		asgncode(ty->type, lev + 1);
		/* fall thru */
	case VOID: case CHAR: case SHORT: case INT: case UNSIGNED:
	case FLOAT: case DOUBLE:
		break;
	case STRUCT: case UNION: {
		Field p;
		for (p = fieldlist(ty); p; p = p->link)
			asgncode(p->type, lev + 1);
		/* fall thru */
	case ENUM:
		if (ty->x.typeno == 0)
			ty->x.typeno = ++ntypes;
		if (lev > 0 && (*ty->u.sym->name < '0' || *ty->u.sym->name > '9'))
			dbxout(ty);
		break;
		}
	default:
		assert(0);
	}
}

/* dbxout - output .stabs entry for type ty */
static void dbxout(ty) Type ty; {
	ty = unqual(ty);
	if (!ty->x.printed) {
		int col = 0;
		print(".stabs \""), col += 8;
		if (ty->u.sym && !(isfunc(ty) || isarray(ty) || isptr(ty)))
			print("%s", ty->u.sym->name), col += strlen(ty->u.sym->name);
		print(":%c", isstruct(ty) || isenum(ty) ? 'T' : 't'), col += 2;
		emittype(ty, 0, col);
		print("\",%d,0,0,0\n", N_LSYM);
	}
}

/* dbxtype - emit a stabs entry for type ty, return type code */
static int dbxtype(ty) Type ty; {
	asgncode(ty, 0);
	dbxout(ty);
	return ty->x.typeno;
}

/*
 * emittype - emit ty's type number, emitting its definition if necessary.
 * Returns the output column number after emission; col is the approximate
 * output column before emission and is used to emit continuation lines for long
 * struct, union, and enum types. Continuations are not emitted for other types,
 * even if the definition is long. lev is the depth of calls to emittype.
 */
static int emittype(ty, lev, col) Type ty; {
	int tc = ty->x.typeno;

	if (isconst(ty) || isvolatile(ty)) {
		col = emittype(ty->type, lev, col);
		ty->x.typeno = ty->type->x.typeno;
		ty->x.printed = 1;
		return col;
	}
	if (tc == 0) {
		ty->x.typeno = tc = ++ntypes;
/*              fprint(2,"`%t'=%d\n", ty, tc); */
	}
	print("%d", tc), col += 3;
	if (ty->x.printed)
		return col;
	ty->x.printed = 1;
	switch (ty->op) {
	case VOID:	/* void is defined as itself */
		print("=%d", tc), col += 1+3;
		break;
	case CHAR:	/* unsigned char is a subrange of int */
		if (ty == unsignedchar)
			print("=r1;0;255;"), col += 10;
		else	/* following pcc, char is a subrange of itself */
			print("=r%d;-128;127;", tc), col += 2+3+10;
		break;
	case SHORT:	/* short is a subrange of int */
		if (ty == unsignedshort)
			print("=r1;0;65535;"), col += 12;
		else	/* signed */
			print("=r1;-32768;32767;"), col += 17;
		break;
	case INT:	/* int is a subrange of itself */
		print("=r1;%d;%d;", INT_MIN, INT_MAX), col += 4+11+1+10+1;
		break;
	case UNSIGNED:	/* unsigned is a subrange of int */
		print("=r1;0;-1;"), col += 9;
		break;
	case FLOAT: case DOUBLE:	/* float, double get sizes instead of ranges */
		print("=r1;%d;0;", ty->size), col += 4+1+3;
		break;
	case POINTER:
		print("=*"), col += 2;
		col = emittype(ty->type, lev + 1, col);
		break;
	case FUNCTION:
		print("=f"), col += 2;
		col = emittype(ty->type, lev + 1, col);
		break;
	case ARRAY:	/* array includes subscript as an int range */
		if (ty->size && ty->type->size)
			print("=ar1;0;%d;", ty->size/ty->type->size - 1), col += 7+3+1;
		else
			print("=ar1;0;-1;"), col += 10;
		col = emittype(ty->type, lev + 1, col);
		break;
	case STRUCT: case UNION: {
		Field p;
		if (!ty->u.sym->defined) {
			print("=x%c%s:", ty->op == STRUCT ? 's' : 'u', ty->u.sym->name);
			col += 2+1+strlen(ty->u.sym->name)+1;
			break;
		}
		if (lev > 0 && (*ty->u.sym->name < '0' || *ty->u.sym->name > '9')) {
			ty->x.printed = 0;
			break;
		}
		print("=%c%d", ty->op == STRUCT ? 's' : 'u', ty->size), col += 1+1+3;
		for (p = fieldlist(ty); p; p = p->link) {
			if (p->name)
				print("%s:", p->name), col += strlen(p->name)+1;
			else
				print(":"), col += 1;
			col = emittype(p->type, lev + 1, col);
			if (p->lsb)
				print(",%d,%d;", 8*p->offset +
					(IR->little_endian ? fieldright(p) : fieldleft(p)),
					fieldsize(p));
			else
				print(",%d,%d;", 8*p->offset, 8*p->type->size);
			col += 1+3+1+3+1;	/* accounts for ,%d,%d; */
			if (col >= 80 && p->link) {
				print("\\\\\",%d,0,0,0\n.stabs \"", N_LSYM);
				col = 8;
			}
		}
		print(";"), col += 1;
		break;
		}
	case ENUM: {
		Symbol *p;
		if (lev > 0 && (*ty->u.sym->name < '0' || *ty->u.sym->name > '9')) {
			ty->x.printed = 0;
			break;
		}
		print("=e"), col += 2;
		for (p = ty->u.sym->u.idlist; *p; p++) {
			print("%s:%d,", (*p)->name, (*p)->u.value), col += strlen((*p)->name)+3;
			if (col >= 80 && p[1]) {
				print("\\\\\",%d,0,0,0\n.stabs \"", N_LSYM);
				col = 8;
			}
		}
		print(";"), col += 1;
		break;
		}
	default:
		assert(0);
	}
	return col;
}

/* stabblock - output a stab entry for '{' or '}' at level lev */
static void stabblock(brace, lev, p) Symbol *p; {
	if (brace == '{')
		while (*p)
			stabsym(*p++);
	print(".stabd 0x%x,0,%d\n", brace == '{' ? N_LBRAC : N_RBRAC, lev);
}

/* stabfend - end of function p */
static void stabfend(p, line) Symbol p; {}

/* stabinit - initialize stab output */
static void stabinit(file, argc, argv) char *file, *argv[]; {
	typedef void (*Closure) ARGS((Symbol, void *));

	if (file && *file) {
		(*IR->segment)(CODE);
		print("Ltext:.stabs \"%s\",0x%x,0,0,Ltext\n", file, N_SO);
		currentfile = file;
	}
	dbxtype(inttype);
	dbxtype(chartype);
	dbxtype(doubletype);
	dbxtype(floattype);
	dbxtype(longdouble);
	dbxtype(longtype);
	dbxtype(shorttype);
	dbxtype(signedchar);
	dbxtype(unsignedchar);
	dbxtype(unsignedlong);
	dbxtype(unsignedshort);
	dbxtype(unsignedtype);
	dbxtype(voidtype);
	foreach(types, GLOBAL, (Closure)stabtype, NULL);
}

/* stabline - emit stab entry for source coordinate *cp */
static void stabline(cp) Coordinate *cp; {
	if (cp->file && cp->file != currentfile) {
		int lab = genlabel(1);
		print("L%d: .stabs \"%s\",0x%x,0,0,L%d\n", lab,
				cp->file, N_SOL, lab);
		currentfile = cp->file;
	}
	print(".stabd 0x%x,0,%d\n", N_SLINE, cp->y);
}

/* stabsym - output a stab entry for symbol p */
static void stabsym(p) Symbol p; {
	int code, tc, sz = p->type->size;

	if (p->generated || p->computed)
		return;
	if (isfunc(p->type)) {
		print(".stabs \"%s:%c%d\",%d,0,0,%s\n", p->name,
			p->sclass == STATIC ? 'f' : 'F', dbxtype(freturn(p->type)),
			N_FUN, p->x.name);
		return;
	}
	if (!IR->wants_argb && p->scope == PARAM && p->structarg) {
		assert(isptr(p->type) && isstruct(p->type->type));
		tc = dbxtype(p->type->type);
		sz = p->type->type->size;
	} else
		tc = dbxtype(p->type);
	if (p->sclass == AUTO && p->scope == GLOBAL || p->sclass == EXTERN) {
		print(".stabs \"%s:G", p->name);
		code = N_GSYM;
	} else if (p->sclass == STATIC) {
		print(".stabs \"%s:%c%d\",%d,0,0,%s\n", p->name, p->scope == GLOBAL ? 'S' : 'V',
			tc, p->u.seg == BSS ? N_LCSYM : N_STSYM, p->x.name);
		return;
	} else if (p->sclass == REGISTER) {
		if (p->scope > PARAM) {
			int r = p->x.regnode->number;
			if (p->x.regnode->set == FREG)
				r += 32;	/* floating point */
			print(".stabs \"%s:r%d\",%d,0,", p->name, tc, N_RSYM);
			print("%d,%d\n", sz, r);
		}
		return;
	} else if (p->scope == PARAM) {
		print(".stabs \"%s:p", p->name);
		code = N_PSYM;
	} else if (p->scope >= LOCAL) {
		print(".stabs \"%s:", p->name);
		code = N_LSYM;
	} else
		assert(0);
	print("%d\",%d,0,0,%s\n", tc, code,
		p->scope >= PARAM && p->sclass != EXTERN ? p->x.name : "0");
}

/* stabtype - output a stab entry for type *p */
static void stabtype(p) Symbol p; {
	if (p->type) {
		if (p->sclass == 0)
			dbxtype(p->type);
		else if (p->sclass == TYPEDEF)
			print(".stabs \"%s:t%d\",%d,0,0,0\n", p->name, dbxtype(p->type), N_LSYM);
	}
}

Interface x86freebsdIR = {
	1, 1, 0,		/* char */
	2, 2, 0,		/* short */
	4, 4, 0,		/* int */
	4, 4, 1,		/* float */
	8, 4, 1,		/* double */
	4, 4, 0,		/* T * */
	0, 1, 0,		/* struct so that ARGB keeps stack aligned */
	1,			/* little_endian */
	0,			/* mulops_calls */
	0,			/* wants_callb */
	1,			/* wants_argb */
	0,			/* left_to_right */
	0,			/* wants_dag */
	address,
	blockbeg,
	blockend,
	defaddress,
	defconst,
	defstring,
	defsymbol,
	emit0,
	export,
	function,
	gen,
	global,
	import,
	local,
	progbeg,
	progend,
	segment,
	space,
	stabblock, 0, 0, stabinit, stabline, stabsym, stabtype,
	{1, blkfetch, blkstore, blkloop,
		_label,
		_rule,
		_nts,
		_kids,
		_opname,
		_arity,
		_string,
		_templates,
		_isinstruction,
		_ntname,
		emit2,
		doarg,
		target,
		clobber,
	}
};
