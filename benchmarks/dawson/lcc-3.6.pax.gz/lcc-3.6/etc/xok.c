#include <string.h>

#ifndef LCCDIR
#define LCCDIR "/bin/"
#define BINDIR "/bin/"
#endif


char *cpp[] = { LCCDIR "lcc-cpp",
	"-D__STDC__=1", "$1", "$2", "$3", 0 };
char *include[] = { "-I/usr/include", 0 };
char *com[] = { LCCDIR "lcc-rcc", "-target=x86-freebsd",
	"$1", "$2", "$3", "", 0 };
char *as[] = { BINDIR "as", "-o", "$3", "$1", "$2", 0 };
char *ld[] = { BINDIR "ld", "-o", "$3", "-dc", "-dp", "-e", "start", "-X",
	"$1", "/usr/lib/crt0.o", "", "", "$2", "", "", "-lm", "", "-lc", 0 };
static char *libprefix = "/cmnusr/local/lib/ldb/";
static char *bbexit = LCCDIR "bbexit.o";

extern char *concat(char *, char *);
extern int access(const char *, int);

int option(char *arg) {
  return 1;
}
