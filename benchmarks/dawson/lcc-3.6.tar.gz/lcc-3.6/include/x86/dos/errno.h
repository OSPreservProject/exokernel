#ifndef __ERRNO
#define __ERRNO

#define EDOM	33
#define ERANGE	34
extern int errno;

#endif /* __ERRNO */
