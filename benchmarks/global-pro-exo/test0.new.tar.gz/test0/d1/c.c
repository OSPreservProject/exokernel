main() { printf("hello"); }
