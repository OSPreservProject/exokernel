/* Generated automatically by the program `genpeep'
from the machine description file `md'.  */

#include "rtl.h"

#include "config.h"

#include "regs.h"

extern rtx peep_operand[];

#define operands peep_operand

int
peephole (ins1)
     rtx ins1;
{
  rtx insn, x, pat;
  int i;
  return 0;
}

rtx peep_operand[2];
