/* Generated automatically by the program `genconfig'
from the machine description file `md'.  */


#define MAX_RECOG_OPERANDS 7

#define MAX_DUP_OPERANDS 1
#define MAX_SETS_PER_INSN 1
#define MAX_CLOBBERS_PER_INSN 0
#define REGISTER_CONSTRAINTS
