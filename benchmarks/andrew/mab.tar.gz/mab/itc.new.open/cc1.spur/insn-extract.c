/* Generated automatically by the program `genextract'
from the machine description file `md'.  */

#include "config.h"
#include "rtl.h"

extern rtx recog_operand[];
extern rtx *recog_operand_loc[];
extern rtx *recog_dup_loc[];
extern char recog_dup_num[];

#ifdef __STDC__
#define VOID void
#else
#define VOID int
#endif

VOID
extract_0 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_1 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 1));
}

VOID
extract_2 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_3 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_4 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_5 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_6 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_7 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_8 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_9 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_10 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_11 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 1), 0));
}

VOID
extract_12 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_13 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_14 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_15 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_16 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_17 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_18 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_19 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_20 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_21 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (XEXP (insn, 1), 2), 0));
}

VOID
extract_22 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_23 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (XEXP (insn, 1), 0), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (XEXP (insn, 1), 0), 1));
}

VOID extract_24 () {}

VOID
extract_25 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_26 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 2));
}

VOID
extract_27 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (insn, 0), 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 0), 2));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (insn, 1));
}

VOID extract_28 () {}

VOID extract_29 () {}

VOID extract_30 () {}

VOID extract_31 () {}

VOID
extract_32 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_33 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 2));
}

VOID
extract_34 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (insn, 0), 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 0), 2));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (insn, 1));
}

VOID
extract_35 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_36 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_37 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_38 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_39 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_40 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_41 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID extract_42 () {}

VOID
extract_43 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_44 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID extract_45 () {}

VOID extract_46 () {}

VOID extract_47 () {}

VOID
extract_48 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_49 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_50 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_51 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_52 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_53 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_54 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_55 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_56 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_57 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_58 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_59 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_60 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_61 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_62 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_63 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_64 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_65 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_66 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_67 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_68 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_69 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_70 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID extract_71 () {}

VOID extract_72 () {}

VOID extract_73 () {}

VOID extract_74 () {}

VOID
extract_75 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (insn, 1), 0));
}

VOID
extract_76 (insn)
     rtx insn;
{
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (XVECEXP (insn, 0, 1), 0), 0));
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XVECEXP (insn, 0, 0), 1));
}

VOID
extract_77 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_78 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (insn, 1), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID
extract_79 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (XEXP (insn, 0), 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (insn, 1));
}

VOID
extract_80 (insn)
     rtx insn;
{
  recog_operand[0] = *(recog_operand_loc[0]
    = &XEXP (insn, 0));
  recog_operand[1] = *(recog_operand_loc[1]
    = &XEXP (XEXP (XEXP (insn, 1), 0), 0));
  recog_operand[2] = *(recog_operand_loc[2]
    = &XEXP (XEXP (insn, 1), 1));
}

VOID (*insn_extract_fn[]) () =
{ extract_0, extract_1, extract_2, extract_3,
  extract_4, extract_5, extract_6, extract_7,
  extract_8, extract_9, extract_10, extract_11,
  extract_12, extract_13, extract_14, extract_15,
  extract_16, extract_17, extract_18, extract_19,
  extract_20, extract_21, extract_22, extract_23,
  extract_24, extract_25, extract_26, extract_27,
  extract_28, extract_29, extract_30, extract_31,
  extract_32, extract_33, extract_34, extract_35,
  extract_36, extract_37, extract_38, extract_39,
  extract_40, extract_41, extract_42, extract_43,
  extract_44, extract_45, extract_46, extract_47,
  extract_48, extract_49, extract_50, extract_51,
  extract_52, extract_53, extract_54, extract_55,
  extract_56, extract_57, extract_58, extract_59,
  extract_60, extract_61, extract_62, extract_63,
  extract_64, extract_65, extract_66, extract_67,
  extract_68, extract_69, extract_70, extract_71,
  extract_72, extract_73, extract_74, extract_75,
  extract_76, extract_77, extract_78, extract_79,
  extract_80
};

void
insn_extract (insn)
     rtx insn;
{
  if (INSN_CODE (insn) == -1) abort ();
  (*insn_extract_fn[INSN_CODE (insn)]) (PATTERN (insn));
}
