/*
 * dummy.h --
 *
 * This is an empty include file.  It is the target of a symbolic link
 * in ../../cpp/config.h.  It turns out that some of the files in cpp
 * include config.h, even though they don't need to.  The "real" config.h
 * files are target-machine specific, so ../../cpp/config.h was made
 * to point here to keep cpp target-independent.
 */
