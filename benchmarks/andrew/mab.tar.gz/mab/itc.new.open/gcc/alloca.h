/*
 * alloca.h -
 *
 * This is a dummy header file for machines and operating systems
 * that don't have a real "alloca.h" header file.  If this machine
 * really has an alloca.h header file, delete or move this file
 * so that the real one will be used in place of this one.
 */
